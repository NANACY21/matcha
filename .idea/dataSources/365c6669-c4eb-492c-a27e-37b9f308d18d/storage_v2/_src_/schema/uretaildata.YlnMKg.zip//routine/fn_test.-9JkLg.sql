create
    definer = root@`%` procedure fn_test(IN tn varchar(50))
BEGIN
CREATE TEMPORARY TABLE
			IF NOT EXISTS tn (
				name1 VARCHAR (50),
				value1 VARCHAR (50)
			) ENGINE = INNODB DEFAULT CHARSET = utf8;
insert into tn(name1,value1) select ccode,cname from st_exchangeinfo;
select * from tn;

END;

