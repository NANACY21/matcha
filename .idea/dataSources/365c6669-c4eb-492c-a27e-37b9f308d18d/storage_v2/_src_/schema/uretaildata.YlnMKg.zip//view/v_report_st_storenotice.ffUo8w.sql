create definer = root@`%` view v_report_st_storenotice as
select `uretaildata`.`st_storenotice`.`ioutstoreid`     AS `ioutstoreid`,
       `uretaildata`.`st_storenotice`.`ioutwarehouseid` AS `ioutwarehouseid`,
       `uretaildata`.`st_storenotice`.`iinstoreid`      AS `iinstoreid`,
       `uretaildata`.`st_storenotice`.`iinwarehouseid`  AS `iinwarehouseid`,
       `uretaildata`.`st_storenotice`.`ibustypeid`      AS `ibustypeid`,
       `uretaildata`.`st_storenotice`.`ioperatorid`     AS `ioperatorid`,
       `uretaildata`.`st_storenotice`.`cmemo`           AS `cmemo`,
       `uretaildata`.`st_storenotice`.`csrcbillid`      AS `csrcbillid`,
       `uretaildata`.`st_storenotice`.`csrcbillno`      AS `csrcbillno`,
       `uretaildata`.`st_storenotice`.`bizstatus`       AS `bizstatus`,
       `uretaildata`.`st_storenotice`.`closer`          AS `closer`,
       `uretaildata`.`st_storenotice`.`close_time`      AS `close_time`,
       `uretaildata`.`st_storenotice`.`close_Date`      AS `close_Date`,
       `uretaildata`.`st_storenotice`.`auditor`         AS `auditor`,
       `uretaildata`.`st_storenotice`.`audit_time`      AS `audit_time`,
       `uretaildata`.`st_storenotice`.`audit_date`      AS `audit_date`,
       `uretaildata`.`st_storenotice`.`iStoreID`        AS `iStoreID`,
       `uretaildata`.`st_storenotice`.`vouchdate`       AS `vouchdate`,
       `uretaildata`.`st_storenotice`.`tplid`           AS `tplid`,
       `uretaildata`.`st_storenotice`.`code`            AS `code`,
       `uretaildata`.`st_storenotice`.`create_time`     AS `create_time`,
       `uretaildata`.`st_storenotice`.`create_date`     AS `create_date`,
       `uretaildata`.`st_storenotice`.`modify_time`     AS `modify_time`,
       `uretaildata`.`st_storenotice`.`modify_date`     AS `modify_date`,
       `uretaildata`.`st_storenotice`.`creator`         AS `creator`,
       `uretaildata`.`st_storenotice`.`modifier`        AS `modifier`,
       `uretaildata`.`st_storenotice`.`tenant_id`       AS `tenant_id`,
       `uretaildata`.`st_storenotice`.`id`              AS `id`,
       `uretaildata`.`st_storenotice`.`pubts`           AS `pubts`,
       `uretaildata`.`st_storenotice`.`status`          AS `status`,
       `uretaildata`.`st_storenotice`.`csrcbilltype`    AS `csrcbilltype`,
       `uretaildata`.`st_storenotice`.`csrctopid`       AS `csrctopid`,
       `uretaildata`.`st_storenotice`.`csrctopno`       AS `csrctopno`,
       `uretaildata`.`st_storenotice`.`fTotalQuantity`  AS `fTotalQuantity`,
       `uretaildata`.`st_storenotice`.`iVendorId`       AS `iVendorId`,
       `uretaildata`.`st_storenotice`.`iinwarehouseid`  AS `iwarehouseid`
from `uretaildata`.`st_storenotice`;

-- comment on column v_report_st_storenotice.ioutstoreid not supported: 调出门店

-- comment on column v_report_st_storenotice.ioutwarehouseid not supported: 调出仓库

-- comment on column v_report_st_storenotice.iinstoreid not supported: 调入门店

-- comment on column v_report_st_storenotice.iinwarehouseid not supported: 调入仓库

-- comment on column v_report_st_storenotice.ibustypeid not supported: 业务类型

-- comment on column v_report_st_storenotice.ioperatorid not supported: 经办人

-- comment on column v_report_st_storenotice.cmemo not supported: 备注

-- comment on column v_report_st_storenotice.csrcbillid not supported: 来源单据

-- comment on column v_report_st_storenotice.csrcbillno not supported: 来源单据号

-- comment on column v_report_st_storenotice.bizstatus not supported: 单据状态

-- comment on column v_report_st_storenotice.closer not supported: 关闭人

-- comment on column v_report_st_storenotice.close_time not supported: 关闭时间

-- comment on column v_report_st_storenotice.close_Date not supported: 关闭日期

-- comment on column v_report_st_storenotice.auditor not supported: 审批人

-- comment on column v_report_st_storenotice.audit_time not supported: 审批时间

-- comment on column v_report_st_storenotice.audit_date not supported: 审批日期

-- comment on column v_report_st_storenotice.iStoreID not supported: 门店ID

-- comment on column v_report_st_storenotice.vouchdate not supported: 单据日期

-- comment on column v_report_st_storenotice.tplid not supported: 模板id

-- comment on column v_report_st_storenotice.code not supported: 编码

-- comment on column v_report_st_storenotice.create_time not supported: 创建时间

-- comment on column v_report_st_storenotice.create_date not supported: 创建日期

-- comment on column v_report_st_storenotice.modify_time not supported: 修改时间

-- comment on column v_report_st_storenotice.modify_date not supported: 修改日期

-- comment on column v_report_st_storenotice.creator not supported: 创建人

-- comment on column v_report_st_storenotice.modifier not supported: 修改人

-- comment on column v_report_st_storenotice.tenant_id not supported: 租户

-- comment on column v_report_st_storenotice.id not supported: ID

-- comment on column v_report_st_storenotice.pubts not supported: 时间戳

-- comment on column v_report_st_storenotice.status not supported: 单据状态

-- comment on column v_report_st_storenotice.csrcbilltype not supported: 来源单据类型

-- comment on column v_report_st_storenotice.fTotalQuantity not supported: 整单数量

-- comment on column v_report_st_storenotice.iVendorId not supported: 供应商

-- comment on column v_report_st_storenotice.iwarehouseid not supported: 调入仓库

