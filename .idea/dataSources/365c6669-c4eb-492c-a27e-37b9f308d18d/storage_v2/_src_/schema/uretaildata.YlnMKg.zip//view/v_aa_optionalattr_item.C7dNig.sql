create definer = root@`%` view v_aa_optionalattr_item as
select `t1`.`parent_id` AS `parent_id`, group_concat(`t1`.`attrValueName` separator ',') AS `attrValueName`
from `uretaildata`.`aa_optionalattr_item` `t1`
group by `t1`.`parent_id`;

