create
    definer = root@`%` procedure p_aa_updateTableName(IN sourceTablename varchar(200), IN targetTablename varchar(200),
                                                      IN executeType varchar(200), IN executeStr varchar(200))
BEGIN
	DECLARE CurrentDatabase VARCHAR(100);
	SELECT DATABASE() INTO CurrentDatabase;
	SET @sourceTablename = sourceTablename;
	SET @targetTablename = targetTablename;
	SET @executeType = executeType;
	SET @executeStr = executeStr;
	SET @count1 = (SELECT COUNT(*)
								FROM information_schema.`TABLES` 
								WHERE table_schema=CurrentDatabase 
								AND TABLE_NAME=@sourceTablename);
	SET @count2 = (SELECT COUNT(*)
								FROM information_schema.`TABLES` 
								WHERE table_schema=CurrentDatabase 
								AND TABLE_NAME=@targetTablename);
	IF @executeType	= 'alter' AND @count1 >0 AND @count2 = 0 THEN  
		PREPARE stmt1 FROM @executeStr;
		EXECUTE stmt1;
	END IF;
END;

