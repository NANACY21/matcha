create definer = root@`%` view v_winshor_fjlxzs as
select `t1`.`store_id` AS `store_id`,
       `store`.`cName` AS `store_name`,
       `t1`.`roomType` AS `roomType`,
       `t3`.`name`     AS `roomType_name`,
       `period`.`name` AS `timeperiod`,
       count(0)        AS `totalnum`
from (((`uretaildata`.`aa_room` `t1` left join `yilian`.`mp_store` `store` on ((`store`.`id` = `t1`.`store_id`))) left join `uretaildata`.`aa_roomtype` `t3` on ((`t1`.`roomType` = `t3`.`id`)))
         left join `uretaildata`.`aa_timeperiod` `period` on ((`period`.`store` = `store`.`id`)))
group by `t1`.`store_id`, `t3`.`name`, `period`.`name`;

-- comment on column v_winshor_fjlxzs.store_id not supported: 门店ID

-- comment on column v_winshor_fjlxzs.store_name not supported: 门店名称

-- comment on column v_winshor_fjlxzs.roomType not supported: 房间类型

-- comment on column v_winshor_fjlxzs.roomType_name not supported: 名称

-- comment on column v_winshor_fjlxzs.timeperiod not supported: 名称

