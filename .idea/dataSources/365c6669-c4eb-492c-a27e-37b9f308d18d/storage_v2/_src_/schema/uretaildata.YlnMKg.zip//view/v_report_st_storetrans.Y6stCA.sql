create definer = root@`%` view v_report_st_storetrans as
select `uretaildata`.`st_storetrans`.`ioutwarehouseid` AS `ioutwarehouseid`,
       `uretaildata`.`st_storetrans`.`iinwarehouseid`  AS `iinwarehouseid`,
       `uretaildata`.`st_storetrans`.`ibusinesstype`   AS `ibusinesstype`,
       `uretaildata`.`st_storetrans`.`ioperatorid`     AS `ioperatorid`,
       `uretaildata`.`st_storetrans`.`cMemo`           AS `cMemo`,
       `uretaildata`.`st_storetrans`.`auditor`         AS `auditor`,
       `uretaildata`.`st_storetrans`.`audit_time`      AS `audit_time`,
       `uretaildata`.`st_storetrans`.`audit_date`      AS `audit_date`,
       `uretaildata`.`st_storetrans`.`iStoreID`        AS `iStoreID`,
       `uretaildata`.`st_storetrans`.`vouchdate`       AS `vouchdate`,
       `uretaildata`.`st_storetrans`.`tplid`           AS `tplid`,
       `uretaildata`.`st_storetrans`.`status`          AS `status`,
       `uretaildata`.`st_storetrans`.`code`            AS `code`,
       `uretaildata`.`st_storetrans`.`create_time`     AS `create_time`,
       `uretaildata`.`st_storetrans`.`create_date`     AS `create_date`,
       `uretaildata`.`st_storetrans`.`modify_time`     AS `modify_time`,
       `uretaildata`.`st_storetrans`.`modify_date`     AS `modify_date`,
       `uretaildata`.`st_storetrans`.`creator`         AS `creator`,
       `uretaildata`.`st_storetrans`.`modifier`        AS `modifier`,
       `uretaildata`.`st_storetrans`.`tenant_id`       AS `tenant_id`,
       `uretaildata`.`st_storetrans`.`id`              AS `id`,
       `uretaildata`.`st_storetrans`.`pubts`           AS `pubts`,
       `uretaildata`.`st_storetrans`.`fTotalQuantity`  AS `fTotalQuantity`,
       `uretaildata`.`st_storetrans`.`iShopID`         AS `iShopID`,
       `uretaildata`.`st_storetrans`.`iinwarehouseid`  AS `iwarehouseid`
from `uretaildata`.`st_storetrans`;

-- comment on column v_report_st_storetrans.ioutwarehouseid not supported: 出库仓库

-- comment on column v_report_st_storetrans.iinwarehouseid not supported: 入库仓库

-- comment on column v_report_st_storetrans.ibusinesstype not supported: 业务类型

-- comment on column v_report_st_storetrans.ioperatorid not supported: 经办人

-- comment on column v_report_st_storetrans.cMemo not supported: 备注

-- comment on column v_report_st_storetrans.auditor not supported: 审批人

-- comment on column v_report_st_storetrans.audit_time not supported: 审批时间

-- comment on column v_report_st_storetrans.audit_date not supported: 审批日期

-- comment on column v_report_st_storetrans.iStoreID not supported: 门店ID

-- comment on column v_report_st_storetrans.vouchdate not supported: 单据日期

-- comment on column v_report_st_storetrans.tplid not supported: 模板id

-- comment on column v_report_st_storetrans.status not supported: 单据状态

-- comment on column v_report_st_storetrans.code not supported: 编码

-- comment on column v_report_st_storetrans.create_time not supported: 创建时间

-- comment on column v_report_st_storetrans.create_date not supported: 创建日期

-- comment on column v_report_st_storetrans.modify_time not supported: 修改时间

-- comment on column v_report_st_storetrans.modify_date not supported: 修改日期

-- comment on column v_report_st_storetrans.creator not supported: 创建人

-- comment on column v_report_st_storetrans.modifier not supported: 修改人

-- comment on column v_report_st_storetrans.tenant_id not supported: 租户

-- comment on column v_report_st_storetrans.id not supported: ID

-- comment on column v_report_st_storetrans.pubts not supported: 时间戳

-- comment on column v_report_st_storetrans.fTotalQuantity not supported: 整单数量

-- comment on column v_report_st_storetrans.iShopID not supported: 商家

-- comment on column v_report_st_storetrans.iwarehouseid not supported: 入库仓库

