create
    definer = root@`%` procedure changecolumn()
BEGIN 
	IF EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = 'mp_storeemployee' AND column_name = 'bIsclerk') THEN
		alter table `mp_storeemployee` change COLUMN `bIsclerk` `bIsclerk` bit(1) DEFAULT b'1' COMMENT '是否店员';
	end if ;
END;

