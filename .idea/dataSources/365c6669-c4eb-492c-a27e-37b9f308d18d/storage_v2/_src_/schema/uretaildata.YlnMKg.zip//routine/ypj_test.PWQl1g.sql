create
    definer = root@`%` procedure ypj_test(IN rtn int)
begin  
    IF rtn is NULL   THEN  
        set @rtn=2;  
    ELSEIF rtn = 0    THEN  
        set @rtn=3;  
    ELSE  
        set @rtn=5;  
    END IF;  
end;

