create definer = root@`%` view aa_v_productlook as
select distinct `t1`.`product_id` AS `id`,
                ''                AS `code`,
                'tempName222'     AS `name`,
                `t1`.`product_id` AS `product_id`,
                ''                AS `lookat`,
                `t1`.`tenant_id`  AS `tenant_id`,
                ''                AS `parent_id`,
                ''                AS `level`,
                ''                AS `path`,
                ''                AS `sort_num`,
                ''                AS `isEnd`,
                ''                AS `pubts`
from `uretaildata`.`aa_goodsproductscomparison` `t1`;

