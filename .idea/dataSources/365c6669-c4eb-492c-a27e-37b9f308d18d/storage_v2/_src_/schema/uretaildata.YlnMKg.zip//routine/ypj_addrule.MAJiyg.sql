create
    definer = root@`%` procedure ypj_addrule(IN rtn int)
begin  
    IF rtn is NOT NULL   THEN  
		select rtn;
		##需要实现的rule
		delete from billruleregister where ruleId = 'checkReturnBillRule' and billnum ='st_returnapply' and action ='pullAndpush';
		##需要实现的rule
		-- <!-- 一品佳校验出库校验 -->
		INSERT INTO `uretaildata`.`billruleregister`(`billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT 'st_returnapply', 'pullAndpush', 'checkReturnBillRule', 14.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL  from tenant where id<>0
		union
		SELECT 'st_returnapply', 'pullAndpush', 'checkReturnBillRule', 14.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'checkPurinrecordBillRule' and billnum ='st_purinrecord_conver' and action ='pullAndpush';
		-- <!-- 一品佳校验领料消耗校验 -->
		INSERT INTO `uretaildata`.`billruleregister`(`billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT 'st_purinrecord_conver', 'pullAndpush', 'checkPurinrecordBillRule', 14.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT 'st_purinrecord_conver', 'pullAndpush', 'checkPurinrecordBillRule', 14.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'checkPurinrecordBillRule' and billnum ='storeAcquisitionCost' and action ='pullAndpush';
		INSERT INTO `uretaildata`.`billruleregister`(`billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`)
		SELECT 'storeAcquisitionCost', 'pullAndpush', 'checkPurinrecordBillRule', 14.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT 'storeAcquisitionCost', 'pullAndpush', 'checkPurinrecordBillRule', 14.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'saveBillBeforeCheckRule' and billnum ='common' and action ='save';
		##<!-- 一品佳单据校验rule-->
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`)
		SELECT 'common', 'save', 'saveBillBeforeCheckRule', 29.60, NULL, id , NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT 'common', 'save', 'saveBillBeforeCheckRule', 29.60, NULL, 0 , NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'beforeQueryDemandPlanToApplyRule' and billnum ='demandPlanToApply' and action ='query';
		##<!-- 要货计划推要货申请列表查询规则 -->
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`)
		SELECT 'demandPlanToApply', 'query', 'beforeQueryDemandPlanToApplyRule', 20.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT 'demandPlanToApply', 'query', 'beforeQueryDemandPlanToApplyRule', 20.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL
		;
		
		delete from billruleregister where ruleId = 'storeoutSaveBeforeCheckRule' and billnum ='common' and action ='save';
		##<!-- 一品佳店存出库单保存单据校验rule-->
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT 'common', 'save', 'storeoutSaveBeforeCheckRule', 29.70, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT 'common', 'save', 'storeoutSaveBeforeCheckRule', 29.70, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL  
		;
		
		delete from billruleregister where ruleId = 'salesCheckRule' and billnum ='st_purinrecord_sale' and action ='pullAndpush';
		##<!-- 一品佳店退货业务rule-->
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT 'st_purinrecord_sale', 'pullAndpush', 'salesCheckRule', 1.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT 'st_purinrecord_sale', 'pullAndpush', 'salesCheckRule', 1.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'stDefaultBillRule' and billnum ='ST' and action ='add';
		##<!-- 一品佳店页面默认值设置rule-->
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`)
		SELECT 'ST', 'add', 'stDefaultBillRule', 31.00, 'addBillRule',  id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT 'ST', 'add', 'stDefaultBillRule', 31.00, 'addBillRule',  0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'differencesCalculateRule' and billnum ='Trukdifferences' and action ='pullAndpush';
		##<!-- 一品佳_收货差异计算rule-->
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT 'Trukdifferences', 'pullAndpush', 'differencesCalculateRule', 61.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT 'Trukdifferences', 'pullAndpush', 'differencesCalculateRule', 61.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		;
		
		delete from billruleregister where ruleId = 'auditBillCheckRule' and billnum ='rm_demandplanlist' and action ='audit';
		#要货计划推送SAP
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT 'rm_demandplanlist', 'audit', 'auditBillCheckRule', 29.90, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT 'rm_demandplanlist', 'audit', 'auditBillCheckRule', 29.90, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'auditBillCheckRule' and billnum ='rm_receiving_differenceslist' and action ='audit';
		#收获差异推送SAP#收获差异推送SAP
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`)
		SELECT 'rm_receiving_differenceslist', 'audit', 'auditBillCheckRule', 29.90, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL  from tenant where id<>0
		union
		SELECT 'rm_receiving_differenceslist', 'audit', 'auditBillCheckRule', 29.90, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL
		;
		
		delete from billruleregister where ruleId = 'auditBillCheckRule' and billnum ='rm_receiving_differences' and action ='audit';
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT'rm_receiving_differences', 'audit', 'auditBillCheckRule', 29.90, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT'rm_receiving_differences', 'audit', 'auditBillCheckRule', 29.90, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'stDefaultFillRule' and billnum ='rm_demandplan' and action ='add';
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`)
		SELECT 'rm_demandplan', 'add', 'stDefaultFillRule', 30.00, 'addBillRule', id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT 'rm_demandplan', 'add', 'stDefaultFillRule', 30.00, 'addBillRule', 0, NULL, b'1', NULL, 0, NULL, NULL, NULL
		;
		
		delete from billruleregister where ruleId = 'stDefaultFillRule' and billnum ='st_special_demandapply' and action ='add';
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT 'st_special_demandapply', 'add', 'stDefaultFillRule', 30.00, 'addBillRule', id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0 
		union
		SELECT 'st_special_demandapply', 'add', 'stDefaultFillRule', 30.00, 'addBillRule', 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'stDefaultFillRule' and billnum ='rm_receiving_differences' and action ='add';
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT 'rm_receiving_differences', 'add', 'stDefaultFillRule', 30.00, 'addBillRule', id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0 
		union
		SELECT 'rm_receiving_differences', 'add', 'stDefaultFillRule', 30.00, 'addBillRule', 0, NULL, b'1', NULL, 0, NULL, NULL, NULL
		;
		
		delete from billruleregister where ruleId = 'findWarehouseAroundStore' and billnum ='rm_demandplan' and action ='refer';
		#按照门店ID 检索门店周边仓库
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT 'rm_demandplan', 'refer', 'findWarehouseAroundStore', 15.00, NULL,  id, 'aa_warehouse', b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union 
		SELECT 'rm_demandplan', 'refer', 'findWarehouseAroundStore', 15.00, NULL,  0, 'aa_warehouse', b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'beforestorenoticePullAndPushRule' and billnum ='st_storenotice' and action ='pullAndpush';
		#入库通知单入库功能校验是否生成差异
		INSERT INTO `uretaildata`.`billruleregister`(`billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT  'st_storenotice', 'pullAndpush', 'beforestorenoticePullAndPushRule', 29.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0  
		union 
		SELECT  'st_storenotice', 'pullAndpush', 'beforestorenoticePullAndPushRule', 29.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'splitStorenoticeRule' and billnum ='st_storenotice' and action ='pullAndpush';
		#入库通知单自动拆分
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`)
		SELECT  'st_storenotice', 'pullAndpush', 'splitStorenoticeRule', 66.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0 
		union 
		SELECT  'st_storenotice', 'pullAndpush', 'splitStorenoticeRule', 66.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'storenoticeTopurinrecordRule' and billnum ='storenoticeTopurinrecord' and action ='pullAndpush';
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT  'storenoticeTopurinrecord', 'pullAndpush', 'storenoticeTopurinrecordRule', 66.00, NULL,  id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0  
		union
		SELECT  'storenoticeTopurinrecord', 'pullAndpush', 'storenoticeTopurinrecordRule', 66.00, NULL,  0, NULL, b'1', NULL, 0, NULL, NULL, NULL
		;
		
		delete from billruleregister where ruleId = 'queryByiCabinetgroup' and billnum ='common' and action ='query';
		#柜组权限Rule
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT  'common', 'query', 'queryByiCabinetgroup', 29.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0  
		union 
		SELECT  'common', 'query', 'queryByiCabinetgroup', 29.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL
		;
		
		delete from billruleregister where ruleId = 'cabinetShiroFilterRule' and billnum ='common' and action ='refer';
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT  'common', 'refer', 'cabinetShiroFilterRule', 10.00, NULL, id, 'aa_cabinetgroupref', b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0 
		union 
		SELECT  'common', 'refer', 'cabinetShiroFilterRule', 10.00, NULL, 0, 'aa_cabinetgroupref', b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'retQtyBillDefaultRule' and billnum ='st_purinrecord_sale' and action ='pullAndpush';
		#默认退货数量
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT  'st_purinrecord_sale', 'pullAndpush', 'retQtyBillDefaultRule', 61.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0  
		union 
		SELECT  'st_purinrecord_sale', 'pullAndpush', 'retQtyBillDefaultRule', 61.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL
		;
		
		delete from billruleregister where ruleId = 'productFilterRule' and billnum ='common' and action ='refer';
		#要货申请_过滤加工商品
		INSERT INTO `uretaildata`.`billruleregister`(`billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT  'common', 'refer', 'productFilterRule', 35.00, NULL,  id, 'aa_skuwithfilter', b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0
		union
		SELECT  'common', 'refer', 'productFilterRule', 35.00, NULL,  0, 'aa_skuwithfilter', b'1', NULL, 0, NULL, NULL, NULL
		;
		
		delete from billruleregister where ruleId = 'demandPlanUnauditBillWebRule' and billnum ='rm_demandplanlist' and action ='unaudit';
		#要货计划撤回
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`)
		SELECT  'rm_demandplanlist', 'unaudit', 'demandPlanUnauditBillWebRule', 29.00, NULL,  id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0  
		union 
		SELECT  'rm_demandplanlist', 'unaudit', 'demandPlanUnauditBillWebRule', 29.00, NULL,  0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'demandPlanUnauditBillWebRule' and billnum ='rm_demandplan' and action ='unaudit';
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT  'rm_demandplan', 'unaudit', 'demandPlanUnauditBillWebRule', 29.00, NULL,  id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0  
		union 
		SELECT  'rm_demandplan', 'unaudit', 'demandPlanUnauditBillWebRule', 29.00, NULL,  0, NULL, b'1', NULL, 0, NULL, NULL, NULL  
		;
		
		delete from billruleregister where ruleId = 'submitBillcheckRule' and billnum ='common' and action ='audit';
		#同步接口
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`) 
		SELECT  'common', 'audit', 'submitBillcheckRule', 29.90, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0  
		union 
		SELECT  'common', 'audit', 'submitBillcheckRule', 29.90, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
		
		delete from billruleregister where ruleId = 'submitcheckRule' and billnum ='common' and action ='audit';
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, `domain`, `dataRule`)
		SELECT  'common', 'audit', 'submitcheckRule', 29.90, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0  
		union
		SELECT  'common', 'audit', 'submitcheckRule', 29.90, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL
		;
		
		delete from billruleregister where ruleId = 'saveSpecialNumBeforeRule' and billnum ='common' and action ='save';
		#特价菜控制要货数
		INSERT INTO `uretaildata`.`billruleregister`( `billnum`, `action`, `ruleId`, `iorder`, `overrule`, `tenant_id`, `key`, `isSystem`, `url`, `isAsyn`, `config`, 	`domain`, `dataRule`) 
		SELECT  'common', 'save', 'saveSpecialNumBeforeRule', 29.00, NULL, id, NULL, b'1', NULL, 0, NULL, NULL, NULL from tenant where id<>0  
		union
		SELECT  'common', 'save', 'saveSpecialNumBeforeRule', 29.00, NULL, 0, NULL, b'1', NULL, 0, NULL, NULL, NULL 
		;
 END IF;  
end;

