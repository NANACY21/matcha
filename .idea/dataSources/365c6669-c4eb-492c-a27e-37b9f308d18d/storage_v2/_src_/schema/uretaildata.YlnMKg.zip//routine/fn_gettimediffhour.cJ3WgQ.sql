create
    definer = root@`%` function fn_gettimediffhour(d1 datetime, d2 datetime) returns mediumtext
BEGIN
DECLARE x long DEFAULT NULL;
SET x= TIMESTAMPDIFF(HOUR,d1,d2);
RETURN x;                              
END;

