create definer = uretail@`192.168.1.%` view v_rm_salereceipts_report_group as
select `uretaildata`.`rm_paymentwritedetail`.`iRetailid` AS `iRetailid`,
       max(`uretaildata`.`rm_paymentwritedetail`.`id`)   AS `rm_paymentwritedetailid`,
       1                                                 AS `isSumLine`,
       `uretaildata`.`rm_paymentwrite`.`tenant_id`       AS `tenant_id`
from (`uretaildata`.`rm_paymentwrite`
         left join `uretaildata`.`rm_paymentwritedetail`
                   on ((`uretaildata`.`rm_paymentwrite`.`id` = `uretaildata`.`rm_paymentwritedetail`.`ipaymentwriteid`)))
group by `uretaildata`.`rm_paymentwritedetail`.`iRetailid`, `uretaildata`.`rm_paymentwrite`.`tenant_id`;

-- comment on column v_rm_salereceipts_report_group.iRetailid not supported: 零售单id

-- comment on column v_rm_salereceipts_report_group.rm_paymentwritedetailid not supported: ID

