create
    definer = root@`%` procedure addreporttablecolumn()
BEGIN 
	IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = 'rm_daily_report' AND column_name = 'dMakeDate') THEN
	alter table `rm_daily_report`  add COLUMN `dMakeDate` datetime DEFAULT NULL COMMENT '制单日期';
	end if ;
END;

