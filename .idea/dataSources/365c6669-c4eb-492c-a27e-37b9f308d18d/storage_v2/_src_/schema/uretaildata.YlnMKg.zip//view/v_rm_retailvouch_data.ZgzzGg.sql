create definer = root@`%` view v_rm_retailvouch_data as
select `uretaildata`.`rm_retailvouch`.`id`                     AS `id`,
       `uretaildata`.`rm_retailvouch`.`cCode`                  AS `cCode`,
       `uretaildata`.`rm_retailvouch`.`dDate`                  AS `vouchdate`,
       `uretaildata`.`rm_retailvouch`.`iStoreid`               AS `iStoreid`,
       `uretaildata`.`rm_retailvouch`.`cStoreCode`             AS `cStoreCode`,
       `uretaildata`.`rm_retailvouch`.`cMachineid`             AS `cMachineid`,
       `uretaildata`.`rm_retailvouch`.`iOrgid`                 AS `iOrgid`,
       `uretaildata`.`rm_retailvouch`.`tenant_id`              AS `tenant_id`,
       `uretaildata`.`rm_retailvouch`.`iDepartmentid`          AS `iDepartmentid`,
       `uretaildata`.`rm_retailvouch`.`dDate`                  AS `dDate`,
       `uretaildata`.`rm_retailvouch`.`iGradeid`               AS `iGradeid`,
       `uretaildata`.`rm_retailvouch`.`iNegative`              AS `iNegative`,
       `uretaildata`.`rm_retailvouch`.`bHangUp`                AS `bHangUp`,
       `uretaildata`.`rm_retailvouch`.`iMemberid`              AS `iMemberid`,
       `uretaildata`.`rm_retailvouch`.`cMemberCode`            AS `cMemberCode`,
       `uretaildata`.`rm_retailvouch`.`iMaker`                 AS `iMaker`,
       `uretaildata`.`rm_retailvouch`.`fGatheringMoney`        AS `fGatheringMoney`,
       `uretaildata`.`rm_retailvouch`.`iCoRetailid`            AS `iCoRetailid`,
       `uretaildata`.`rm_retailvouch`.`fVIPRate`               AS `fVIPRate`,
       `uretaildata`.`rm_retailvouch`.`fDiscountRate`          AS `fDiscountRate`,
       `uretaildata`.`rm_retailvouch`.`fDiscountMoney`         AS `fDiscountMoney`,
       `uretaildata`.`rm_retailvouch`.`fEffaceMoney`           AS `fEffaceMoney`,
       `uretaildata`.`rm_retailvouch`.`iRelatingRetailid`      AS `iRelatingRetailid`,
       `uretaildata`.`rm_retailvouch`.`dMakeDate`              AS `dMakeDate`,
       `uretaildata`.`rm_retailvouch`.`fbitSettle`             AS `fbitSettle`,
       `uretaildata`.`rm_retailvouch`.`fPointCurrent`          AS `fPointCurrent`,
       `uretaildata`.`rm_retailvouch`.`fPointBalance`          AS `fPointBalance`,
       `uretaildata`.`rm_retailvouch`.`fCardBalance`           AS `fCardBalance`,
       `uretaildata`.`rm_retailvouch`.`dPlanShipmentDate`      AS `dPlanShipmentDate`,
       `uretaildata`.`rm_retailvouch`.`dShipmentDate`          AS `dShipmentDate`,
       `uretaildata`.`rm_retailvouch`.`cRemark`                AS `cRemark`,
       `uretaildata`.`rm_retailvouch`.`iPresellState`          AS `iPresellState`,
       `uretaildata`.`rm_retailvouch`.`iDeliveryState`         AS `iDeliveryState`,
       `uretaildata`.`rm_retailvouch`.`iPayState`              AS `iPayState`,
       `uretaildata`.`rm_retailvouch`.`iTakeway`               AS `iTakeway`,
       `uretaildata`.`rm_retailvouch`.`bDeliveryModify`        AS `bDeliveryModify`,
       `uretaildata`.`rm_retailvouch`.`bPreselllockStock`      AS `bPreselllockStock`,
       `uretaildata`.`rm_retailvouch`.`fVIPDiscountSum`        AS `fVIPDiscountSum`,
       `uretaildata`.`rm_retailvouch`.`fPromotionSum`          AS `fPromotionSum`,
       `uretaildata`.`rm_retailvouch`.`fSceneDiscountSum`      AS `fSceneDiscountSum`,
       `uretaildata`.`rm_retailvouch`.`fGiftApportion`         AS `fGiftApportion`,
       `uretaildata`.`rm_retailvouch`.`fSaleMoney`             AS `fSaleMoney`,
       `uretaildata`.`rm_retailvouch`.`fMoneySum`              AS `fMoneySum`,
       `uretaildata`.`rm_retailvouch`.`fQuantitySum`           AS `fQuantitySum`,
       `uretaildata`.`rm_retailvouch`.`fPresellPayMoney`       AS `fPresellPayMoney`,
       `uretaildata`.`rm_retailvouch`.`iDeliveryStoreid`       AS `iDeliveryStoreid`,
       `uretaildata`.`rm_retailvouch`.`iDeliveryWarehouseid`   AS `iDeliveryWarehouseid`,
       `uretaildata`.`rm_retailvouch`.`fPointPay`              AS `fPointPay`,
       `uretaildata`.`rm_retailvouch`.`fPointPayMoney`         AS `fPointPayMoney`,
       `uretaildata`.`rm_retailvouch`.`iBusinesstypeid`        AS `iBusinesstypeid`,
       `uretaildata`.`rm_retailvouch`.`iProfitTo`              AS `iProfitTo`,
       `uretaildata`.`rm_retailvouch`.`cRegionCode`            AS `cRegionCode`,
       `uretaildata`.`rm_retailvouch`.`cDeliveradd`            AS `cDeliveradd`,
       `uretaildata`.`rm_retailvouch`.`cCusperson`             AS `cCusperson`,
       `uretaildata`.`rm_retailvouch`.`cMobileNo`              AS `cMobileNo`,
       `uretaildata`.`rm_retailvouch`.`fCardDisApportion`      AS `fCardDisApportion`,
       `uretaildata`.`rm_retailvouch`.`fCardApportion`         AS `fCardApportion`,
       `uretaildata`.`rm_retailvouch`.`bRequireOver`           AS `bRequireOver`,
       `uretaildata`.`rm_retailvouch`.`blocalSale`             AS `blocalSale`,
       `uretaildata`.`rm_retailvouch`.`blocaDelivery`          AS `blocaDelivery`,
       `uretaildata`.`rm_retailvouch`.`iChangeUser`            AS `iChangeUser`,
       `uretaildata`.`rm_retailvouch`.`dChangeTime`            AS `dChangeTime`,
       `uretaildata`.`rm_retailvouch`.`bRestore`               AS `bRestore`,
       `uretaildata`.`rm_retailvouch`.`create_time`            AS `create_time`,
       `uretaildata`.`rm_retailvouch`.`create_date`            AS `create_date`,
       `uretaildata`.`rm_retailvouch`.`modify_time`            AS `modify_time`,
       `uretaildata`.`rm_retailvouch`.`modify_date`            AS `modify_date`,
       `uretaildata`.`rm_retailvouch`.`creator`                AS `creator`,
       `uretaildata`.`rm_retailvouch`.`modifier`               AS `modifier`,
       `uretaildata`.`rm_retailvouch`.`auditor`                AS `auditor`,
       `uretaildata`.`rm_retailvouch`.`audit_time`             AS `audit_time`,
       `uretaildata`.`rm_retailvouch`.`audit_date`             AS `audit_date`,
       `uretaildata`.`rm_retailvouch`.`tplid`                  AS `tplid`,
       `uretaildata`.`rm_retailvouch`.`status`                 AS `status`,
       `uretaildata`.`rm_retailvouch`.`pubts`                  AS `pubts`,
       `uretaildata`.`rm_retailvouch`.`fDiscountSum`           AS `fDiscountSum`,
       `uretaildata`.`rm_retailvouch`.`fQuoteMoneySum`         AS `fQuoteMoneySum`,
       `uretaildata`.`rm_retailvouch`.`fCoQuantitySum`         AS `fCoQuantitySum`,
       `uretaildata`.`rm_retailvouch`.`dPresellDate`           AS `dPresellDate`,
       `uretaildata`.`rm_retailvouch`.`fChangeMoney`           AS `fChangeMoney`,
       `uretaildata`.`rm_retailvouch`.`fCoDiscountSum`         AS `fCoDiscountSum`,
       `uretaildata`.`rm_retailvouch`.`fbitReport`             AS `fbitReport`,
       `uretaildata`.`rm_retailvouch`.`cLogisticid`            AS `cLogisticid`,
       `uretaildata`.`rm_retailvouch`.`cLogisticsNo`           AS `cLogisticsNo`,
       `uretaildata`.`rm_retailvouch`.`cCourierid`             AS `cCourierid`,
       `uretaildata`.`rm_retailvouch`.`cCourierPhone`          AS `cCourierPhone`,
       `uretaildata`.`rm_retailvouch`.`iOwesState`             AS `iOwesState`,
       `uretaildata`.`rm_retailvouch`.`iCustomerid`            AS `iCustomerid`,
       `uretaildata`.`rm_retailvouch`.`cGUID`                  AS `cGUID`,
       `uretaildata`.`rm_retailvouch`.`ioffline`               AS `ioffline`,
       `uretaildata`.`rm_retailvouch`.`fSellerPointBalance`    AS `fSellerPointBalance`,
       `uretaildata`.`rm_retailvouch`.`fSellerPointCurrent`    AS `fSellerPointCurrent`,
       `uretaildata`.`rm_retailvouch`.`fSellerPointPay`        AS `fSellerPointPay`,
       `uretaildata`.`rm_retailvouch`.`printCount`             AS `printCount`,
       `uretaildata`.`rm_retailvouch`.`iEInvoiceState`         AS `iEInvoiceState`,
       `uretaildata`.`rm_retailvouch`.`cEInvoiceURL`           AS `cEInvoiceURL`,
       `uretaildata`.`rm_retailvouch`.`bCoEInvoiceOver`        AS `bCoEInvoiceOver`,
       `uretaildata`.`rm_retailvouch`.`cRetailURL`             AS `cRetailURL`,
       `uretaildata`.`rm_retailvouch`.`iCoEInvoiceWay`         AS `iCoEInvoiceWay`,
       `uretaildata`.`rm_retailvouch`.`dEInvoiceEndData`       AS `dEInvoiceEndData`,
       `uretaildata`.`rm_retailvouch`.`iPrcsStatus`            AS `iPrcsStatus`,
       `uretaildata`.`rm_retailvouch`.`handMakeInvoicePeo`     AS `handMakeInvoicePeo`,
       `uretaildata`.`rm_retailvouch`.`handMakeInvoiceTime`    AS `handMakeInvoiceTime`,
       `uretaildata`.`rm_retailvouch`.`bAmountAdjustment`      AS `bAmountAdjustment`,
       `uretaildata`.`rm_retailvouch`.`bGiveawayList`          AS `bGiveawayList`,
       `uretaildata`.`rm_retailvouch`.`bcustomizedOrder`       AS `bcustomizedOrder`,
       `uretaildata`.`rm_retailvouch`.`bReturnStore`           AS `bReturnStore`,
       `uretaildata`.`rm_retailvouch`.`iReturnWarehousid`      AS `iReturnWarehousid`,
       `uretaildata`.`rm_retailvouch`.`iGiveawayListRetailid`  AS `iGiveawayListRetailid`,
       `uretaildata`.`rm_retailvouch`.`iAmountAdjustRetailid`  AS `iAmountAdjustRetailid`,
       `uretaildata`.`rm_retailvouch`.`iGatheringType`         AS `iGatheringType`,
       `uretaildata`.`rm_retailvouch`.`bUnsubscribe`           AS `bUnsubscribe`,
       `uretaildata`.`rm_retailvouch`.`unsubscribeReason`      AS `unsubscribeReason`,
       `uretaildata`.`rm_retailvouch`.`outOrg`                 AS `outOrg`,
       `uretaildata`.`rm_retailvouch`.`bGiveawayListGenerated` AS `bGiveawayListGenerated`,
       `uretaildata`.`rm_retailvouch`.`bExtendHeader`          AS `bExtendHeader`,
       `uretaildata`.`rm_retailvouch`.`bExtendBody`            AS `bExtendBody`,
       `uretaildata`.`rm_retailvouch`.`iAmountAdjustNum`       AS `iAmountAdjustNum`,
       `uretaildata`.`rm_retailvouch`.`billNo`                 AS `billNo`,
       `uretaildata`.`rm_retailvouch`.`room`                   AS `room`,
       `uretaildata`.`rm_retailvouch`.`iProcessingState`       AS `iProcessingState`,
       `uretaildata`.`rm_retailvouch`.`cPickCode`              AS `cPickCode`,
       `uretaildata`.`rm_retailvouch`.`oldroom`                AS `oldroom`,
       `uretaildata`.`rm_retailvouch`.`dRoomturnDate`          AS `dRoomturnDate`,
       `uretaildata`.`rm_retailvouch`.`ibillSource`            AS `ibillSource`,
       `uretaildata`.`rm_retailvouch`.`esignature`             AS `esignature`,
       `uretaildata`.`rm_retailvouch`.`iposid`                 AS `iposid`,
       `uretaildata`.`rm_retailvouch`.`cRemark`                AS `cMemo`
from `uretaildata`.`rm_retailvouch`;

-- comment on column v_rm_retailvouch_data.id not supported: ID

-- comment on column v_rm_retailvouch_data.cCode not supported: 单据编号

-- comment on column v_rm_retailvouch_data.vouchdate not supported: 业务日期

-- comment on column v_rm_retailvouch_data.iStoreid not supported: 门店id

-- comment on column v_rm_retailvouch_data.cStoreCode not supported: 门店代码

-- comment on column v_rm_retailvouch_data.cMachineid not supported: 收银机id

-- comment on column v_rm_retailvouch_data.iOrgid not supported: 组织

-- comment on column v_rm_retailvouch_data.tenant_id not supported: 租户

-- comment on column v_rm_retailvouch_data.iDepartmentid not supported: 部门id

-- comment on column v_rm_retailvouch_data.dDate not supported: 业务日期

-- comment on column v_rm_retailvouch_data.iGradeid not supported: 班次id

-- comment on column v_rm_retailvouch_data.iNegative not supported: 退货状态

-- comment on column v_rm_retailvouch_data.bHangUp not supported: 是否挂单

-- comment on column v_rm_retailvouch_data.iMemberid not supported: 会员id

-- comment on column v_rm_retailvouch_data.cMemberCode not supported: 会员号

-- comment on column v_rm_retailvouch_data.iMaker not supported: 制单人

-- comment on column v_rm_retailvouch_data.fGatheringMoney not supported: 收款金额

-- comment on column v_rm_retailvouch_data.iCoRetailid not supported: 退货原单id

-- comment on column v_rm_retailvouch_data.fVIPRate not supported: 会员扣率

-- comment on column v_rm_retailvouch_data.fDiscountRate not supported: 整单折扣率

-- comment on column v_rm_retailvouch_data.fDiscountMoney not supported: 整单折扣额

-- comment on column v_rm_retailvouch_data.fEffaceMoney not supported: 抹零折扣额

-- comment on column v_rm_retailvouch_data.iRelatingRetailid not supported: 关联单据id

-- comment on column v_rm_retailvouch_data.dMakeDate not supported: 制单日期

-- comment on column v_rm_retailvouch_data.fbitSettle not supported: 日结状态

-- comment on column v_rm_retailvouch_data.fPointCurrent not supported: 本单积分

-- comment on column v_rm_retailvouch_data.fPointBalance not supported: 积分余额

-- comment on column v_rm_retailvouch_data.fCardBalance not supported: 储值卡账户余额

-- comment on column v_rm_retailvouch_data.dPlanShipmentDate not supported: 预计发货日期

-- comment on column v_rm_retailvouch_data.dShipmentDate not supported: 实际发货日期

-- comment on column v_rm_retailvouch_data.cRemark not supported: 备注

-- comment on column v_rm_retailvouch_data.iPresellState not supported: 预订单状态

-- comment on column v_rm_retailvouch_data.iDeliveryState not supported: 交货状态

-- comment on column v_rm_retailvouch_data.iPayState not supported: 收款状态

-- comment on column v_rm_retailvouch_data.iTakeway not supported: 提货方式

-- comment on column v_rm_retailvouch_data.bDeliveryModify not supported: 交货时可修改商品

-- comment on column v_rm_retailvouch_data.bPreselllockStock not supported: 预订占用可用量

-- comment on column v_rm_retailvouch_data.fVIPDiscountSum not supported: 会员折扣额

-- comment on column v_rm_retailvouch_data.fPromotionSum not supported: 促销折扣额

-- comment on column v_rm_retailvouch_data.fSceneDiscountSum not supported: 现场折扣额

-- comment on column v_rm_retailvouch_data.fGiftApportion not supported: 优惠券折扣额

-- comment on column v_rm_retailvouch_data.fSaleMoney not supported: 应售金额合计

-- comment on column v_rm_retailvouch_data.fMoneySum not supported: 实销金额合计

-- comment on column v_rm_retailvouch_data.fQuantitySum not supported: 实销数量合计

-- comment on column v_rm_retailvouch_data.fPresellPayMoney not supported: 预定已支付金额合计

-- comment on column v_rm_retailvouch_data.iDeliveryStoreid not supported: 交货门店id

-- comment on column v_rm_retailvouch_data.iDeliveryWarehouseid not supported: 交货仓库

-- comment on column v_rm_retailvouch_data.fPointPay not supported: 抵款积分

-- comment on column v_rm_retailvouch_data.fPointPayMoney not supported: 积分抵款金额

-- comment on column v_rm_retailvouch_data.iBusinesstypeid not supported: 业务类型

-- comment on column v_rm_retailvouch_data.iProfitTo not supported: 预定业绩归属门店

-- comment on column v_rm_retailvouch_data.cRegionCode not supported: 收货地区

-- comment on column v_rm_retailvouch_data.cDeliveradd not supported: 收货人地址

-- comment on column v_rm_retailvouch_data.cCusperson not supported: 收货联系人

-- comment on column v_rm_retailvouch_data.cMobileNo not supported: 收货人手机号

-- comment on column v_rm_retailvouch_data.fCardDisApportion not supported: 回收分摊储值卡折扣金额

-- comment on column v_rm_retailvouch_data.fCardApportion not supported: 回收分摊储值卡实销金额

-- comment on column v_rm_retailvouch_data.bRequireOver not supported: 要货后标记状态

-- comment on column v_rm_retailvouch_data.blocalSale not supported: 本店销售

-- comment on column v_rm_retailvouch_data.blocaDelivery not supported: 本店交货

-- comment on column v_rm_retailvouch_data.iChangeUser not supported: 变更人

-- comment on column v_rm_retailvouch_data.dChangeTime not supported: 变更时间

-- comment on column v_rm_retailvouch_data.bRestore not supported: 是否补单

-- comment on column v_rm_retailvouch_data.create_time not supported: 创建时间

-- comment on column v_rm_retailvouch_data.create_date not supported: 创建日期

-- comment on column v_rm_retailvouch_data.modify_time not supported: 修改时间

-- comment on column v_rm_retailvouch_data.modify_date not supported: 修改日期

-- comment on column v_rm_retailvouch_data.creator not supported: 创建人

-- comment on column v_rm_retailvouch_data.modifier not supported: 修改人

-- comment on column v_rm_retailvouch_data.auditor not supported: 审批人

-- comment on column v_rm_retailvouch_data.audit_time not supported: 审批时间

-- comment on column v_rm_retailvouch_data.audit_date not supported: 审批日期

-- comment on column v_rm_retailvouch_data.tplid not supported: 模板id

-- comment on column v_rm_retailvouch_data.status not supported: 单据状态

-- comment on column v_rm_retailvouch_data.pubts not supported: 时间戳

-- comment on column v_rm_retailvouch_data.fDiscountSum not supported: 折扣额

-- comment on column v_rm_retailvouch_data.fQuoteMoneySum not supported: 零售金额

-- comment on column v_rm_retailvouch_data.fCoQuantitySum not supported: 已退货数量合计

-- comment on column v_rm_retailvouch_data.dPresellDate not supported: 预订日期

-- comment on column v_rm_retailvouch_data.fChangeMoney not supported: 找零金额

-- comment on column v_rm_retailvouch_data.fbitReport not supported: 日报状态

-- comment on column v_rm_retailvouch_data.cLogisticid not supported: 物流公司id

-- comment on column v_rm_retailvouch_data.cLogisticsNo not supported: 快递单号

-- comment on column v_rm_retailvouch_data.cCourierid not supported: 配送人id

-- comment on column v_rm_retailvouch_data.cCourierPhone not supported: 配送人手机

-- comment on column v_rm_retailvouch_data.iOwesState not supported: 赊销状态

-- comment on column v_rm_retailvouch_data.iCustomerid not supported: 客户id

-- comment on column v_rm_retailvouch_data.cGUID not supported: 离线保存ID

-- comment on column v_rm_retailvouch_data.ioffline not supported: 网络状态

-- comment on column v_rm_retailvouch_data.fSellerPointBalance not supported: 商家积分余额

-- comment on column v_rm_retailvouch_data.fSellerPointCurrent not supported: 本单商家积分

-- comment on column v_rm_retailvouch_data.fSellerPointPay not supported: 商家抵款积分

-- comment on column v_rm_retailvouch_data.printCount not supported: 打印次数

-- comment on column v_rm_retailvouch_data.iEInvoiceState not supported: 开票状态

-- comment on column v_rm_retailvouch_data.cEInvoiceURL not supported: 开票网址

-- comment on column v_rm_retailvouch_data.bCoEInvoiceOver not supported: 退货行已开票

-- comment on column v_rm_retailvouch_data.cRetailURL not supported: 零售网址

-- comment on column v_rm_retailvouch_data.iCoEInvoiceWay not supported: 非原单退货行处理方式

-- comment on column v_rm_retailvouch_data.dEInvoiceEndData not supported: 开票截至日期

-- comment on column v_rm_retailvouch_data.iPrcsStatus not supported: 加工状态

-- comment on column v_rm_retailvouch_data.handMakeInvoicePeo not supported: 手工开票人

-- comment on column v_rm_retailvouch_data.handMakeInvoiceTime not supported: 手工开票时间

-- comment on column v_rm_retailvouch_data.bAmountAdjustment not supported: 金额调整

-- comment on column v_rm_retailvouch_data.bGiveawayList not supported: 赠品单

-- comment on column v_rm_retailvouch_data.bcustomizedOrder not supported: 来源定制单

-- comment on column v_rm_retailvouch_data.bReturnStore not supported: 退回门店

-- comment on column v_rm_retailvouch_data.iReturnWarehousid not supported: 退货仓库id

-- comment on column v_rm_retailvouch_data.iGiveawayListRetailid not supported: 赠品单关联零售单id

-- comment on column v_rm_retailvouch_data.iAmountAdjustRetailid not supported: 金额调整关联零售单号

-- comment on column v_rm_retailvouch_data.iGatheringType not supported: 收款模式

-- comment on column v_rm_retailvouch_data.bUnsubscribe not supported: 可退订

-- comment on column v_rm_retailvouch_data.unsubscribeReason not supported: 可否退订原因

-- comment on column v_rm_retailvouch_data.outOrg not supported: 发货组织id

-- comment on column v_rm_retailvouch_data.bGiveawayListGenerated not supported: 是否已生成赠品单

-- comment on column v_rm_retailvouch_data.bExtendHeader not supported: 是否扩展表头

-- comment on column v_rm_retailvouch_data.bExtendBody not supported: 是否扩展表体

-- comment on column v_rm_retailvouch_data.iAmountAdjustNum not supported: 金额调整次数

-- comment on column v_rm_retailvouch_data.billNo not supported: 外部系统单号

-- comment on column v_rm_retailvouch_data.room not supported: 房间id

-- comment on column v_rm_retailvouch_data.iProcessingState not supported: 处理状态

-- comment on column v_rm_retailvouch_data.cPickCode not supported: 提货码

-- comment on column v_rm_retailvouch_data.oldroom not supported: 原房间id

-- comment on column v_rm_retailvouch_data.dRoomturnDate not supported: 转房时间

-- comment on column v_rm_retailvouch_data.ibillSource not supported: 单据来源

-- comment on column v_rm_retailvouch_data.esignature not supported: 电子签名

-- comment on column v_rm_retailvouch_data.iposid not supported: 终端设备id

-- comment on column v_rm_retailvouch_data.cMemo not supported: 备注

