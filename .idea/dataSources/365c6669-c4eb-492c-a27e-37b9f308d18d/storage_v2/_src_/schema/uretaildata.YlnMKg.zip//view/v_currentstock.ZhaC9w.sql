create definer = root@`%` view v_currentstock as
select `a`.`iWarehouseId`  AS `iWarehouseId`,
       `a`.`fCurrentQty`   AS `fCurrentQty`,
       `a`.`fAvailableQty` AS `fAvailableQty`,
       `a`.`fInnoticeQty`  AS `fInnoticeQty`,
       `a`.`fOutnoticeQty` AS `fOutnoticeQty`,
       `a`.`fPreretailQty` AS `fPreretailQty`,
       `a`.`iUnitId`       AS `iUnitId`,
       `a`.`tenant_id`     AS `tenant_id`,
       `a`.`define1`       AS `free1`,
       `a`.`define2`       AS `free2`,
       `a`.`define3`       AS `free3`,
       `a`.`define4`       AS `free4`,
       `a`.`define5`       AS `free5`,
       `a`.`define6`       AS `free6`,
       `a`.`define7`       AS `free7`,
       `a`.`define8`       AS `free8`,
       `a`.`define9`       AS `free9`,
       `a`.`define10`      AS `free10`,
       `a`.`iStoreID`      AS `iStoreID`,
       `a`.`iProductid`    AS `iProductid`,
       `a`.`iProductSkuid` AS `iProductSkuid`,
       `a`.`sBatchNo`      AS `sBatchNo`,
       `a`.`dProduceDate`  AS `dProduceDate`,
       `a`.`dInvalidDate`  AS `dInvalidDate`,
       `a`.`id`            AS `id`,
       `a`.`define1`       AS `define1`,
       `a`.`define2`       AS `define2`,
       `a`.`define3`       AS `define3`,
       `a`.`define4`       AS `define4`,
       `a`.`define5`       AS `define5`,
       `a`.`define6`       AS `define6`,
       `a`.`define7`       AS `define7`,
       `a`.`define8`       AS `define8`,
       `a`.`define9`       AS `define9`,
       `a`.`define10`      AS `define10`,
       `a`.`pubts`         AS `pubts`,
       `b`.`id`            AS `batchnoid`,
       `a`.`fAvailableQty` AS `costprice`,
       `a`.`fAvailableQty` AS `costmoney`,
       `a`.`fAvailableQty` AS `stockmoney`
from (`uretaildata`.`currentstock` `a`
         left join `uretaildata`.`batchno` `b`
                   on (((`a`.`iProductSkuid` = `b`.`iProductSkuid`) and (`a`.`sBatchNo` = `b`.`sBatchNo`))));

-- comment on column v_currentstock.fCurrentQty not supported: 现存数量

-- comment on column v_currentstock.fAvailableQty not supported: 可用数量

-- comment on column v_currentstock.fInnoticeQty not supported: 入库通知数量

-- comment on column v_currentstock.fOutnoticeQty not supported: 出库通知数量

-- comment on column v_currentstock.fPreretailQty not supported: 预订零售数量

-- comment on column v_currentstock.iUnitId not supported: 销售单位id

-- comment on column v_currentstock.tenant_id not supported: 租户

-- comment on column v_currentstock.free1 not supported: 自定义项1

-- comment on column v_currentstock.free2 not supported: 自定义项2

-- comment on column v_currentstock.free3 not supported: 自定义项3

-- comment on column v_currentstock.free4 not supported: 自定义项4

-- comment on column v_currentstock.free5 not supported: 自定义项5

-- comment on column v_currentstock.free6 not supported: 自定义项6

-- comment on column v_currentstock.free7 not supported: 自定义项7

-- comment on column v_currentstock.free8 not supported: 自定义项8

-- comment on column v_currentstock.free9 not supported: 自定义项9

-- comment on column v_currentstock.free10 not supported: 自定义项10

-- comment on column v_currentstock.iStoreID not supported: 门店ID

-- comment on column v_currentstock.dProduceDate not supported: 生产日期

-- comment on column v_currentstock.dInvalidDate not supported: 失效日期

-- comment on column v_currentstock.id not supported: ID

-- comment on column v_currentstock.define1 not supported: 自定义项1

-- comment on column v_currentstock.define2 not supported: 自定义项2

-- comment on column v_currentstock.define3 not supported: 自定义项3

-- comment on column v_currentstock.define4 not supported: 自定义项4

-- comment on column v_currentstock.define5 not supported: 自定义项5

-- comment on column v_currentstock.define6 not supported: 自定义项6

-- comment on column v_currentstock.define7 not supported: 自定义项7

-- comment on column v_currentstock.define8 not supported: 自定义项8

-- comment on column v_currentstock.define9 not supported: 自定义项9

-- comment on column v_currentstock.define10 not supported: 自定义项10

-- comment on column v_currentstock.pubts not supported: 时间戳

-- comment on column v_currentstock.batchnoid not supported: ID

-- comment on column v_currentstock.costprice not supported: 可用数量

-- comment on column v_currentstock.costmoney not supported: 可用数量

-- comment on column v_currentstock.stockmoney not supported: 可用数量

