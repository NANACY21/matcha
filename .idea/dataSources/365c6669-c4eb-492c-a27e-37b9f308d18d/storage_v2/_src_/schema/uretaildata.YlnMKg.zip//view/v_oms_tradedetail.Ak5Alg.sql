create view v_oms_tradedetail as
(
select `ec`.`dvdate`        AS `invaliddate`,
       `ec`.`dmdate`        AS `producedate`,
       `ec`.`iquantity`     AS `qty`,
       `ec`.`cwhcode`       AS `warehouseId`,
       `ec`.`product`       AS `productId`,
       `ec`.`citemid`       AS `productSkuId`,
       `ec`.`cbatch`        AS `sBatchNo`,
       `detail`.`parentid`  AS `parentid`,
       `detail`.`id`        AS `id`,
       NULL                 AS `iGoodsPositionId`,
       `detail`.`saleserId` AS `operator`
from (`omstest`.`oms_tradedetail` `detail`
         join `omstest`.`ec_shipdetail` `ec` on ((`detail`.`id` = `ec`.`bodyid`))));

