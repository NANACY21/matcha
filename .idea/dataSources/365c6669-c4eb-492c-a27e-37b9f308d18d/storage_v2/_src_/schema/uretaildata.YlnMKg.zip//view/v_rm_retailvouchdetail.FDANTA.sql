create definer = root@`%` view v_rm_retailvouchdetail as
select `uretaildata`.`rm_retailvouchdetail`.`iRetailid`               AS `iRetailid`,
       `uretaildata`.`rm_retailvouchdetail`.`cProductid`              AS `cProductid`,
       `uretaildata`.`rm_retailvouchdetail`.`cProductid`              AS `iProductid`,
       `uretaildata`.`rm_retailvouchdetail`.`iSKUid`                  AS `iSKUid`,
       `uretaildata`.`rm_retailvouchdetail`.`iSKUid`                  AS `iProductSkuid`,
       `uretaildata`.`rm_retailvouchdetail`.`iWarehouseid`            AS `iWarehouseid`,
       `uretaildata`.`rm_retailvouchdetail`.`cBatchNo`                AS `sBatchno`,
       `uretaildata`.`rm_retailvouchdetail`.`iBathid`                 AS `iBathid`,
       `uretaildata`.`rm_retailvouchdetail`.`dProduceDate`            AS `dProduceDate`,
       `uretaildata`.`rm_retailvouchdetail`.`dInvalidDate`            AS `dInvalidDate`,
       `uretaildata`.`rm_retailvouchdetail`.`fQuantity`               AS `fQuantity`,
       `uretaildata`.`rm_retailvouchdetail`.`fMoney`                  AS `fMoney`,
       `uretaildata`.`rm_retailvouchdetail`.`fQuotePrice`             AS `fQuotePrice`,
       `uretaildata`.`rm_retailvouchdetail`.`fVIPPrice`               AS `fVIPPrice`,
       `uretaildata`.`rm_retailvouchdetail`.`fPrice`                  AS `fPrice`,
       `uretaildata`.`rm_retailvouchdetail`.`fDiscountRate`           AS `fDiscountRate`,
       `uretaildata`.`rm_retailvouchdetail`.`fDiscount`               AS `fDiscount`,
       `uretaildata`.`rm_retailvouchdetail`.`cMemo`                   AS `cMemo`,
       `uretaildata`.`rm_retailvouchdetail`.`iOrder`                  AS `iOrder`,
       `uretaildata`.`rm_retailvouchdetail`.`iEmployeeid`             AS `iEmployeeid`,
       `uretaildata`.`rm_retailvouchdetail`.`iSuperior`               AS `iSuperior`,
       `uretaildata`.`rm_retailvouchdetail`.`iCoRetailDetailId`       AS `iCoRetailDetailId`,
       `uretaildata`.`rm_retailvouchdetail`.`fCoQuantity`             AS `fCoQuantity`,
       `uretaildata`.`rm_retailvouchdetail`.`fCoMoney`                AS `fCoMoney`,
       `uretaildata`.`rm_retailvouchdetail`.`fCoDiscount`             AS `fCoDiscount`,
       `uretaildata`.`rm_retailvouchdetail`.`fSceneDiscountRate`      AS `fSceneDiscountRate`,
       `uretaildata`.`rm_retailvouchdetail`.`fSceneDiscount`          AS `fSceneDiscount`,
       `uretaildata`.`rm_retailvouchdetail`.`bSpecial`                AS `bSpecial`,
       `uretaildata`.`rm_retailvouchdetail`.`fRealPrice`              AS `fRealPrice`,
       `uretaildata`.`rm_retailvouchdetail`.`iProductModel`           AS `iProductModel`,
       `uretaildata`.`rm_retailvouchdetail`.`fEffaceMoney`            AS `fEffaceMoney`,
       `uretaildata`.`rm_retailvouchdetail`.`fSceneDiscountType`      AS `fSceneDiscountType`,
       `uretaildata`.`rm_retailvouchdetail`.`fSceneDiscountPrice`     AS `fSceneDiscountPrice`,
       `uretaildata`.`rm_retailvouchdetail`.`fPromotionPrice`         AS `fPromotionPrice`,
       `uretaildata`.`rm_retailvouchdetail`.`fGiftTokenDiscount`      AS `fGiftTokenDiscount`,
       `uretaildata`.`rm_retailvouchdetail`.`fPointPayDiscount`       AS `fPointPayDiscount`,
       `uretaildata`.`rm_retailvouchdetail`.`iBackid`                 AS `iBackid`,
       `uretaildata`.`rm_retailvouchdetail`.`iSupperOperatorid`       AS `iSupperOperatorid`,
       `uretaildata`.`rm_retailvouchdetail`.`fCardDisApportion`       AS `fCardDisApportion`,
       `uretaildata`.`rm_retailvouchdetail`.`fCardApportion`          AS `fCardApportion`,
       `uretaildata`.`rm_retailvouchdetail`.`fPointCurrent`           AS `fPointCurrent`,
       `uretaildata`.`rm_retailvouchdetail`.`bCanDiscount`            AS `bCanDiscount`,
       `uretaildata`.`rm_retailvouchdetail`.`iPromotionProduct`       AS `iPromotionProduct`,
       `uretaildata`.`rm_retailvouchdetail`.`fPointMultiple`          AS `fPointMultiple`,
       `uretaildata`.`rm_retailvouchdetail`.`fPointGive`              AS `fPointGive`,
       `uretaildata`.`rm_retailvouchdetail`.`fPointDiscount`          AS `fPointDiscount`,
       `uretaildata`.`rm_retailvouchdetail`.`cProductPath`            AS `cProductPath`,
       `uretaildata`.`rm_retailvouchdetail`.`cFree1`                  AS `cFree1`,
       `uretaildata`.`rm_retailvouchdetail`.`cFree2`                  AS `cFree2`,
       `uretaildata`.`rm_retailvouchdetail`.`cFree3`                  AS `cFree3`,
       `uretaildata`.`rm_retailvouchdetail`.`cFree4`                  AS `cFree4`,
       `uretaildata`.`rm_retailvouchdetail`.`cFree5`                  AS `cFree5`,
       `uretaildata`.`rm_retailvouchdetail`.`cFree6`                  AS `cFree6`,
       `uretaildata`.`rm_retailvouchdetail`.`cFree7`                  AS `cFree7`,
       `uretaildata`.`rm_retailvouchdetail`.`cFree8`                  AS `cFree8`,
       `uretaildata`.`rm_retailvouchdetail`.`cFree9`                  AS `cFree9`,
       `uretaildata`.`rm_retailvouchdetail`.`cFree10`                 AS `cFree10`,
       `uretaildata`.`rm_retailvouchdetail`.`dCoSaleDate`             AS `dCoSaleDate`,
       `uretaildata`.`rm_retailvouchdetail`.`create_time`             AS `create_time`,
       `uretaildata`.`rm_retailvouchdetail`.`create_date`             AS `create_date`,
       `uretaildata`.`rm_retailvouchdetail`.`modify_time`             AS `modify_time`,
       `uretaildata`.`rm_retailvouchdetail`.`modify_date`             AS `modify_date`,
       `uretaildata`.`rm_retailvouchdetail`.`creator`                 AS `creator`,
       `uretaildata`.`rm_retailvouchdetail`.`modifier`                AS `modifier`,
       `uretaildata`.`rm_retailvouchdetail`.`id`                      AS `id`,
       `uretaildata`.`rm_retailvouchdetail`.`pubts`                   AS `pubts`,
       `uretaildata`.`rm_retailvouchdetail`.`fPromotionDiscount`      AS `fPromotionDiscount`,
       `uretaildata`.`rm_retailvouchdetail`.`fQuoteMoney`             AS `fQuoteMoney`,
       `uretaildata`.`rm_retailvouchdetail`.`fVIPDiscount`            AS `fVIPDiscount`,
       `uretaildata`.`rm_retailvouchdetail`.`fVIPRate`                AS `fVIPRate`,
       `uretaildata`.`rm_retailvouchdetail`.`fBackOutQuantity`        AS `fBackOutQuantity`,
       `uretaildata`.`rm_retailvouchdetail`.`iRelatingRetailDetailId` AS `iRelatingRetailDetailId`,
       `uretaildata`.`rm_retailvouchdetail`.`iGoodsPositionId`        AS `iGoodsPositionId`
from `uretaildata`.`rm_retailvouchdetail`;

-- comment on column v_rm_retailvouchdetail.iRetailid not supported: 零售单id

-- comment on column v_rm_retailvouchdetail.cProductid not supported: 商品id

-- comment on column v_rm_retailvouchdetail.iProductid not supported: 商品id

-- comment on column v_rm_retailvouchdetail.iSKUid not supported: 商品SKUID

-- comment on column v_rm_retailvouchdetail.iProductSkuid not supported: 商品SKUID

-- comment on column v_rm_retailvouchdetail.iWarehouseid not supported: 仓库id

-- comment on column v_rm_retailvouchdetail.iBathid not supported: 批号id

-- comment on column v_rm_retailvouchdetail.dProduceDate not supported: 生产日期

-- comment on column v_rm_retailvouchdetail.dInvalidDate not supported: 失效日期

-- comment on column v_rm_retailvouchdetail.fQuantity not supported: 数量

-- comment on column v_rm_retailvouchdetail.fMoney not supported: 金额

-- comment on column v_rm_retailvouchdetail.fQuotePrice not supported: 零售价

-- comment on column v_rm_retailvouchdetail.fVIPPrice not supported: 会员价

-- comment on column v_rm_retailvouchdetail.fPrice not supported: 单价

-- comment on column v_rm_retailvouchdetail.fDiscountRate not supported: 扣率

-- comment on column v_rm_retailvouchdetail.fDiscount not supported: 扣额

-- comment on column v_rm_retailvouchdetail.cMemo not supported: 备注

-- comment on column v_rm_retailvouchdetail.iOrder not supported: 顺序号

-- comment on column v_rm_retailvouchdetail.iEmployeeid not supported: 营业员id

-- comment on column v_rm_retailvouchdetail.iSuperior not supported: 营业员上级id

-- comment on column v_rm_retailvouchdetail.iCoRetailDetailId not supported: 原单退货原单子表id

-- comment on column v_rm_retailvouchdetail.fCoQuantity not supported: 退货数量

-- comment on column v_rm_retailvouchdetail.fCoMoney not supported: 退货金额

-- comment on column v_rm_retailvouchdetail.fCoDiscount not supported: 退货折扣

-- comment on column v_rm_retailvouchdetail.fSceneDiscountRate not supported: 现场折扣率

-- comment on column v_rm_retailvouchdetail.fSceneDiscount not supported: 现场折扣额

-- comment on column v_rm_retailvouchdetail.bSpecial not supported: 是否特价商品

-- comment on column v_rm_retailvouchdetail.fRealPrice not supported: 分摊价

-- comment on column v_rm_retailvouchdetail.iProductModel not supported: 商品模式

-- comment on column v_rm_retailvouchdetail.fEffaceMoney not supported: 抹零折扣额

-- comment on column v_rm_retailvouchdetail.fSceneDiscountType not supported: 现场折扣类型

-- comment on column v_rm_retailvouchdetail.fSceneDiscountPrice not supported: 现场折扣价格

-- comment on column v_rm_retailvouchdetail.fPromotionPrice not supported: 促销价格

-- comment on column v_rm_retailvouchdetail.fGiftTokenDiscount not supported: 礼券折扣额

-- comment on column v_rm_retailvouchdetail.fPointPayDiscount not supported: 积分折扣额

-- comment on column v_rm_retailvouchdetail.iBackid not supported: 退货原因id

-- comment on column v_rm_retailvouchdetail.iSupperOperatorid not supported: 折扣授权人

-- comment on column v_rm_retailvouchdetail.fCardDisApportion not supported: 回收分摊储值卡折扣金额

-- comment on column v_rm_retailvouchdetail.fCardApportion not supported: 回收分摊储值卡实销金额

-- comment on column v_rm_retailvouchdetail.fPointCurrent not supported: 本次明细行积分

-- comment on column v_rm_retailvouchdetail.bCanDiscount not supported: 参与折扣计算

-- comment on column v_rm_retailvouchdetail.iPromotionProduct not supported: 促销品

-- comment on column v_rm_retailvouchdetail.fPointMultiple not supported: N倍积分

-- comment on column v_rm_retailvouchdetail.fPointGive not supported: 赠送积分

-- comment on column v_rm_retailvouchdetail.fPointDiscount not supported: 分摊抵款积分

-- comment on column v_rm_retailvouchdetail.cProductPath not supported: 商品类别全路径

-- comment on column v_rm_retailvouchdetail.cFree1 not supported: 商品规格1

-- comment on column v_rm_retailvouchdetail.cFree2 not supported: 商品规格2

-- comment on column v_rm_retailvouchdetail.cFree3 not supported: 商品规格3

-- comment on column v_rm_retailvouchdetail.cFree4 not supported: 商品规格4

-- comment on column v_rm_retailvouchdetail.cFree5 not supported: 商品规格5

-- comment on column v_rm_retailvouchdetail.cFree6 not supported: 商品规格6

-- comment on column v_rm_retailvouchdetail.cFree7 not supported: 商品规格7

-- comment on column v_rm_retailvouchdetail.cFree8 not supported: 商品规格8

-- comment on column v_rm_retailvouchdetail.cFree9 not supported: 商品规格9

-- comment on column v_rm_retailvouchdetail.cFree10 not supported: 商品规格10

-- comment on column v_rm_retailvouchdetail.dCoSaleDate not supported: 原销售日期

-- comment on column v_rm_retailvouchdetail.create_time not supported: 创建时间

-- comment on column v_rm_retailvouchdetail.create_date not supported: 创建日期

-- comment on column v_rm_retailvouchdetail.modify_time not supported: 修改时间

-- comment on column v_rm_retailvouchdetail.modify_date not supported: 修改日期

-- comment on column v_rm_retailvouchdetail.creator not supported: 创建人

-- comment on column v_rm_retailvouchdetail.modifier not supported: 修改人

-- comment on column v_rm_retailvouchdetail.id not supported: ID

-- comment on column v_rm_retailvouchdetail.pubts not supported: 时间戳

-- comment on column v_rm_retailvouchdetail.fPromotionDiscount not supported: 促销折扣额

-- comment on column v_rm_retailvouchdetail.fQuoteMoney not supported: 零售金额

-- comment on column v_rm_retailvouchdetail.fVIPDiscount not supported: 会员折扣额

-- comment on column v_rm_retailvouchdetail.fVIPRate not supported: 会员折扣率%

-- comment on column v_rm_retailvouchdetail.fBackOutQuantity not supported: 后台出库数量

-- comment on column v_rm_retailvouchdetail.iRelatingRetailDetailId not supported: 关联单据子表id

