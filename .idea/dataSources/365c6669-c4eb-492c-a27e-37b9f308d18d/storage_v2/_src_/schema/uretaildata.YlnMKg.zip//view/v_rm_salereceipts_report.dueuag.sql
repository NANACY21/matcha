create definer = root@`%` view v_rm_salereceipts_report as
select `uretaildata`.`rm_retailvouch`.`id`                   AS `id`,
       `uretaildata`.`rm_retailvouch`.`cCode`                AS `cCode`,
       `uretaildata`.`rm_retailvouch`.`vouchdate`            AS `vouchdate`,
       `uretaildata`.`rm_retailvouch`.`iStoreid`             AS `iStoreid`,
       `uretaildata`.`rm_retailvouch`.`cStoreCode`           AS `cStoreCode`,
       `uretaildata`.`rm_retailvouch`.`cMachineid`           AS `cMachineid`,
       `uretaildata`.`rm_retailvouch`.`iOrgid`               AS `iOrgid`,
       `uretaildata`.`rm_retailvouch`.`tenant_id`            AS `tenant_id`,
       `uretaildata`.`rm_retailvouch`.`iDepartmentid`        AS `iDepartmentid`,
       `uretaildata`.`rm_retailvouch`.`dDate`                AS `dDate`,
       `uretaildata`.`rm_retailvouch`.`iGradeid`             AS `iGradeid`,
       `uretaildata`.`rm_retailvouch`.`iNegative`            AS `iNegative`,
       `uretaildata`.`rm_retailvouch`.`bHangUp`              AS `bHangUp`,
       `uretaildata`.`rm_retailvouch`.`iMemberid`            AS `iMemberid`,
       `uretaildata`.`rm_retailvouch`.`cMemberCode`          AS `cMemberCode`,
       `uretaildata`.`rm_retailvouch`.`iMaker`               AS `iMaker`,
       `uretaildata`.`rm_retailvouch`.`fGatheringMoney`      AS `fGatheringMoney`,
       `uretaildata`.`rm_retailvouch`.`iCoRetailid`          AS `iCoRetailid`,
       `uretaildata`.`rm_retailvouch`.`fVIPRate`             AS `fVIPRate`,
       `uretaildata`.`rm_retailvouch`.`fDiscountRate`        AS `fDiscountRate`,
       `uretaildata`.`rm_retailvouch`.`fDiscountMoney`       AS `fDiscountMoney`,
       `uretaildata`.`rm_retailvouch`.`fEffaceMoney`         AS `fEffaceMoney`,
       `uretaildata`.`rm_retailvouch`.`iRelatingRetailid`    AS `iRelatingRetailid`,
       `uretaildata`.`rm_retailvouch`.`dMakeDate`            AS `dMakeDate`,
       `uretaildata`.`rm_retailvouch`.`fbitSettle`           AS `retailvouchfbitSettle`,
       `uretaildata`.`rm_gatheringvouch`.`bSettle`           AS `gatheringvouchbSettle`,
       if(isnull(`uretaildata`.`rm_gatheringvouch`.`bSettle`), `uretaildata`.`rm_retailvouch`.`fbitSettle`,
          `uretaildata`.`rm_gatheringvouch`.`bSettle`)       AS `fbitSettle`,
       `uretaildata`.`rm_retailvouch`.`fPointCurrent`        AS `fPointCurrent`,
       `uretaildata`.`rm_retailvouch`.`fPointBalance`        AS `fPointBalance`,
       `uretaildata`.`rm_retailvouch`.`fCardBalance`         AS `fCardBalance`,
       `uretaildata`.`rm_retailvouch`.`dPlanShipmentDate`    AS `dPlanShipmentDate`,
       `uretaildata`.`rm_retailvouch`.`dShipmentDate`        AS `dShipmentDate`,
       `uretaildata`.`rm_retailvouch`.`cRemark`              AS `cRemark`,
       `uretaildata`.`rm_retailvouch`.`iPresellState`        AS `iPresellState`,
       `uretaildata`.`rm_retailvouch`.`iDeliveryState`       AS `iDeliveryState`,
       `uretaildata`.`rm_retailvouch`.`iPayState`            AS `iPayState`,
       `uretaildata`.`rm_retailvouch`.`iTakeway`             AS `iTakeway`,
       `uretaildata`.`rm_retailvouch`.`bDeliveryModify`      AS `bDeliveryModify`,
       `uretaildata`.`rm_retailvouch`.`bPreselllockStock`    AS `bPreselllockStock`,
       `uretaildata`.`rm_retailvouch`.`fVIPDiscountSum`      AS `fVIPDiscountSum`,
       `uretaildata`.`rm_retailvouch`.`fPromotionSum`        AS `fPromotionSum`,
       `uretaildata`.`rm_retailvouch`.`fSceneDiscountSum`    AS `fSceneDiscountSum`,
       `uretaildata`.`rm_retailvouch`.`fGiftApportion`       AS `fGiftApportion`,
       `uretaildata`.`rm_retailvouch`.`fSaleMoney`           AS `fSaleMoney`,
       `uretaildata`.`rm_retailvouch`.`fMoneySum`            AS `fMoneySum`,
       `uretaildata`.`rm_retailvouch`.`fQuantitySum`         AS `fQuantitySum`,
       `uretaildata`.`rm_retailvouch`.`fPresellPayMoney`     AS `fPresellPayMoney`,
       `uretaildata`.`rm_retailvouch`.`iDeliveryStoreid`     AS `iDeliveryStoreid`,
       `uretaildata`.`rm_retailvouch`.`iDeliveryWarehouseid` AS `iDeliveryWarehouseid`,
       `uretaildata`.`rm_retailvouch`.`fPointPay`            AS `fPointPay`,
       `uretaildata`.`rm_retailvouch`.`fPointPayMoney`       AS `fPointPayMoney`,
       `uretaildata`.`rm_retailvouch`.`iBusinesstypeid`      AS `iBusinesstypeid`,
       `uretaildata`.`rm_retailvouch`.`iProfitTo`            AS `iProfitTo`,
       `uretaildata`.`rm_retailvouch`.`cRegionCode`          AS `cRegionCode`,
       `uretaildata`.`rm_retailvouch`.`cDeliveradd`          AS `cDeliveradd`,
       `uretaildata`.`rm_retailvouch`.`cCusperson`           AS `cCusperson`,
       `uretaildata`.`rm_retailvouch`.`cMobileNo`            AS `cMobileNo`,
       `uretaildata`.`rm_retailvouch`.`fCardDisApportion`    AS `fCardDisApportion`,
       `uretaildata`.`rm_retailvouch`.`fCardApportion`       AS `fCardApportion`,
       `uretaildata`.`rm_retailvouch`.`bRequireOver`         AS `bRequireOver`,
       `uretaildata`.`rm_retailvouch`.`blocalSale`           AS `blocalSale`,
       `uretaildata`.`rm_retailvouch`.`blocaDelivery`        AS `blocaDelivery`,
       `uretaildata`.`rm_retailvouch`.`iChangeUser`          AS `iChangeUser`,
       `uretaildata`.`rm_retailvouch`.`dChangeTime`          AS `dChangeTime`,
       `uretaildata`.`rm_retailvouch`.`bRestore`             AS `bRestore`,
       `uretaildata`.`rm_retailvouch`.`create_time`          AS `create_time`,
       `uretaildata`.`rm_retailvouch`.`create_date`          AS `create_date`,
       `uretaildata`.`rm_retailvouch`.`modify_time`          AS `modify_time`,
       `uretaildata`.`rm_retailvouch`.`modify_date`          AS `modify_date`,
       `uretaildata`.`rm_retailvouch`.`creator`              AS `creator`,
       `uretaildata`.`rm_retailvouch`.`modifier`             AS `modifier`,
       `uretaildata`.`rm_retailvouch`.`auditor`              AS `auditor`,
       `uretaildata`.`rm_retailvouch`.`audit_time`           AS `audit_time`,
       `uretaildata`.`rm_retailvouch`.`audit_date`           AS `audit_date`,
       `uretaildata`.`rm_retailvouch`.`tplid`                AS `tplid`,
       `uretaildata`.`rm_retailvouch`.`status`               AS `status`,
       `uretaildata`.`rm_retailvouch`.`pubts`                AS `pubts`,
       `uretaildata`.`rm_retailvouch`.`fQuoteMoneySum`       AS `fQuoteMoneySum`,
       `uretaildata`.`rm_retailvouch`.`fDiscountSum`         AS `fDiscountSum`,
       `uretaildata`.`rm_retailvouch`.`fCoQuantitySum`       AS `fCoQuantitySum`,
       `uretaildata`.`rm_retailvouch`.`dPresellDate`         AS `dPresellDate`,
       `uretaildata`.`rm_retailvouch`.`fChangeMoney`         AS `fChangeMoney`,
       `uretaildata`.`rm_retailvouch`.`fCoDiscountSum`       AS `fCoDiscountSum`,
       `uretaildata`.`rm_retailvouch`.`fbitReport`           AS `fbitReport`,
       `uretaildata`.`rm_retailvouch`.`iOwesState`           AS `iOwesState`,
       `uretaildata`.`rm_retailvouch`.`iCustomerid`          AS `iCustomerid`,
       `uretaildata`.`rm_gatheringvouchdetail`.`id`          AS `retailVouchGatherings`,
       `uretaildata`.`rm_gatheringvouch`.`id`                AS `retailVouchGathering`,
       `uretaildata`.`rm_paymentwritedetail`.`id`            AS `paymentwritedetails`,
       `uretaildata`.`rm_paymentwritedetail`.`isSumLine`     AS `isSumLine`
from ((((`uretaildata`.`rm_retailvouch` left join `uretaildata`.`rm_paymentwrite` on ((
        (`uretaildata`.`rm_retailvouch`.`id` = `uretaildata`.`rm_paymentwrite`.`iRetailid`) and
        (`uretaildata`.`rm_retailvouch`.`tenant_id` =
         `uretaildata`.`rm_paymentwrite`.`tenant_id`)))) left join `uretaildata`.`rm_paymentwritedetail` on ((
        (`uretaildata`.`rm_retailvouch`.`id` = `uretaildata`.`rm_paymentwritedetail`.`iRetailid`) and
        (`uretaildata`.`rm_paymentwrite`.`id` =
         `uretaildata`.`rm_paymentwritedetail`.`ipaymentwriteid`)))) left join `uretaildata`.`rm_gatheringvouch` on ((
        (`uretaildata`.`rm_paymentwrite`.`iGatheringid` = `uretaildata`.`rm_gatheringvouch`.`id`) and
        (`uretaildata`.`rm_gatheringvouch`.`tenant_id` = `uretaildata`.`rm_paymentwrite`.`tenant_id`))))
         left join `uretaildata`.`rm_gatheringvouchdetail` on (((`uretaildata`.`rm_gatheringvouch`.`id` =
                                                                 `uretaildata`.`rm_gatheringvouchdetail`.`iGatheringid`) and
                                                                (`uretaildata`.`rm_paymentwritedetail`.`iGatheringdetailid` =
                                                                 `uretaildata`.`rm_gatheringvouchdetail`.`id`))))
where (`uretaildata`.`rm_retailvouch`.`iPresellState` <> 5);

-- comment on column v_rm_salereceipts_report.id not supported: ID

-- comment on column v_rm_salereceipts_report.cCode not supported: 单据编号

-- comment on column v_rm_salereceipts_report.vouchdate not supported: 单据日期

-- comment on column v_rm_salereceipts_report.iStoreid not supported: 门店id

-- comment on column v_rm_salereceipts_report.cStoreCode not supported: 门店代码

-- comment on column v_rm_salereceipts_report.cMachineid not supported: 收银机id

-- comment on column v_rm_salereceipts_report.iOrgid not supported: 组织

-- comment on column v_rm_salereceipts_report.tenant_id not supported: 租户

-- comment on column v_rm_salereceipts_report.iDepartmentid not supported: 部门id

-- comment on column v_rm_salereceipts_report.dDate not supported: 业务日期

-- comment on column v_rm_salereceipts_report.iGradeid not supported: 班次id

-- comment on column v_rm_salereceipts_report.iNegative not supported: 退货状态

-- comment on column v_rm_salereceipts_report.bHangUp not supported: 是否挂单

-- comment on column v_rm_salereceipts_report.iMemberid not supported: 会员id

-- comment on column v_rm_salereceipts_report.cMemberCode not supported: 会员号

-- comment on column v_rm_salereceipts_report.iMaker not supported: 制单人

-- comment on column v_rm_salereceipts_report.fGatheringMoney not supported: 收款金额

-- comment on column v_rm_salereceipts_report.iCoRetailid not supported: 退货原单id

-- comment on column v_rm_salereceipts_report.fVIPRate not supported: 会员扣率

-- comment on column v_rm_salereceipts_report.fDiscountRate not supported: 整单折扣率

-- comment on column v_rm_salereceipts_report.fDiscountMoney not supported: 整单折扣额

-- comment on column v_rm_salereceipts_report.fEffaceMoney not supported: 抹零折扣额

-- comment on column v_rm_salereceipts_report.iRelatingRetailid not supported: 关联单据id

-- comment on column v_rm_salereceipts_report.dMakeDate not supported: 制单日期

-- comment on column v_rm_salereceipts_report.retailvouchfbitSettle not supported: 日结状态

-- comment on column v_rm_salereceipts_report.gatheringvouchbSettle not supported: 日结状态

-- comment on column v_rm_salereceipts_report.fPointCurrent not supported: 本单积分

-- comment on column v_rm_salereceipts_report.fPointBalance not supported: 积分余额

-- comment on column v_rm_salereceipts_report.fCardBalance not supported: 储值卡账户余额

-- comment on column v_rm_salereceipts_report.dPlanShipmentDate not supported: 预计发货日期

-- comment on column v_rm_salereceipts_report.dShipmentDate not supported: 实际发货日期

-- comment on column v_rm_salereceipts_report.cRemark not supported: 备注

-- comment on column v_rm_salereceipts_report.iPresellState not supported: 预订单状态

-- comment on column v_rm_salereceipts_report.iDeliveryState not supported: 交货状态

-- comment on column v_rm_salereceipts_report.iPayState not supported: 收款状态

-- comment on column v_rm_salereceipts_report.iTakeway not supported: 提货方式

-- comment on column v_rm_salereceipts_report.bDeliveryModify not supported: 交货时可修改商品

-- comment on column v_rm_salereceipts_report.bPreselllockStock not supported: 预订占用可用量

-- comment on column v_rm_salereceipts_report.fVIPDiscountSum not supported: 会员折扣额

-- comment on column v_rm_salereceipts_report.fPromotionSum not supported: 促销折扣额

-- comment on column v_rm_salereceipts_report.fSceneDiscountSum not supported: 现场折扣额

-- comment on column v_rm_salereceipts_report.fGiftApportion not supported: 优惠券折扣额

-- comment on column v_rm_salereceipts_report.fSaleMoney not supported: 应售金额合计

-- comment on column v_rm_salereceipts_report.fMoneySum not supported: 实销金额合计

-- comment on column v_rm_salereceipts_report.fQuantitySum not supported: 实销数量合计

-- comment on column v_rm_salereceipts_report.fPresellPayMoney not supported: 预定已支付金额合计

-- comment on column v_rm_salereceipts_report.iDeliveryStoreid not supported: 交货门店id

-- comment on column v_rm_salereceipts_report.iDeliveryWarehouseid not supported: 交货仓库

-- comment on column v_rm_salereceipts_report.fPointPay not supported: 抵款积分

-- comment on column v_rm_salereceipts_report.fPointPayMoney not supported: 积分抵款金额

-- comment on column v_rm_salereceipts_report.iBusinesstypeid not supported: 业务类型

-- comment on column v_rm_salereceipts_report.iProfitTo not supported: 预定业绩归属门店

-- comment on column v_rm_salereceipts_report.cRegionCode not supported: 收货地区

-- comment on column v_rm_salereceipts_report.cDeliveradd not supported: 收货人地址

-- comment on column v_rm_salereceipts_report.cCusperson not supported: 收货联系人

-- comment on column v_rm_salereceipts_report.cMobileNo not supported: 收货人手机号

-- comment on column v_rm_salereceipts_report.fCardDisApportion not supported: 回收分摊储值卡折扣金额

-- comment on column v_rm_salereceipts_report.fCardApportion not supported: 回收分摊储值卡实销金额

-- comment on column v_rm_salereceipts_report.bRequireOver not supported: 要货后标记状态

-- comment on column v_rm_salereceipts_report.blocalSale not supported: 本店销售

-- comment on column v_rm_salereceipts_report.blocaDelivery not supported: 本店交货

-- comment on column v_rm_salereceipts_report.iChangeUser not supported: 变更人

-- comment on column v_rm_salereceipts_report.dChangeTime not supported: 变更时间

-- comment on column v_rm_salereceipts_report.bRestore not supported: 是否补单

-- comment on column v_rm_salereceipts_report.create_time not supported: 创建时间

-- comment on column v_rm_salereceipts_report.create_date not supported: 创建日期

-- comment on column v_rm_salereceipts_report.modify_time not supported: 修改时间

-- comment on column v_rm_salereceipts_report.modify_date not supported: 修改日期

-- comment on column v_rm_salereceipts_report.creator not supported: 创建人

-- comment on column v_rm_salereceipts_report.modifier not supported: 修改人

-- comment on column v_rm_salereceipts_report.auditor not supported: 审批人

-- comment on column v_rm_salereceipts_report.audit_time not supported: 审批时间

-- comment on column v_rm_salereceipts_report.audit_date not supported: 审批日期

-- comment on column v_rm_salereceipts_report.tplid not supported: 模板id

-- comment on column v_rm_salereceipts_report.status not supported: 单据状态

-- comment on column v_rm_salereceipts_report.pubts not supported: 时间戳

-- comment on column v_rm_salereceipts_report.fQuoteMoneySum not supported: 零售金额

-- comment on column v_rm_salereceipts_report.fDiscountSum not supported: 折扣额

-- comment on column v_rm_salereceipts_report.fCoQuantitySum not supported: 已退货数量合计

-- comment on column v_rm_salereceipts_report.dPresellDate not supported: 预订日期

-- comment on column v_rm_salereceipts_report.fChangeMoney not supported: 找零金额

-- comment on column v_rm_salereceipts_report.fbitReport not supported: 日报状态

-- comment on column v_rm_salereceipts_report.iOwesState not supported: 赊销状态

-- comment on column v_rm_salereceipts_report.iCustomerid not supported: 客户id

-- comment on column v_rm_salereceipts_report.retailVouchGatherings not supported: ID

-- comment on column v_rm_salereceipts_report.retailVouchGathering not supported: ID

-- comment on column v_rm_salereceipts_report.paymentwritedetails not supported: ID

-- comment on column v_rm_salereceipts_report.isSumLine not supported: 同一张零售单下的收款明细只有一行isSumLine=1

