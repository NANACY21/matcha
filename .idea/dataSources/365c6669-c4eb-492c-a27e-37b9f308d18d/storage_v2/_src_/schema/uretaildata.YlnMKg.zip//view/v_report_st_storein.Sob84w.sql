create definer = root@`%` view v_report_st_storein as
select `uretaildata`.`st_storein`.`ioutstoreid`     AS `ioutstoreid`,
       `uretaildata`.`st_storein`.`ioutwarehouseid` AS `ioutwarehouseid`,
       `uretaildata`.`st_storein`.`iinstoreid`      AS `iinstoreid`,
       `uretaildata`.`st_storein`.`iinwarehouseid`  AS `iinwarehouseid`,
       `uretaildata`.`st_storein`.`ibustypeid`      AS `ibustypeid`,
       `uretaildata`.`st_storein`.`ioperatorid`     AS `ioperatorid`,
       `uretaildata`.`st_storein`.`cmemo`           AS `cmemo`,
       `uretaildata`.`st_storein`.`csrcbillid`      AS `csrcbillid`,
       `uretaildata`.`st_storein`.`csrcbillno`      AS `csrcbillno`,
       `uretaildata`.`st_storein`.`auditor`         AS `auditor`,
       `uretaildata`.`st_storein`.`audit_time`      AS `audit_time`,
       `uretaildata`.`st_storein`.`audit_date`      AS `audit_date`,
       `uretaildata`.`st_storein`.`iStoreID`        AS `iStoreID`,
       `uretaildata`.`st_storein`.`vouchdate`       AS `vouchdate`,
       `uretaildata`.`st_storein`.`tplid`           AS `tplid`,
       `uretaildata`.`st_storein`.`status`          AS `status`,
       `uretaildata`.`st_storein`.`code`            AS `code`,
       `uretaildata`.`st_storein`.`create_time`     AS `create_time`,
       `uretaildata`.`st_storein`.`create_date`     AS `create_date`,
       `uretaildata`.`st_storein`.`modify_time`     AS `modify_time`,
       `uretaildata`.`st_storein`.`modify_date`     AS `modify_date`,
       `uretaildata`.`st_storein`.`creator`         AS `creator`,
       `uretaildata`.`st_storein`.`modifier`        AS `modifier`,
       `uretaildata`.`st_storein`.`tenant_id`       AS `tenant_id`,
       `uretaildata`.`st_storein`.`id`              AS `id`,
       `uretaildata`.`st_storein`.`pubts`           AS `pubts`,
       `uretaildata`.`st_storein`.`csrcbilltype`    AS `csrcbilltype`,
       `uretaildata`.`st_storein`.`fTotalQuantity`  AS `fTotalQuantity`,
       `uretaildata`.`st_storein`.`iinwarehouseid`  AS `iwarehouseid`
from `uretaildata`.`st_storein`;

-- comment on column v_report_st_storein.ioutstoreid not supported: 调出门店

-- comment on column v_report_st_storein.ioutwarehouseid not supported: 调出仓库

-- comment on column v_report_st_storein.iinstoreid not supported: 调入门店

-- comment on column v_report_st_storein.iinwarehouseid not supported: 调入仓库

-- comment on column v_report_st_storein.ibustypeid not supported: 业务类型

-- comment on column v_report_st_storein.ioperatorid not supported: 经办人

-- comment on column v_report_st_storein.cmemo not supported: 备注

-- comment on column v_report_st_storein.csrcbillid not supported: 来源单据

-- comment on column v_report_st_storein.csrcbillno not supported: 来源单据号

-- comment on column v_report_st_storein.auditor not supported: 审批人

-- comment on column v_report_st_storein.audit_time not supported: 审批时间

-- comment on column v_report_st_storein.audit_date not supported: 审批日期

-- comment on column v_report_st_storein.iStoreID not supported: 门店ID

-- comment on column v_report_st_storein.vouchdate not supported: 单据日期

-- comment on column v_report_st_storein.tplid not supported: 模板id

-- comment on column v_report_st_storein.status not supported: 单据状态

-- comment on column v_report_st_storein.code not supported: 编码

-- comment on column v_report_st_storein.create_time not supported: 创建时间

-- comment on column v_report_st_storein.create_date not supported: 创建日期

-- comment on column v_report_st_storein.modify_time not supported: 修改时间

-- comment on column v_report_st_storein.modify_date not supported: 修改日期

-- comment on column v_report_st_storein.creator not supported: 创建人

-- comment on column v_report_st_storein.modifier not supported: 修改人

-- comment on column v_report_st_storein.tenant_id not supported: 租户

-- comment on column v_report_st_storein.id not supported: ID

-- comment on column v_report_st_storein.pubts not supported: 时间戳

-- comment on column v_report_st_storein.fTotalQuantity not supported: 整单数量

-- comment on column v_report_st_storein.iwarehouseid not supported: 调入仓库

