create definer = root@`%` view v_winshor_bckfs as
select `rsc`.`tenant_id`                                               AS `tenant_id`,
       `rsc`.`store_id`                                                AS `store_id`,
       date_format((`rsc`.`begin_time` - interval 9 hour), '%Y-%m-%d') AS `busidate`,
       `go`.`id`                                                       AS `gid`,
       `go`.`name`                                                     AS `gname`,
       count(0)                                                        AS `num`
from ((`uretaildata`.`aa_roomstatuschange` `rsc` left join `uretaildata`.`aa_groupstorerelated` `gsr` on ((`rsc`.`store_id` = `gsr`.`storeId`)))
         left join `uretaildata`.`aa_gradeorder` `go` on ((`gsr`.`group_id` = `go`.`group_id`)))
where ((`rsc`.`newstatus` = '7') and (`rsc`.`beforestatus` in ('1', '3', '6')) and
       (((date_format(`rsc`.`begin_time`, '%H:%i:%s') >= `go`.`startTime`) and
         (date_format(`rsc`.`begin_time`, '%H:%i:%s') < `go`.`endTime`)) or
        ((concat('1', date_format(`rsc`.`begin_time`, '%H:%i:%s')) >= concat('0', `go`.`startTime`)) and
         (concat('1', date_format(`rsc`.`begin_time`, '%H:%i:%s')) <
          concat((case when `go`.`bNextDay` then '1' else '0' end), `go`.`endTime`)))))
group by `rsc`.`tenant_id`, `rsc`.`store_id`, date_format((`rsc`.`begin_time` - interval 9 hour), '%Y-%m-%d'),
         `go`.`id`, `go`.`name`;

-- comment on column v_winshor_bckfs.tenant_id not supported: 租户

-- comment on column v_winshor_bckfs.store_id not supported: 门店ID

-- comment on column v_winshor_bckfs.gid not supported: ID

-- comment on column v_winshor_bckfs.gname not supported: 名称

