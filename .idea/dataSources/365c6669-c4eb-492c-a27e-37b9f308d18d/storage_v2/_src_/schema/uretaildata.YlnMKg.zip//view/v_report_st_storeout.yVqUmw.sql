create definer = root@`%` view v_report_st_storeout as
select `uretaildata`.`st_storeout`.`ioutstoreid`     AS `ioutstoreid`,
       `uretaildata`.`st_storeout`.`ioutwarehouseid` AS `ioutwarehouseid`,
       `uretaildata`.`st_storeout`.`iinstoreid`      AS `iinstoreid`,
       `uretaildata`.`st_storeout`.`iinwarehouseid`  AS `iinwarehouseid`,
       `uretaildata`.`st_storeout`.`ibustypeid`      AS `ibustypeid`,
       `uretaildata`.`st_storeout`.`ioperatorid`     AS `ioperatorid`,
       `uretaildata`.`st_storeout`.`cmemo`           AS `cmemo`,
       `uretaildata`.`st_storeout`.`isrcbillid`      AS `isrcbillid`,
       `uretaildata`.`st_storeout`.`csrcbillno`      AS `csrcbillno`,
       `uretaildata`.`st_storeout`.`vouchdate`       AS `vouchdate`,
       `uretaildata`.`st_storeout`.`tplid`           AS `tplid`,
       `uretaildata`.`st_storeout`.`status`          AS `status`,
       `uretaildata`.`st_storeout`.`id`              AS `id`,
       `uretaildata`.`st_storeout`.`pubts`           AS `pubts`,
       `uretaildata`.`st_storeout`.`code`            AS `code`,
       `uretaildata`.`st_storeout`.`create_time`     AS `create_time`,
       `uretaildata`.`st_storeout`.`create_date`     AS `create_date`,
       `uretaildata`.`st_storeout`.`modify_time`     AS `modify_time`,
       `uretaildata`.`st_storeout`.`modify_date`     AS `modify_date`,
       `uretaildata`.`st_storeout`.`creator`         AS `creator`,
       `uretaildata`.`st_storeout`.`modifier`        AS `modifier`,
       `uretaildata`.`st_storeout`.`tenant_id`       AS `tenant_id`,
       `uretaildata`.`st_storeout`.`auditor`         AS `auditor`,
       `uretaildata`.`st_storeout`.`audit_time`      AS `audit_time`,
       `uretaildata`.`st_storeout`.`audit_date`      AS `audit_date`,
       `uretaildata`.`st_storeout`.`iStoreID`        AS `iStoreID`,
       `uretaildata`.`st_storeout`.`csrcbilltype`    AS `csrcbilltype`,
       `uretaildata`.`st_storeout`.`iinorgid`        AS `iinorgid`,
       `uretaildata`.`st_storeout`.`fTotalQuantity`  AS `fTotalQuantity`,
       `uretaildata`.`st_storeout`.`ioutwarehouseid` AS `iwarehouseid`
from `uretaildata`.`st_storeout`;

-- comment on column v_report_st_storeout.ioutstoreid not supported: 调出门店

-- comment on column v_report_st_storeout.ioutwarehouseid not supported: 出库仓库

-- comment on column v_report_st_storeout.iinstoreid not supported: 调入门店

-- comment on column v_report_st_storeout.iinwarehouseid not supported: 调入仓库

-- comment on column v_report_st_storeout.ibustypeid not supported: 业务类型

-- comment on column v_report_st_storeout.ioperatorid not supported: 经办人

-- comment on column v_report_st_storeout.cmemo not supported: 备注

-- comment on column v_report_st_storeout.isrcbillid not supported: 来源单据

-- comment on column v_report_st_storeout.csrcbillno not supported: 来源单据号

-- comment on column v_report_st_storeout.vouchdate not supported: 单据日期

-- comment on column v_report_st_storeout.tplid not supported: 模板id

-- comment on column v_report_st_storeout.status not supported: 单据状态

-- comment on column v_report_st_storeout.id not supported: ID

-- comment on column v_report_st_storeout.pubts not supported: 时间戳

-- comment on column v_report_st_storeout.code not supported: 编码

-- comment on column v_report_st_storeout.create_time not supported: 创建时间

-- comment on column v_report_st_storeout.create_date not supported: 创建日期

-- comment on column v_report_st_storeout.modify_time not supported: 修改时间

-- comment on column v_report_st_storeout.modify_date not supported: 修改日期

-- comment on column v_report_st_storeout.creator not supported: 创建人

-- comment on column v_report_st_storeout.modifier not supported: 修改人

-- comment on column v_report_st_storeout.tenant_id not supported: 租户

-- comment on column v_report_st_storeout.auditor not supported: 审批人

-- comment on column v_report_st_storeout.audit_time not supported: 审批时间

-- comment on column v_report_st_storeout.audit_date not supported: 审批日期

-- comment on column v_report_st_storeout.iStoreID not supported: 门店ID

-- comment on column v_report_st_storeout.fTotalQuantity not supported: 整单数量

-- comment on column v_report_st_storeout.iwarehouseid not supported: 出库仓库

