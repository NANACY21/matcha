create
    definer = root@`%` procedure p_hr_getmembercardno(IN p_tenant bigint, IN p_istoreid bigint, OUT p_cardno varchar(50))
begin
    DECLARE t_error INTEGER DEFAULT 0;    
	declare p_code varchar(50);
	declare p_latestnumber int;
	declare p_addinterval int;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
	    SET t_error=1;   
		SET p_cardno='-1';
        ROLLBACK;    		
	END;
   
    START TRANSACTION;    
	select code,latestnumber,addinterval into p_code,p_latestnumber,p_addinterval from aa_hr_memberfilenumberrule where tenant_id=p_tenant and istoreid=p_istoreid and stopstatus=0 for update;
	if p_code is not null AND LENGTH(trim(p_code)) > 0 AND p_latestnumber is not null AND p_addinterval is not null then 		
		SET p_latestnumber=p_latestnumber+p_addinterval;
		SET p_cardno = concat(p_code,p_latestnumber);
		update aa_hr_memberfilenumberrule set latestnumber=p_latestnumber where tenant_id=p_tenant and istoreid=p_istoreid and stopstatus=0;	
	end if;
	IF t_error = 1 THEN
		set p_cardno='-1';
        ROLLBACK;    
    ELSE    
        COMMIT;    
    END IF;    
end;

