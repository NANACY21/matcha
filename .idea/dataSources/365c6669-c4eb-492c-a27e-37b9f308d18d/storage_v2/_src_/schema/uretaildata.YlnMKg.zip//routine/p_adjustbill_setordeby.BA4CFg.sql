create
    definer = root@`%` procedure p_adjustbill_setordeby(IN billno varchar(200))
begin
	
	
    declare var_iTenant_ID bigint;
	declare var_iUserId bigint;
    DECLARE done int DEFAULT 0;
    
    declare cur1 CURSOR FOR select id from tenant;
    
    declare cur2 CURSOR FOR select id from user where tenant_id=var_iTenant_ID ;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; 
    open cur1;
    read_loop: LOOP
        fetch cur1 into var_iTenant_ID;
        IF done=1 THEN
			LEAVE read_loop;
        END IF;
        
        open cur2;
        inner_loop: LOOP
            fetch cur2 into var_iUserId;
            IF done=1 THEN
				LEAVE inner_loop;
            END IF;
			
			set @zrow=0;
			set @billno=billno;
			set @iTenant_ID=var_iTenant_ID;
			set @iUserId=var_iUserId;
			select id into @billid from bill_base where cbillno=@billno and tenant_id=@iTenant_ID;
			update billitem_set set iorder=(@zrow:=@zrow+10) where ibillid =@billid and cuserid=@iUserId order by iorder; 				
        END LOOP inner_loop;
        close cur2;
        
        
        SET done = 0;   
    END LOOP read_loop;
    close cur1; 	
end;

