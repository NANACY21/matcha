create definer = root@`%` view v_st_othoutrecord as
select `uretaildata`.`st_othoutrecord`.`auditor`        AS `auditor`,
       `uretaildata`.`st_othoutrecord`.`audit_date`     AS `audit_date`,
       `uretaildata`.`st_othoutrecord`.`audit_time`     AS `audit_time`,
       `uretaildata`.`st_othoutrecord`.`cMemo`          AS `cMemo`,
       `uretaildata`.`st_othoutrecord`.`code`           AS `cCode`,
       `uretaildata`.`st_othoutrecord`.`create_date`    AS `create_date`,
       `uretaildata`.`st_othoutrecord`.`create_time`    AS `create_time`,
       `uretaildata`.`st_othoutrecord`.`creator`        AS `creator`,
       `uretaildata`.`st_othoutrecord`.`fTotalQuantity` AS `fTotalQuantity`,
       `uretaildata`.`st_othoutrecord`.`iBusType`       AS `iBusType`,
       `uretaildata`.`st_othoutrecord`.`id`             AS `id`,
       `uretaildata`.`st_othoutrecord`.`iOperatorId`    AS `iOperatorId`,
       `uretaildata`.`st_othoutrecord`.`iShopID`        AS `iShopID`,
       `uretaildata`.`st_othoutrecord`.`iStoreID`       AS `iStoreID`,
       `uretaildata`.`st_othoutrecord`.`iWarehouseId`   AS `iWarehouseId`,
       `uretaildata`.`st_othoutrecord`.`modifier`       AS `modifier`,
       `uretaildata`.`st_othoutrecord`.`modify_date`    AS `modify_date`,
       `uretaildata`.`st_othoutrecord`.`modify_time`    AS `modify_time`,
       `uretaildata`.`st_othoutrecord`.`pubts`          AS `pubts`,
       `uretaildata`.`st_othoutrecord`.`status`         AS `status`,
       `uretaildata`.`st_othoutrecord`.`tenant_id`      AS `tenant_id`,
       `uretaildata`.`st_othoutrecord`.`tplid`          AS `tplid`,
       `uretaildata`.`st_othoutrecord`.`vouchdate`      AS `dDate`
from `uretaildata`.`st_othoutrecord`;

-- comment on column v_st_othoutrecord.auditor not supported: 审批人

-- comment on column v_st_othoutrecord.audit_date not supported: 审批日期

-- comment on column v_st_othoutrecord.audit_time not supported: 审批时间

-- comment on column v_st_othoutrecord.cMemo not supported: 备注

-- comment on column v_st_othoutrecord.cCode not supported: 编码

-- comment on column v_st_othoutrecord.create_date not supported: 创建日期

-- comment on column v_st_othoutrecord.create_time not supported: 创建时间

-- comment on column v_st_othoutrecord.creator not supported: 创建人

-- comment on column v_st_othoutrecord.fTotalQuantity not supported: 整单数量

-- comment on column v_st_othoutrecord.iBusType not supported: 业务类型

-- comment on column v_st_othoutrecord.id not supported: ID

-- comment on column v_st_othoutrecord.iOperatorId not supported: 经办人

-- comment on column v_st_othoutrecord.iShopID not supported: 商家

-- comment on column v_st_othoutrecord.iStoreID not supported: 门店ID

-- comment on column v_st_othoutrecord.iWarehouseId not supported: 仓库

-- comment on column v_st_othoutrecord.modifier not supported: 修改人

-- comment on column v_st_othoutrecord.modify_date not supported: 修改日期

-- comment on column v_st_othoutrecord.modify_time not supported: 修改时间

-- comment on column v_st_othoutrecord.pubts not supported: 时间戳

-- comment on column v_st_othoutrecord.status not supported: 单据状态

-- comment on column v_st_othoutrecord.tenant_id not supported: 租户

-- comment on column v_st_othoutrecord.tplid not supported: 模板id

-- comment on column v_st_othoutrecord.dDate not supported: 单据日期

