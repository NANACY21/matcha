create
    definer = root@`%` procedure ws()
begin
	declare m int;
	set m= 1;
	while m <= 30 do
	set @cFieldName=concat('productProps.define',m);
	set @cName=concat('productProps!define',m);
	set @cCaption=concat('商品自定义项',m);
	set @cShowCaption=concat('商品自定义项',m);
	set @iOrder = 93+m;
	set @defineID = 90+m;
	set @cSelfDefineType = concat("define",@defineID);
	
	delete from billitem_base where cName=@cName and iBillId in (select id from bill_base where cBillNo='aa_productskuref');

	insert into billitem_base(`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`multiple`,`tenant_id`) 
	select `iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,'ST',@cFieldName,@cName,@cCaption,@cShowCaption,@iOrder,'255',1,0,null,0,0,1,null,null,null,null,null,0,0,null,1,null,'255',null,'150',null,1,0,1,null,1,null,null,null,'68',1,1,0,0,1,'st.demandapply.DemandApplyFreeItem',null,null,'Input',null,null,0,null,null,null,@cSelfDefineType,0,0,1,`tenant_id`
	from billitem_base where cName='productSkuProps!define60'
	and iBillId in (select id from bill_base where cBillNo='aa_productskuref');

	set m = m + 1;
	end while;
end;

