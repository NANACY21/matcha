create definer = uretail@`192.168.1.%` view v_rm_retailvouchdetailbatch as
select `uretaildata`.`rm_retailvouchdetailbatch`.`id`                   AS `id`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB1`            AS `define1`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB2`            AS `define2`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB3`            AS `define3`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB4`            AS `define4`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB5`            AS `define5`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB6`            AS `define6`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB7`            AS `define7`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB8`            AS `define8`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB9`            AS `define9`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB10`           AS `define10`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB11`           AS `define11`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB12`           AS `define12`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB13`           AS `define13`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB14`           AS `define14`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB15`           AS `define15`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB16`           AS `define16`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB17`           AS `define17`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB18`           AS `define18`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB19`           AS `define19`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB20`           AS `define20`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB21`           AS `define21`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB22`           AS `define22`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB23`           AS `define23`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB24`           AS `define24`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB25`           AS `define25`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB26`           AS `define26`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB27`           AS `define27`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB28`           AS `define28`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB29`           AS `define29`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`cDefineB30`           AS `define30`,
       `uretaildata`.`rm_retailvouchdetailbatch`.`iRetailVouchDetailId` AS `iRetailVouchDetailId`
from `uretaildata`.`rm_retailvouchdetailbatch`;

-- comment on column v_rm_retailvouchdetailbatch.id not supported: ID

-- comment on column v_rm_retailvouchdetailbatch.define1 not supported: 批次自定义项1

-- comment on column v_rm_retailvouchdetailbatch.define2 not supported: 批次自定义项2

-- comment on column v_rm_retailvouchdetailbatch.define3 not supported: 批次自定义项3

-- comment on column v_rm_retailvouchdetailbatch.define4 not supported: 批次自定义项4

-- comment on column v_rm_retailvouchdetailbatch.define5 not supported: 批次自定义项5

-- comment on column v_rm_retailvouchdetailbatch.define6 not supported: 批次自定义项6

-- comment on column v_rm_retailvouchdetailbatch.define7 not supported: 批次自定义项7

-- comment on column v_rm_retailvouchdetailbatch.define8 not supported: 批次自定义项8

-- comment on column v_rm_retailvouchdetailbatch.define9 not supported: 批次自定义项9

-- comment on column v_rm_retailvouchdetailbatch.define10 not supported: 批次自定义项10

-- comment on column v_rm_retailvouchdetailbatch.define11 not supported: 批次自定义项11

-- comment on column v_rm_retailvouchdetailbatch.define12 not supported: 批次自定义项12

-- comment on column v_rm_retailvouchdetailbatch.define13 not supported: 批次自定义项13

-- comment on column v_rm_retailvouchdetailbatch.define14 not supported: 批次自定义项14

-- comment on column v_rm_retailvouchdetailbatch.define15 not supported: 批次自定义项15

-- comment on column v_rm_retailvouchdetailbatch.define16 not supported: 批次自定义项16

-- comment on column v_rm_retailvouchdetailbatch.define17 not supported: 批次自定义项17

-- comment on column v_rm_retailvouchdetailbatch.define18 not supported: 批次自定义项18

-- comment on column v_rm_retailvouchdetailbatch.define19 not supported: 批次自定义项19

-- comment on column v_rm_retailvouchdetailbatch.define20 not supported: 批次自定义项20

-- comment on column v_rm_retailvouchdetailbatch.define21 not supported: 批次自定义项21

-- comment on column v_rm_retailvouchdetailbatch.define22 not supported: 批次自定义项22

-- comment on column v_rm_retailvouchdetailbatch.define23 not supported: 批次自定义项23

-- comment on column v_rm_retailvouchdetailbatch.define24 not supported: 批次自定义项24

-- comment on column v_rm_retailvouchdetailbatch.define25 not supported: 批次自定义项25

-- comment on column v_rm_retailvouchdetailbatch.define26 not supported: 批次自定义项26

-- comment on column v_rm_retailvouchdetailbatch.define27 not supported: 批次自定义项27

-- comment on column v_rm_retailvouchdetailbatch.define28 not supported: 批次自定义项28

-- comment on column v_rm_retailvouchdetailbatch.define29 not supported: 批次自定义项29

-- comment on column v_rm_retailvouchdetailbatch.define30 not supported: 批次自定义项30

-- comment on column v_rm_retailvouchdetailbatch.iRetailVouchDetailId not supported: 零售单子表

