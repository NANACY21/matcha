create
    definer = root@`%` procedure ypj_addBtn(IN rtn int)
begin  
    IF rtn is NOT NULL   THEN  
			
	

delete billentity_base from billentity_base inner join bill_base on billentity_base.iBillId=bill_base.id where bill_base.cBillNo='rm_demandplanTemplate_templatelist' ;
delete billtemplate_base from billtemplate_base inner join bill_base on billtemplate_base.iBillId=bill_base.id where bill_base.cBillNo='rm_demandplanTemplate_templatelist' ;
delete billtplgroup_base from billtplgroup_base inner join bill_base on billtplgroup_base.iBillId=bill_base.id where bill_base.cBillNo='rm_demandplanTemplate_templatelist' ;
delete billitem_base from billitem_base inner JOIN bill_base on billitem_base.iBillId=bill_base.id where bill_base.cBillNo='rm_demandplanTemplate_templatelist' ;
delete from pub_makebillrule_detail where makebill_id in (select makebill_id from pub_makebillrule where iBillId in (select id from bill_base where cBillNo='rm_demandplanTemplate_templatelist'));
delete from pub_makebillrule where iBillId in (select id from bill_base where cBillNo='rm_demandplanTemplate_templatelist');
delete from bill_base where cBillNo='rm_demandplanTemplate_templatelist';

select ifnull(max(id),0)+1 into @id4 from bill_base;
insert into bill_base(`id`,`cBillNo`,`cName`,`cCardKey`,`cSubId`,`iDefTplId`,`iDefPrnTplId`,`iOrder`,`bAllowMultiTpl`,`cDefWhere`,`isDeleted`,`bPrintLimited`,`iSystem`,`cAuthId`,`cBillType`,`cBeanId`,`cFilterId`,`bRowAuthControl`,`bColumnAuthControl`,`bRowAuthObject`,`bColumnAuthControlled`,`bRowAuthControlled`,`cPersonDataSource`,`cCarry`,`printBoPk`,`authGroupKey`,`sysid`,`tenant_id`,`datasourcetype`,`datasourcesql`,`batchoperate`,`authType`,`pkField`,`parentField`,`domain`,`isSupportBpm`,`isBpmInited`,`rowAuthObject`) values (@id4,'rm_demandplanTemplate_templatelist','要货模板','rm_demandplantemplate','RM',null,null,0,0,null,0,null,1,null,'VoucherList',null,null,0,0,0,0,0,null,null,null,null,null,0,null,null,0,null,null,null,null,0,0,null);

select ifnull(max(id),0)+1 into @id10 from billentity_base;
insert into billentity_base(`id`,`iBillId`,`cCode`,`cName`,`cSubId`,`iOrder`,`isDeleted`,`cDataSourceName`,`cPrimaryKey`,`iSystem`,`bMain`,`cForeignKey`,`cParentCode`,`childrenField`,`cModelType`,`bIsNull`,`sysid`,`tenant_id`,`isprint`,`queryJoin`,`printKey`,`isTplExport`) values (@id10,@id4,'rm_demandplanTemplate_templatelist_entity','要货模板','RM',1,0,'rm.demandplantemplate.Template','id',1,1,null,null,null,null,null,null,0,1,null,null,1);

select ifnull(max(id),0)+1 into @id16 from billtemplate_base;
insert into billtemplate_base(`id`,`iBillId`,`cName`,`iOrder`,`iTplMode`,`iWidth`,`isDeleted`,`cPrintSetting`,`cPageHeader`,`cPageFooter`,`cTitleHeight`,`iPrintTotal`,`iFixedCols`,`cMemo`,`cTitle`,`iGridStyle`,`cRowLayout`,`cTitleStyle`,`cTotalColor`,`cAmongColor`,`cFixedColor`,`sysid`,`tenant_id`,`templateType`) values (@id16,@id4,'要货模板显示模板',0,0,'10000',0,null,null,null,null,null,null,null,'操作员柜组权限',null,null,null,null,null,null,null,0,null);

select ifnull(max(id),0)+1 into @id22 from billtplgroup_base;
insert into billtplgroup_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`cCode`,`cName`,`cSubId`,`iOrder`,`cDataSourceName`,`cPrimaryKey`,`isDeleted`,`iSystem`,`bMain`,`cForeignKey`,`cParentDataSource`,`cType`,`iParentID`,`cAlign`,`iCols`,`cStyle`,`cImage`,`sysid`,`tenant_id`,`dataRule`) values (@id22,@id4,@id10,@id16,'ListHeader_1','要货模板','RM',1,'rm.demandplantemplate.Template','id',0,1,1,null,null,'ListHeader',null,'top',null,null,null,null,0,null);
set @id23=@id22+1;
insert into billtplgroup_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`cCode`,`cName`,`cSubId`,`iOrder`,`cDataSourceName`,`cPrimaryKey`,`isDeleted`,`iSystem`,`bMain`,`cForeignKey`,`cParentDataSource`,`cType`,`iParentID`,`cAlign`,`iCols`,`cStyle`,`cImage`,`sysid`,`tenant_id`,`dataRule`) values (@id23,@id4,@id10,@id16,'ConvenientQuery_2','要货模板过滤条件','RM',2,'rm.demandplantemplate.Template','id',0,1,1,null,null,'ConvenientQuery',@id22,'left',null,null,null,null,0,null);
set @id24=@id23+1;
insert into billtplgroup_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`cCode`,`cName`,`cSubId`,`iOrder`,`cDataSourceName`,`cPrimaryKey`,`isDeleted`,`iSystem`,`bMain`,`cForeignKey`,`cParentDataSource`,`cType`,`iParentID`,`cAlign`,`iCols`,`cStyle`,`cImage`,`sysid`,`tenant_id`,`dataRule`) values (@id24,@id4,@id10,@id16,'Table_3','要货模板数据','RM',3,'rm.demandplantemplate.Template','id',0,1,1,null,null,'Table',null,'right',null,null,null,null,0,null);

select ifnull(max(id),0)+1 into @id30 from billitem_base;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id30,@id4,@id10,@id16,@id24,'RM','id','id','ID','ID',1,'255',1,null,null,0,1,1,null,null,null,null,null,null,null,null,0,null,'255',null,'200',null,null,null,0,null,0,null,null,null,'30',1,null,null,null,null,'rm.demandplantemplate.Template',null,null,'Input',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id31=@id30+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id31,@id4,@id10,@id16,@id24,'RM','code','code','模板编码','模板编码',2,'255',1,0,null,0,1,0,null,null,null,null,null,0,0,null,0,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,0,1,1,0,0,'rm.demandplantemplate.Template',null,0,'Input',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id32=@id31+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id32,@id4,@id10,@id16,@id24,'RM','name','name','模板名称','模板名称',3,'255',1,0,null,0,1,0,null,null,null,null,null,0,0,null,1,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,0,1,0,0,0,'rm.demandplantemplate.Template',null,0,'Input',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id33=@id32+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id33,@id4,@id10,@id16,@id24,'RM','adminOrg','adminOrg','管理组织ID','管理组织ID',4,'255',1,null,null,0,1,1,'aa_orgtree',null,'{"adminOrg":"id","adminOrg.name":"name"}',null,null,0,0,null,0,null,'255',null,'200',null,1,0,0,null,1,null,null,null,null,0,1,0,0,0,'rm.demandplantemplate.Template',null,null,'TreeRefer',null,'name',0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id34=@id33+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id34,@id4,@id10,@id16,@id24,'RM','adminOrg.name','adminOrg_name','管理组织名称','管理组织名称',5,'255',1,null,null,0,1,0,'aa_orgtree',null,'{"adminOrg":"id","adminOrg.name":"name"}',null,null,0,0,null,0,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,0,1,0,0,0,'rm.demandplantemplate.Template',null,null,'TreeRefer',null,'name',0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id35=@id34+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id35,@id4,@id10,@id16,@id24,'RM','vouchdate','vouchdate','单据日期','单据日期',6,'255',1,0,null,0,1,0,null,null,null,null,null,0,0,null,0,null,'255',null,'200',null,1,0,1,null,1,null,'YYYY-MM-DD',null,null,0,1,0,0,0,'rm.demandplantemplate.Template',null,0,'DatePicker',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id36=@id35+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id36,@id4,@id10,@id16,@id24,'RM','operator','operator','经办人','经办人',7,'255',1,null,null,0,0,1,'aa_operator',null,'{"operator":"id","operator.name":"name","retailVouchDetailCustom!define12":"iSuperior_erpCode","retailVouchDetailCustom!define11":"iSuperior_name"}',null,null,0,0,null,1,null,'255',null,'200',null,1,0,0,null,1,null,null,null,null,1,1,0,0,0,'rm.demandplantemplate.Template',null,0,'refer',null,'name',0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id37=@id36+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id37,@id4,@id10,@id16,@id24,'RM','operator.name','operator_name','经办人','经办人',8,'255',1,null,null,0,0,0,'aa_operator',null,'{"operator":"id","operator.name":"name","retailVouchDetailCustom!define12":"iSuperior_erpCode","retailVouchDetailCustom!define11":"iSuperior_name"}',null,null,0,0,null,1,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,1,1,0,0,0,'rm.demandplantemplate.Template',null,0,'refer',null,'name',0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id38=@id37+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id38,@id4,@id10,@id16,@id24,'RM','memo','memo','备注','备注',9,'255',1,0,null,0,1,0,null,null,null,null,null,0,0,null,1,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,1,1,0,0,0,'rm.demandplantemplate.Template',null,0,'Input',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id39=@id38+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id39,@id4,@id10,@id16,@id24,'RM','createTime','createTime','创建时间','创建时间','10','255',1,0,null,0,0,1,null,null,null,null,null,0,0,null,0,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,0,1,0,0,0,'rm.demandplantemplate.Template',null,0,'DatePicker',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id40=@id39+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id40,@id4,@id10,@id16,@id24,'RM','createDate','createDate','创建日期','创建日期','11','255',1,0,null,0,0,1,null,null,null,null,null,0,0,null,0,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,1,1,0,0,0,'rm.demandplantemplate.Template',null,0,'DatePicker',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id41=@id40+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id41,@id4,@id10,@id16,@id24,'RM','creator','creator','创建人','创建人','12','255',1,0,null,0,0,1,null,null,null,null,null,0,0,null,0,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,0,1,0,0,0,'rm.demandplantemplate.Template',null,0,'refer',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id42=@id41+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id42,@id4,@id10,@id16,@id24,'RM','modifier','modifier','最后修改人','最后修改人','13','255',1,0,null,0,0,1,null,null,null,null,null,0,0,null,0,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,1,1,0,0,0,'rm.demandplantemplate.Template',null,0,'refer',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id43=@id42+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id43,@id4,@id10,@id16,@id24,'RM','modifyTime','modifyTime','最后修改时间','最后修改时间','14','255',1,0,null,0,0,1,null,null,null,null,null,0,0,null,0,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,1,1,0,0,0,'rm.demandplantemplate.Template',null,0,'DatePicker',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);
set @id44=@id43+1;
insert into billitem_base(`id`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`sysid`,`tenant_id`,`isprint`,`multiple`,`isshoprelated`,`depends`,`iSystem`,`auth_level`,`cDefineName`,`makeField`,`enterDirection`,`isExport`,`cSensFieldName`,`bShowZero`) values (@id44,@id4,@id10,@id16,@id24,'RM','modifyDate','modifyDate','最后修改日期','最后修改日期','15','255',1,0,null,0,0,1,null,null,null,null,null,0,0,null,0,null,'255',null,'200',null,1,0,1,null,1,null,null,null,null,1,1,0,0,0,'rm.demandplantemplate.Template',null,0,'DatePicker',null,null,0,null,null,0,null,0,0,null,0,1,0,0,null,1,3,null,null,4,1,null,1);



delete pb_filter_solution_common from pb_filter_solution_common  inner join pb_filter_solution on pb_filter_solution_common.solutionId = pb_filter_solution.id  inner join pb_meta_filters on pb_filter_solution.filtersId=pb_meta_filters.id  where pb_meta_filters.filterName='rm_demandplanTemplate_templatelist' ;
delete pb_filter_solution from pb_filter_solution  inner join pb_meta_filters on pb_filter_solution.filtersId=pb_meta_filters.id where pb_meta_filters.filterName='rm_demandplanTemplate_templatelist' ;
delete from pb_meta_filter_item where filtersId in (select id from pb_meta_filters where filterName='rm_demandplanTemplate_templatelist');
delete from pb_meta_filters where filterName='rm_demandplanTemplate_templatelist';

select ifnull(max(id),0)+1 into @id60 from pb_meta_filters;
insert into pb_meta_filters(`id`,`filterName`,`filterDesc`,`subId`,`createTime`,`isUpGrade`,`dr`,`updateTime`,`advanceSupport`,`behaviorObject`) values (@id60,'rm_demandplanTemplate_templatelist','要货模板列表过滤','RM',now(),0,0,null,null,null);

select ifnull(max(id),0)+1 into @id66 from pb_meta_filter_item;
insert into pb_meta_filter_item(`id`,`filtersId`,`itemName`,`itemTitle`,`itemType`,`referCode`,`refType`,`refReturn`,`compareLogic`,`iprecision`,`dataSource`,`descValue`,`isCommon`,`mustInput`,`rangeInput`,`multSelect`,`allowUpdateCompare`,`orLogic`,`defaultVal1`,`defaultVal2`,`groupName`,`isSys`,`createTime`,`dr`,`referId`,`updateTime`,`cEnumType`,`bEnum`,`bAutoflt`,`displayname`,`cformatData`,`extendField`,`auth_level`,`cSelfDefineType`) values (@id66,@id60,'code','模板编码','Input',null,null,null,'like',null,'code',null,1,0,0,0,0,0,null,null,null,1,'2019/3/11 16:45:20',0,null,null,null,null,null,null,null,null,3,null);
set @id67=@id66+1;
insert into pb_meta_filter_item(`id`,`filtersId`,`itemName`,`itemTitle`,`itemType`,`referCode`,`refType`,`refReturn`,`compareLogic`,`iprecision`,`dataSource`,`descValue`,`isCommon`,`mustInput`,`rangeInput`,`multSelect`,`allowUpdateCompare`,`orLogic`,`defaultVal1`,`defaultVal2`,`groupName`,`isSys`,`createTime`,`dr`,`referId`,`updateTime`,`cEnumType`,`bEnum`,`bAutoflt`,`displayname`,`cformatData`,`extendField`,`auth_level`,`cSelfDefineType`) values (@id67,@id60,'name','模板名称','Input',null,null,null,'like',null,'name',null,1,0,0,0,0,0,null,null,null,1,'2019/3/11 16:45:20',0,null,null,null,null,null,null,null,null,3,null);
set @id68=@id67+1;
insert into pb_meta_filter_item(`id`,`filtersId`,`itemName`,`itemTitle`,`itemType`,`referCode`,`refType`,`refReturn`,`compareLogic`,`iprecision`,`dataSource`,`descValue`,`isCommon`,`mustInput`,`rangeInput`,`multSelect`,`allowUpdateCompare`,`orLogic`,`defaultVal1`,`defaultVal2`,`groupName`,`isSys`,`createTime`,`dr`,`referId`,`updateTime`,`cEnumType`,`bEnum`,`bAutoflt`,`displayname`,`cformatData`,`extendField`,`auth_level`,`cSelfDefineType`) values (@id68,@id60,'iCabinetgroup','柜组','Refer','aa_cabinetgroupref',null,'id','in',null,'cabinetgroup.cabinetGroup',null,1,0,0,1,0,0,null,null,null,1,'2019/3/11 16:45:20',0,null,null,null,null,null,'name',null,null,3,null);

select ifnull(max(id),0)+1 into @id74 from pb_filter_solution;
insert into pb_filter_solution(`id`,`filtersId`,`solutionName`,`isDefault`,`isPublic`,`userId`,`orderId`,`terminalType`,`tenant_id`,`sysid`) values (@id74,@id60,'默认方案',1,1,null,null,1,0,null);

select ifnull(max(id),0)+1 into @id80 from pb_filter_solution_common;
insert into pb_filter_solution_common(`id`,`solutionId`,`itemId`,`itemName`,`itemTitle`,`refType`,`isCommon`,`rangeInput`,`multSelect`,`compareLogic`,`defaultVal1`,`defaultVal2`,`orderId`,`saveHistory`,`checkRefer`,`pb_filter_solution_commoncol`,`tenant_id`,`defineId`,`itemType`,`refercode`,`bhidden`,`isshoprelated`,`cEnumType`,`bEnum`,`bAutoflt`,`cDataRule`,`bIsNull`) values (@id80,@id74,@id66,'code','模板编码',0,1,0,0,'like',null,null,'10',0,0,null,0,null,null,null,0,0,null,null,null,null,null);
set @id81=@id80+1;
insert into pb_filter_solution_common(`id`,`solutionId`,`itemId`,`itemName`,`itemTitle`,`refType`,`isCommon`,`rangeInput`,`multSelect`,`compareLogic`,`defaultVal1`,`defaultVal2`,`orderId`,`saveHistory`,`checkRefer`,`pb_filter_solution_commoncol`,`tenant_id`,`defineId`,`itemType`,`refercode`,`bhidden`,`isshoprelated`,`cEnumType`,`bEnum`,`bAutoflt`,`cDataRule`,`bIsNull`) values (@id81,@id74,@id67,'name','模板名称',0,1,0,0,'like',null,null,'20',0,0,null,0,null,null,null,0,0,null,null,null,null,null);
set @id82=@id81+1;
insert into pb_filter_solution_common(`id`,`solutionId`,`itemId`,`itemName`,`itemTitle`,`refType`,`isCommon`,`rangeInput`,`multSelect`,`compareLogic`,`defaultVal1`,`defaultVal2`,`orderId`,`saveHistory`,`checkRefer`,`pb_filter_solution_commoncol`,`tenant_id`,`defineId`,`itemType`,`refercode`,`bhidden`,`isshoprelated`,`cEnumType`,`bEnum`,`bAutoflt`,`cDataRule`,`bIsNull`) values (@id82,@id74,@id68,'iCabinetgroup','柜组',0,1,0,1,'in',null,null,'50',0,0,null,0,null,null,null,0,0,null,null,null,null,null);

delete from bill_toolbar where billnumber='rm_demandplanTemplate_templatelist';
delete from bill_toolbaritem where billnumber='rm_demandplanTemplate_templatelist';
delete from bill_command where billnumber='rm_demandplanTemplate_templatelist';

select ifnull(max(id),0)+1 into @id88 from bill_toolbar;
insert into bill_toolbar(`id`,`billnumber`,`name`,`ismain`,`parent`,`align`,`subid`,`system`,`orderNum`,`childrenField`,`tplmode`,`cStyle`,`templateType`,`terminalType`,`tenant_id`) values (@id88,'rm_demandplanTemplate_templatelist','ListHeader',null,'ListHeader_1','top',null,0,0,null,0,null,1,1,0);
set @id89=@id88+1;
insert into bill_toolbar(`id`,`billnumber`,`name`,`ismain`,`parent`,`align`,`subid`,`system`,`orderNum`,`childrenField`,`tplmode`,`cStyle`,`templateType`,`terminalType`,`tenant_id`) values (@id89,'rm_demandplanTemplate_templatelist','ListBody',null,'Table_3','left',null,0,0,null,0,null,1,1,0);

select ifnull(max(id),0)+1 into @id95 from bill_toolbaritem;
insert into bill_toolbaritem(`id`,`billnumber`,`toolbar`,`name`,`command`,`type`,`style`,`text`,`parameter`,`imgsrc`,`parent`,`order`,`subid`,`system`,`authid`,`authcontrol`,`authname`,`bMerge`,`icon`,`sysid`,`tenant_id`,`auth_level`,`cDataRule`) values (@id95,'rm_demandplanTemplate_templatelist','ListHeader','btnAdd','cmdAdd','primarybutton',0,'新增',null,null,null,1,'RM',1,null,1,null,1,'plus-copy',null,0,3,null);
set @id96=@id95+1;
insert into bill_toolbaritem(`id`,`billnumber`,`toolbar`,`name`,`command`,`type`,`style`,`text`,`parameter`,`imgsrc`,`parent`,`order`,`subid`,`system`,`authid`,`authcontrol`,`authname`,`bMerge`,`icon`,`sysid`,`tenant_id`,`auth_level`,`cDataRule`) values (@id96,'rm_demandplanTemplate_templatelist','ListBody','btnEdit','cmdEdit','button',0,'编辑',null,null,null,'10','RM',1,null,1,null,1,'bianji1',null,0,3,null);

select ifnull(max(id),0)+1 into @id102 from bill_command;
insert into bill_command(`id`,`name`,`action`,`billnumber`,`target`,`ruleid`,`svcurl`,`httpmethod`,`subid`,`system`,`parameter`,`tenant_id`,`authid`) values (@id102,'cmdAdd','add','rm_demandplanTemplate_templatelist','ListHeader',null,'/bill/add','POST','RM',1,null,0,'rm_demandplanTemplate_templatelistadd');
set @id103=@id102+1;
insert into bill_command(`id`,`name`,`action`,`billnumber`,`target`,`ruleid`,`svcurl`,`httpmethod`,`subid`,`system`,`parameter`,`tenant_id`,`authid`) values (@id103,'cmdEdit','edit','rm_demandplanTemplate_templatelist',null,null,'/bill/edit','GET','RM',1,null,0,'rm_demandplanTemplate_templatelistedit');
set @id104=@id103+1;
insert into bill_command(`id`,`name`,`action`,`billnumber`,`target`,`ruleid`,`svcurl`,`httpmethod`,`subid`,`system`,`parameter`,`tenant_id`,`authid`) values (@id104,'cmdList','list','rm_demandplanTemplate_templatelist',null,null,'/bill/list','POST','RM',1,null,0,'rm_demandplanTemplate_templatelistlist');
set @id105=@id104+1;
insert into bill_command(`id`,`name`,`action`,`billnumber`,`target`,`ruleid`,`svcurl`,`httpmethod`,`subid`,`system`,`parameter`,`tenant_id`,`authid`) values (@id105,'cmdTempexport','tempexport','rm_demandplanTemplate_templatelist',null,null,'/billtemp/export','POST','RM',1,null,0,'rm_demandplanTemplate_templatelistexport');
set @id106=@id105+1;
insert into bill_command(`id`,`name`,`action`,`billnumber`,`target`,`ruleid`,`svcurl`,`httpmethod`,`subid`,`system`,`parameter`,`tenant_id`,`authid`) values (@id106,'cmdImport','batchimport','rm_demandplanTemplate_templatelist',null,null,'/bill/billImport','POST','RM',1,null,0,'rm_demandplanTemplate_templatelistimport');



update bill_base set `iDefTplId`=@id16 where `id`=@id4;
update bill_base set `cFilterId`=@id60 where `id`=@id4;

	##非0租户卡片 ##部分单据过滤基础表与过滤方案的编号与billnum不一致，单独处理
##风险提示，请执行后自行检查是否结果执行是否正确
set @billno = 'rm_demandplanTemplate_templatelist';
set @filterName='rm_demandplanTemplate_templatelist';
set @solutionName='rm_demandplanTemplate_templatelist';
set @tplmode=0;##部分单模版mode用2，要手工调整，为了处理默认模版的更新
delete billentity_base from billentity_base inner join bill_base on billentity_base.iBillId=bill_base.id where bill_base.cBillNo=@billno and bill_base.tenant_id<>0; 
delete billtemplate_base from billtemplate_base inner join bill_base on billtemplate_base.iBillId=bill_base.id where bill_base.cBillNo=@billno and bill_base.tenant_id<>0; 
delete billtplgroup_base from billtplgroup_base inner join bill_base on billtplgroup_base.iBillId=bill_base.id where bill_base.cBillNo=@billno and bill_base.tenant_id<>0;
delete billitem_base from billitem_base inner JOIN bill_base on billitem_base.iBillId=bill_base.id where bill_base.cBillNo=@billno and bill_base.tenant_id<>0;
delete from bill_base where cBillNo=@billno and tenant_id<>0 ;
delete pb_filter_solution_common from pb_filter_solution_common 
		inner join pb_filter_solution on pb_filter_solution_common.solutionId = pb_filter_solution.id 
		inner join pb_meta_filters on pb_filter_solution.filtersId=pb_meta_filters.id
		where pb_meta_filters.filterName=@filterName and pb_filter_solution_common.tenant_id<>0 ;
delete pb_filter_solution from pb_filter_solution 
		inner join pb_meta_filters on pb_filter_solution.filtersId=pb_meta_filters.id
		where pb_meta_filters.filterName=@filterName and pb_filter_solution.tenant_id<>0 ;
delete from bill_toolbar where billnumber=@billno and tenant_id<>0 ;
delete from bill_toolbaritem where billnumber=@billno and tenant_id<>0 ;
delete from bill_command where billnumber=@billno and tenant_id<>0 ;

insert into bill_base(`sysid`,`cBillNo`,`cName`,`cCardKey`,`cSubId`,`iDefTplId`,`iDefPrnTplId`,`iOrder`,`bAllowMultiTpl`,`cDefWhere`,`isDeleted`,`bPrintLimited`,`iSystem`,`cAuthId`,`cBillType`,`cBeanId`,`cFilterId`,`bRowAuthControl`,`bColumnAuthControl`,`bRowAuthObject`,`bColumnAuthControlled`,`bRowAuthControlled`,`cPersonDataSource`,`cCarry`,`authGroupKey`,`datasourcetype`,`datasourcesql`,`batchoperate`,`authType`,`tenant_id`,`pkField`,`parentField`) 
select bill_base.id,`cBillNo`,`cName`,`cCardKey`,`cSubId`,`iDefTplId`,`iDefPrnTplId`,`iOrder`,`bAllowMultiTpl`,`cDefWhere`,`isDeleted`,`bPrintLimited`,`iSystem`,`cAuthId`,`cBillType`,`cBeanId`,`cFilterId`,`bRowAuthControl`,`bColumnAuthControl`,`bRowAuthObject`,`bColumnAuthControlled`,`bRowAuthControlled`,`cPersonDataSource`,`cCarry`,`authGroupKey`,`datasourcetype`,`datasourcesql`,`batchoperate`,`authType`,tenant.id,pkField,parentField
from bill_base 
left join tenant on 1=1 and tenant.id<>0
where cBillNo=@billno and tenant_id=0;

insert into billentity_base(`sysid`,`iBillId`,`cCode`,`cName`,`cSubId`,`iOrder`,`isDeleted`,`cDataSourceName`,`cPrimaryKey`,`iSystem`,`bMain`,`cForeignKey`,`cParentCode`,`childrenField`,`cModelType`,`bIsNull`,`tenant_id`,`isprint`,`queryJoin`, `printKey`,`isTplExport`) 
select billentity_base.id,bill_base.id,`cCode`,billentity_base.cName,billentity_base.cSubId,billentity_base.iOrder,billentity_base.isDeleted,`cDataSourceName`,`cPrimaryKey`,billentity_base.iSystem,`bMain`,`cForeignKey`,`cParentCode`,`childrenField`,`cModelType`,`bIsNull`,tenant.id,isprint,queryJoin, printKey,isTplExport
from billentity_base 
left join tenant on 1=1 
left join bill_base on bill_base.tenant_id=tenant.id 
where bill_base.cBillNo=@billno and bill_base.tenant_id<>0 
and billentity_base.iBillId in (select id from bill_base where cBillNo=@billno and tenant_id=0);

insert into billtemplate_base(`sysid`,`iBillId`,`cName`,`iOrder`,`iTplMode`,`iWidth`,`isDeleted`,`cPrintSetting`,`cPageHeader`,`cPageFooter`,`cTitleHeight`,`iPrintTotal`,`iFixedCols`,`cMemo`,`cTitle`,`iGridStyle`,`cRowLayout`,`cTitleStyle`,`cTotalColor`,`cAmongColor`,`cFixedColor`,`tenant_id`,`templateType`) 
select billtemplate_base.id,bill_base.id,billtemplate_base.cName,billtemplate_base.iOrder,`iTplMode`,`iWidth`,billtemplate_base.isDeleted,`cPrintSetting`,`cPageHeader`,`cPageFooter`,`cTitleHeight`,`iPrintTotal`,`iFixedCols`,`cMemo`,`cTitle`,`iGridStyle`,`cRowLayout`,`cTitleStyle`,`cTotalColor`,`cAmongColor`,`cFixedColor`,tenant.id,`templateType`
from billtemplate_base 
left join tenant on 1=1 
left join bill_base on bill_base.tenant_id=tenant.id 
where bill_base.cBillNo=@billno and bill_base.tenant_id<>0 
and billtemplate_base.iBillId in (select id from bill_base where cBillNo=@billno and tenant_id=0);

insert into billtplgroup_base(`sysid`,`iBillId`,`iBillEntityId`,`iTplId`,`cCode`,`cName`,`cSubId`,`iOrder`,`cDataSourceName`,`cPrimaryKey`,`isDeleted`,`iSystem`,`bMain`,`cForeignKey`,`cParentDataSource`,`cType`,`iParentID`,`cAlign`,`iCols`,`cStyle`,`cImage`,`tenant_id`) 
select billtplgroup_base.id,bill.iBillId,bill.iBillEntityId,bill.iTplId,billtplgroup_base.cCode,billtplgroup_base.cName,billtplgroup_base.cSubId,billtplgroup_base.iOrder,billtplgroup_base.cDataSourceName,billtplgroup_base.cPrimaryKey,billtplgroup_base.isDeleted,billtplgroup_base.iSystem,billtplgroup_base.bMain,billtplgroup_base.cForeignKey,billtplgroup_base.cParentDataSource,`cType`,`iParentID`,`cAlign`,`iCols`,`cStyle`,`cImage`,tenant.id
from billtplgroup_base
left join tenant on 1=1 
left join bill_base on billtplgroup_base.iBillId=bill_base.id and billtplgroup_base.tenant_id=bill_base.tenant_id
left join billentity_base on billentity_base.iBillId=bill_base.id and billentity_base.tenant_id=bill_base.tenant_id and billtplgroup_base.iBillEntityId=billentity_base.id
left join billtemplate_base on billtemplate_base.iBillId=bill_base.id and billtemplate_base.tenant_id=bill_base.tenant_id and billtemplate_base.id= billtplgroup_base.iTplId 
left join (select bill_base.id as iBillId,billentity_base.id as iBillEntityId ,billtemplate_base.id as iTplId,bill_base.tenant_id,
					billentity_base.cCode as billentity_base_cCode,billtemplate_base.cname as billtemplate_base_cname,billtemplate_base.iTplMode
			from bill_base 
			left join billentity_base on bill_base.id=billentity_base.iBillId and bill_base.tenant_id=billentity_base.tenant_id
			left join billtemplate_base on bill_base.id=billtemplate_base.iBillId and bill_base.tenant_id=billtemplate_base.tenant_id
			where bill_base.cBillNo=@billno and bill_base.tenant_id<>0
			) bill on bill.tenant_id=tenant.id and billentity_base.cCode=bill.billentity_base_cCode and billtemplate_base.cName=bill.billtemplate_base_cname and billtemplate_base.iTplMode=bill.iTplMode
where billtplgroup_base.iBillId in (select id from bill_base where cBillNo=@billno and tenant_id=0);

insert into billitem_base(`makeField`,`sysid`,`iBillId`,`iBillEntityId`,`iTplId`,`iBillTplGroupId`,`cSubId`,`cFieldName`,`cName`,`cCaption`,`cShowCaption`,`iOrder`,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,`isDeleted`,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,`cMemo`,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,`bIsNull`,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,`cDataSourceName`,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,`cStyle`,`bRowAuthControlled`,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,`isprint`,`multiple`,`tenant_id`,`isshoprelated`,`depends`) 
select billitem_base.makeField,billitem_base.id,bill.iBillId,bill.iBillEntityId,bill.iTplId,bill.iBillTplGroupId,billitem_base.cSubId,`cFieldName`,billitem_base.cName,`cCaption`,`cShowCaption`,billitem_base.iOrder,`iMaxLength`,`iFieldType`,`bEnum`,`cEnumString`,billitem_base.isDeleted,`bMustSelect`,`bHidden`,`cRefType`,`cRefId`,`cRefRetID`,`cDataRule`,`iFunctionType`,`bSplit`,`bExtend`,`iNumPoint`,`bCanModify`,`cSourceType`,`iMaxShowLen`,billitem_base.cMemo,`iColWidth`,`cSumType`,`iAlign`,`bNeedSum`,`bShowIt`,`bFixed`,`bFilter`,`cDefaultValue`,`cFormatData`,`cUserId`,`iTabIndex`,billitem_base.bIsNull,`bPrintCaption`,`bJointQuery`,`bPrintUpCase`,`bSelfDefine`,billitem_base.cDataSourceName,`cOrder`,`bCheck`,`cControlType`,`cEnumType`,`refReturn`,`bShowInRowAuth`,`iRowAuthBillId`,billitem_base.cStyle,billitem_base.bRowAuthControlled,`cSelfDefineType`,`bVmExclude`,`bRowAuthDim`,billitem_base.isprint,`multiple`,tenant.id,`isshoprelated`,`depends`
from billitem_base
left join tenant on 1=1
left join bill_base on billitem_base.iBillId=bill_base.id and billitem_base.tenant_id=bill_base.tenant_id
left join billentity_base on billentity_base.iBillId=bill_base.id and billentity_base.tenant_id=bill_base.tenant_id and billitem_base.iBillEntityId=billentity_base.id
left join billtemplate_base on billtemplate_base.iBillId=bill_base.id and billtemplate_base.tenant_id=bill_base.tenant_id and billitem_base.iTplId=billtemplate_base.id
left join billtplgroup_base on billtplgroup_base.iBillId=bill_base.id and billtplgroup_base.tenant_id=bill_base.tenant_id and billtplgroup_base.iBillEntityId=billentity_base.id and billitem_base.iBillTplGroupId=billtplgroup_base.id
left join (select bill_base.id as iBillId,billentity_base.id as iBillEntityId ,billtemplate_base.id as iTplId,
				  billtplgroup_base.id as iBillTplGroupId,bill_base.tenant_id,
					billentity_base.cCode as billentity_base_cCode,billtemplate_base.cname as billtemplate_base_cname,billtemplate_base.iTplMode,
					billtplgroup_base.cCode as billtplgroup_base_cCode
			from bill_base 
			left join billentity_base on bill_base.id=billentity_base.iBillId and bill_base.tenant_id=billentity_base.tenant_id
			left join billtemplate_base on bill_base.id=billtemplate_base.iBillId and bill_base.tenant_id=billtemplate_base.tenant_id
			left join billtplgroup_base on bill_base.id=billtplgroup_base.iBillId and billentity_base.id=billtplgroup_base.iBillEntityId
										and billtemplate_base.id=billtplgroup_base.iTplId and bill_base.tenant_id=billtplgroup_base.tenant_id
			where bill_base.cBillNo=@billno and bill_base.tenant_id<>0 and if(isnull(billtplgroup_base.cCode),'', billtplgroup_base.cCode)<> ''
			) bill on bill.tenant_id=tenant.id and billentity_base.cCode=bill.billentity_base_cCode and billtemplate_base.cName=bill.billtemplate_base_cname 
								and  billtplgroup_base.cCode=bill.billtplgroup_base_cCode 
where billitem_base.iBillId in (select id from bill_base where cBillNo=@billno and tenant_id=0) and if(isnull(billtplgroup_base.cCode),'', billtplgroup_base.cCode)<> '' ;

set @solutionidzero =-1;set @filterid =-1 ;select id into @solutionidzero from pb_filter_solution where tenant_id=0 and filtersid in (select id from pb_meta_filters where filterName=@filterName);
select id into @filterid from pb_meta_filters where filterName=@filterName;
insert into pb_filter_solution (filtersid,solutionName,isDefault,isPublic,userId,orderId,terminalType,tenant_id,sysid)
select filtersid,solutionName,isDefault,isPublic,userId,orderId,terminalType,tenant.id,pb_filter_solution.id
from pb_filter_solution
left join tenant on 1=1
where tenant_id=0 and filtersid in (select id from pb_meta_filters where filterName=@filterName)
;
insert into pb_filter_solution_common (`solutionId`,`itemId`,`itemName`,`itemTitle`,`refType`,`isCommon`,`rangeInput`,`multSelect`,`compareLogic`,`defaultVal1`,`defaultVal2`,`orderId`,`saveHistory`,`checkRefer`,`tenant_id`,`defineId`,`itemType`,`refercode`,`bhidden`,`isshoprelated`)
select pb_filter_solution.id,itemId,itemName,itemTitle,refType,isCommon,rangeInput,multSelect,compareLogic,defaultVal1,defaultVal2,pb_filter_solution_common.orderId,saveHistory,checkRefer,tenant.id,defineId,itemType,refercode,bhidden,isshoprelated 
from pb_filter_solution_common 
left join tenant on 1=1
left join pb_filter_solution on tenant.id=pb_filter_solution.tenant_id
where pb_filter_solution_common.tenant_id=0 and pb_filter_solution.tenant_id<>0 
and pb_filter_solution_common.solutionId =@solutionidzero and pb_filter_solution.filtersId=@filterid
;
insert into bill_toolbar(`billnumber`,`name`,`ismain`,`parent`,`align`,`subid`,`system`,`orderNum`,`childrenField`,`tplmode`,`cStyle`,`tenant_id`,`templateType`,`terminalType`) 
select `billnumber`,bill_toolbar.name,`ismain`,`parent`,`align`,`subid`,`system`,`orderNum`,`childrenField`,`tplmode`,`cStyle`,tenant.id,templateType,terminalType
from bill_toolbar 
left join tenant on 1=1 and tenant.id<>0
where billnumber=@billno and tenant_id=0;

insert into bill_toolbaritem(`sysid`,`billnumber`,`toolbar`,`name`,`command`,`type`,`style`,`text`,`parameter`,`imgsrc`,`parent`,`order`,`subid`,`system`,`authid`,`authcontrol`,`authname`,`bMerge`,`icon`,`tenant_id`) 
select bill_toolbaritem.id,`billnumber`,`toolbar`,bill_toolbaritem.name,`command`,`type`,`style`,`text`,`parameter`,`imgsrc`,`parent`,`order`,`subid`,`system`,`authid`,`authcontrol`,`authname`,`bMerge`,`icon`,tenant.id
from bill_toolbaritem
left join tenant on 1=1 and tenant.id<>0
where billnumber=@billno and tenant_id=0;

insert into bill_command(`name`,`action`,`billnumber`,`target`,`ruleid`,`svcurl`,`httpmethod`,`subid`,`system`,`parameter`,`authid`,`tenant_id`) 
select bill_command.name,`action`,`billnumber`,`target`,`ruleid`,`svcurl`,`httpmethod`,`subid`,`system`,`parameter`,`authid`,tenant.id
from bill_command
left join tenant on 1=1 and tenant.id<>0
where billnumber=@billno and tenant_id=0;

##处理报表查询分组方案 非报表不需要处理
##delete rpt_groupitem from rpt_groupitem inner join rpt_groupschema on rpt_groupitem.mainid=rpt_groupschema.id where rpt_groupschema.billnum=@billno and rpt_groupschema.tenant_id<>0;
##delete from rpt_groupschema where  billnum=@billno and tenant_id<>0;

##insert into rpt_groupschema(`billnum`,`name`,`isDefault`,`isCrossTable`,`tenant_id`,sysid,displayStyle,pageLayout,chartConfig, isDisplayZero,`type`,isPc,isMobile) 
##select `billnum`,rpt_groupschema.name,`isDefault`,`isCrossTable`,tenant.id,rpt_groupschema.id,displayStyle,pageLayout,chartConfig, isDisplayZero,`type`,isPc,isMobile
##from rpt_groupschema
##left join tenant on 1=1 and tenant.id<>0
##where billnum=@billno and tenant_id=0;

##insert into rpt_groupitem (mainid,fieldname,groupType,columndefine,entity,showCaption)
##select rpt_groupschema.id,fieldname,groupType,columndefine,entity,showCaption
##from rpt_groupschema inner join (
##			select rpt_groupitem.id,fieldname,groupType,columndefine,entity,rpt_groupschema.billnum,rpt_groupschema.name,rpt_groupitem.showCaption  from rpt_groupschema 
##     left join rpt_groupitem on rpt_groupschema.id=rpt_groupitem.mainid where billnum=@billno and tenant_id=0) item
##			on item.billnum=rpt_groupschema.billnum and rpt_groupschema.name=item.name
##where rpt_groupschema.tenant_id<>0 and rpt_groupschema.billnum=@billno order by item.id;



##更新bill_base的iDefTplId字段
update bill_base left join billtemplate_base on billtemplate_base.iBillId=bill_base.id and billtemplate_base.tenant_id=bill_base.tenant_id
set bill_base.iDefTplId=billtemplate_base.id
where bill_base.cBillNo=@billno and billtemplate_base.iTplMode=@tplmode;
##更新tplgroup的iParentId字段
update billtplgroup_base a
					inner join billtplgroup_base b on a.iParentId=b.sysid and a.tenant_id=b.tenant_id and a.iTplId=b.iTplId
set a.iParentId=b.id
where  if(ISNULL(a.iParentId),'',a.iParentId)<>'' and a.iBillId in (select id from bill_base where cBillNo=@billno and tenant_id<>0) and if(ISNULL(b.id),'',b.id)<>'';
##更新bill_toolbaritem 的parent字段
update bill_toolbaritem a
##select a.Parent,b.id from bill_toolbaritem a
					inner join bill_toolbaritem b on a.Parent=b.sysid and a.tenant_id=b.tenant_id and a.billnumber=b.billnumber
set a.Parent=b.id
where  if(ISNULL(a.Parent),'',a.Parent)<>'' and a.billnumber=@billno and a.tenant_id<>0 and if(ISNULL(b.id),'',b.id)<>'';
##更新非0租户的cFilterId、sysid为0租户的billid ##插入时处理了sysid不用在更新
##update bill_base a ,bill_base b 
##set a.cFilterId=b.cFilterId,a.sysid=b.id 
##where a.cBillNo = b.cBillNo And b.tenant_id = 0 And a.cBillNo = @billno;
##更新非0租户billitem_base的自定义项
Update 
billitem_base 
left join userdef_base on billitem_base.cSelfDefineType=userdef_base.defineId and userdef_base.tenant_id=billitem_base.tenant_id
left join userdef_type on userdef_base.type = userdef_type.deftype
set
billitem_base.cshowcaption=userdef_base.showitem, billitem_base.bHidden=0, billitem_base.bShowIt=1, billitem_base.cControlType=userdef_type.controltype, 
billitem_base.bIsNull=(case when userdef_base.isinput=1 then 0 else 1 END), 
billitem_base.refReturn=(case when userdef_base.type='Archive' then 'name' else NULL END),
billitem_base.cRefType=(case when userdef_base.type='Archive' then 'pb_userdefine' else NULL END)
where iBillId in (select id from bill_base where cbillno=@billno and tenant_id<>0)
and billitem_base.tenant_id<>0 and bSelfDefine=1 and userdef_base.isenabled=1;

##更新非0租户pb_filter_solution_common的自定义项
Update
pb_filter_solution_common
left join userdef_base on pb_filter_solution_common.defineId=userdef_base.defineId and pb_filter_solution_common.tenant_id=userdef_base.tenant_id
left join userdef_type on userdef_base.type = userdef_type.deftype
set
pb_filter_solution_common.itemTitle=userdef_base.showitem, 
pb_filter_solution_common.bHidden=0, 
pb_filter_solution_common.itemType=userdef_type.controltype, 
pb_filter_solution_common.refercode=(case when userdef_base.type='Archive' then 'pb_userdefine' else NULL END)
where pb_filter_solution_common.solutionId in (select id from pb_filter_solution where filtersId in (select id from pb_meta_filters where filterName=@filterName))
and pb_filter_solution_common.tenant_id<>0 and pb_filter_solution_common.defineId is not null and userdef_base.isenabled=1
;


			 END IF;  
end;

