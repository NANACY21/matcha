create
    definer = root@`%` procedure p_exist_tablecolumn(IN tablename varchar(50), IN columnname varchar(50), OUT result int)
BEGIN
if EXISTS(SELECT 1 from information_schema.TABLES where TABLE_SCHEMA=DATABASE() and table_name=tablename) THEN
	SET result = 1;
end if;
if EXISTS(SELECT 1 from information_schema.COLUMNS where TABLE_SCHEMA=DATABASE() and table_name=tablename and COLUMN_NAME=columnname) Then
	SET result = 2;
end if;
END;

