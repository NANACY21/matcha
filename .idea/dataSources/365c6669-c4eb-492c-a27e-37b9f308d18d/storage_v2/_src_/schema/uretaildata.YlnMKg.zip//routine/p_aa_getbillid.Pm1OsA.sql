create
    definer = root@`%` procedure p_aa_getbillid(IN p_cbillnum varchar(50), IN p_icount int, OUT p_ibillid int)
begin
	start transaction;

	if exists(select 1 from aa_identity where cbillnum=p_cbillnum) then
		select ibillid into p_ibillid from aa_identity where cbillnum=p_cbillnum;
		
		set p_ibillid=p_ibillid+p_icount;

		update aa_identity set ibillid=p_ibillid where cbillnum=p_cbillnum;
			
		set p_ibillid=p_ibillid-p_icount+if(p_icount>0,1,0);
	else
		insert into aa_identity(cbillnum,ibillid) values (p_cbillnum,p_icount);
		
		set p_ibillid=if(p_icount>0,1,0);
	end if;

	commit;
end;

