create
    definer = uretail_user@`%` function fn_formatdateyyyymmdd(d datetime) returns date
BEGIN
DECLARE x date DEFAULT NULL;
SET x= DATE_FORMAT(d,'%Y-%m-%d');
RETURN x;                              
END;

