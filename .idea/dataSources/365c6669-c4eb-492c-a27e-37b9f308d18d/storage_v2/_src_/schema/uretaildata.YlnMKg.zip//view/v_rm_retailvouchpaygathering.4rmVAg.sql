create definer = root@`%` view v_rm_retailvouchpaygathering as
select `a`.`id`                 AS `id`,
       `b`.`iRetailid`          AS `iRetailid`,
       `a`.`iGatheringid`       AS `iGatheringid`,
       `a`.`iGatheringdetailid` AS `iGatheringdetailid`,
       `a`.`iPaymentid`         AS `iPaymentid`,
       `a`.`iPaytype`           AS `iPaytype`,
       `a`.`fAmount`            AS `fAmount`,
       `a`.`dPayTime`           AS `dPayTime`,
       `a`.`cVoucherCode`       AS `cVoucherCode`,
       `a`.`cTransactionCode`   AS `cTransactionCode`,
       `a`.`cCardCode`          AS `cCardCode`,
       `a`.`pubts`              AS `pubts`,
       `a`.`fBalance`           AS `fBalance`,
       `a`.`fCoMoney`           AS `fCoMoney`,
       `a`.`cCardAccount`       AS `cCardAccount`
from (`uretaildata`.`rm_gatheringvouchpaydetail` `a`
         left join `uretaildata`.`rm_paymentwrite` `b` on ((`a`.`iGatheringid` = `b`.`iGatheringid`)));

-- comment on column v_rm_retailvouchpaygathering.id not supported: ID

-- comment on column v_rm_retailvouchpaygathering.iRetailid not supported: 零售单id

-- comment on column v_rm_retailvouchpaygathering.iGatheringid not supported: 收款单id

-- comment on column v_rm_retailvouchpaygathering.iGatheringdetailid not supported: 收款单子表id

-- comment on column v_rm_retailvouchpaygathering.iPaymentid not supported: 收款方式id

-- comment on column v_rm_retailvouchpaygathering.iPaytype not supported: 支付类型

-- comment on column v_rm_retailvouchpaygathering.fAmount not supported: 支付金额

-- comment on column v_rm_retailvouchpaygathering.dPayTime not supported: 支付时间

-- comment on column v_rm_retailvouchpaygathering.cVoucherCode not supported: 单号

-- comment on column v_rm_retailvouchpaygathering.cTransactionCode not supported: 交易号

-- comment on column v_rm_retailvouchpaygathering.cCardCode not supported: 用户卡号

-- comment on column v_rm_retailvouchpaygathering.pubts not supported: 时间戳

-- comment on column v_rm_retailvouchpaygathering.fBalance not supported: 余额

-- comment on column v_rm_retailvouchpaygathering.fCoMoney not supported: 已退金额

-- comment on column v_rm_retailvouchpaygathering.cCardAccount not supported: 账户

