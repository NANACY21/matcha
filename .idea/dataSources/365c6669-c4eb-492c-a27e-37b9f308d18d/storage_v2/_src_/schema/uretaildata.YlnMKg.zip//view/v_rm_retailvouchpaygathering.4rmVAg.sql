create definer = root@`%` view v_rm_retailvouchpaygathering as
select `a`.`id`                 AS `id`,
       `b`.`iRetailid`          AS `iRetailid`,
       `a`.`iGatheringid`       AS `iGatheringid`,
       `a`.`iGatheringdetailid` AS `iGatheringdetailid`,
       `a`.`iPaymentid`         AS `iPaymentid`,
       `a`.`iPaytype`           AS `iPaytype`,
       `a`.`fAmount`            AS `fAmount`,
       `a`.`dPayTime`           AS `dPayTime`,
       `a`.`cVoucherCode`       AS `cVoucherCode`,
       `a`.`cTransactionCode`   AS `cTransactionCode`,
       `a`.`cCardCode`          AS `cCardCode`,
       `a`.`pubts`              AS `pubts`,
       `a`.`fBalance`           AS `fBalance`,
       `a`.`fCoMoney`           AS `fCoMoney`,
       `a`.`cCardAccount`       AS `cCardAccount`
from (`uretaildata`.`rm_gatheringvouchpaydetail` `a`
         left join `uretaildata`.`rm_paymentwrite` `b` on ((`a`.`iGatheringid` = `b`.`iGatheringid`)));

