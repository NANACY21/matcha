create
    definer = root@`%` procedure p_alter_table(IN tablename varchar(50), IN columnname varchar(50))
BEGIN
if not EXISTS(SELECT 1 from information_schema.COLUMNS where TABLE_SCHEMA=DATABASE() and table_name=tablename and COLUMN_NAME=columnname)
 and EXISTS(SELECT 1 from information_schema.TABLES where TABLE_SCHEMA=DATABASE() and table_name=tablename) THEN
	alter table tablename add COLUMN columnname varchar(20);
end if;
END;

