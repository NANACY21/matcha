create
    definer = root@`%` procedure p_create_dailyreport()
BEGIN
if EXISTS(SELECT 1 from information_schema.TABLES where TABLE_SCHEMA=DATABASE() and table_name='rm_gathering_daily_report') THEN
	if NOT EXISTS(SELECT 1 from information_schema.COLUMNS where TABLE_SCHEMA=DATABASE() and table_name='rm_gathering_daily_report' and COLUMN_NAME='busidate') Then
		ALTER TABLE `rm_gathering_daily_report` ADD COLUMN `busidate` DATETIME NULL DEFAULT NULL AFTER `bizstatus`;
	end if;
end if;
END;

