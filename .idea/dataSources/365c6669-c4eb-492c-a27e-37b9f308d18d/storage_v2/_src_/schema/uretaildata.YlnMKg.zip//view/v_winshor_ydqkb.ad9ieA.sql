create definer = root@`%` view v_winshor_ydqkb as
select `t1`.`iStoreid`                                                       AS `store_id`,
       `store`.`cName`                                                       AS `store_name`,
       `t2`.`cDefineH7`                                                      AS `roomType_name`,
       `t2`.`cDefineH8`                                                      AS `timeperiod`,
       date_format((`t1`.`dPlanShipmentDate` - interval 9 hour), '%Y-%m-%d') AS `busidate`,
       count(0)                                                              AS `ydnum`
from ((`uretaildata`.`rm_retailvouch` `t1` left join `yilian`.`mp_store` `store` on ((`store`.`id` = `t1`.`iStoreid`)))
         left join `uretaildata`.`rm_retailvouchcustom` `t2` on ((`t1`.`id` = `t2`.`iRetailVouchId`)))
where ((`t1`.`iDeliveryState` = '0') and (`t2`.`cDefineH7` is not null) and (`t1`.`ibillSource` in ('1', '2', '3')) and
       (`t1`.`iProcessingState` = '3'))
group by `t1`.`iStoreid`, `t2`.`cDefineH7`, `t2`.`cDefineH8`,
         date_format((`t1`.`dPlanShipmentDate` - interval 9 hour), '%Y-%m-%d');

