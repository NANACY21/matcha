create
    definer = root@`%` procedure updatecRefRetId(IN billno varchar(20))
BEGIN 
	select count(*) into  @totalcount from billitem_base where iBillId in (select id from bill_base where cBillNo=billno) and cRefType = 'aa_productsku' and cRefRetId like '%"modelDescription":"modelDescription"%';
	if @totalcount<=0 then
		update billitem_base
		set cRefRetId=
		concat(substring_index(cRefRetId,'}',1),',"modelDescription":"modelDescription"}')   
		where iBillId in (select id from bill_base where cBillNo=billno) and cRefType='aa_productsku';
	end if;

	select count(*) into  @totalcount1 from billitem_base where iBillId in (select id from bill_base where cBillNo=billno) and cRefType = 'aa_product'  and cRefRetId like '%"modelDescription":"modelDescription"%';
	if @totalcount1<=0 then
		update billitem_base
		set cRefRetId=
		concat(substring_index(cRefRetId,'}',1),',"modelDescription":"modelDescription"}')   
		where iBillId in (select id from bill_base where cBillNo=billno) and cRefType='aa_product';
	end if;

	select count(*) into  @totalcount2 from billitem_base where iBillId in (select id from bill_base where cBillNo=billno) and cRefType = 'aa_nomalproduct'  and cRefRetId like '%"modelDescription":"modelDescription"%';
	if @totalcount2<=0 then
		update billitem_base
		set cRefRetId=
		concat(substring_index(cRefRetId,'}',1),',"modelDescription":"modelDescription"}')   
		where iBillId in (select id from bill_base where cBillNo=billno) and cRefType='aa_nomalproduct';
	end if;
END;

