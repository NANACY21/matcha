create
    definer = root@`%` procedure deletecolumn()
BEGIN 
	IF EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = 'role' AND column_name = 'bBottomPriceApproval') THEN
		alter table `role` drop COLUMN `bBottomPriceApproval`;
	end if ;
END;

