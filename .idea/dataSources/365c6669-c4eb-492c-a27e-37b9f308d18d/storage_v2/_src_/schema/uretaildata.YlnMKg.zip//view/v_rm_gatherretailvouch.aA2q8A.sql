create definer = root@`%` view v_rm_gatherretailvouch as
select `c`.`id`                     AS `id`,
       `c`.`cCode`                  AS `cCode`,
       `c`.`vouchdate`              AS `vouchdate`,
       `c`.`iStoreid`               AS `iStoreid`,
       `c`.`cStoreCode`             AS `cStoreCode`,
       `c`.`cMachineid`             AS `cMachineid`,
       `c`.`iOrgid`                 AS `iOrgid`,
       `c`.`tenant_id`              AS `tenant_id`,
       `c`.`iDepartmentid`          AS `iDepartmentid`,
       `c`.`dDate`                  AS `dDate`,
       `c`.`iGradeid`               AS `iGradeid`,
       `c`.`iNegative`              AS `iNegative`,
       `c`.`bHangUp`                AS `bHangUp`,
       `c`.`iMemberid`              AS `iMemberid`,
       `c`.`cMemberCode`            AS `cMemberCode`,
       `c`.`iMaker`                 AS `iMaker`,
       `c`.`fGatheringMoney`        AS `fGatheringMoney`,
       `c`.`iCoRetailid`            AS `iCoRetailid`,
       `c`.`fVIPRate`               AS `fVIPRate`,
       `c`.`fDiscountRate`          AS `fDiscountRate`,
       `c`.`fDiscountMoney`         AS `fDiscountMoney`,
       `c`.`fEffaceMoney`           AS `fEffaceMoney`,
       `c`.`iRelatingRetailid`      AS `iRelatingRetailid`,
       `c`.`dMakeDate`              AS `dMakeDate`,
       `c`.`fbitSettle`             AS `fbitSettle`,
       `c`.`fPointCurrent`          AS `fPointCurrent`,
       `c`.`fPointBalance`          AS `fPointBalance`,
       `c`.`fCardBalance`           AS `fCardBalance`,
       `c`.`dPlanShipmentDate`      AS `dPlanShipmentDate`,
       `c`.`dShipmentDate`          AS `dShipmentDate`,
       `c`.`cRemark`                AS `cRemark`,
       `c`.`iPresellState`          AS `iPresellState`,
       `c`.`iDeliveryState`         AS `iDeliveryState`,
       `c`.`iPayState`              AS `iPayState`,
       `c`.`iTakeway`               AS `iTakeway`,
       `c`.`bDeliveryModify`        AS `bDeliveryModify`,
       `c`.`bPreselllockStock`      AS `bPreselllockStock`,
       `c`.`fVIPDiscountSum`        AS `fVIPDiscountSum`,
       `c`.`fPromotionSum`          AS `fPromotionSum`,
       `c`.`fSceneDiscountSum`      AS `fSceneDiscountSum`,
       `c`.`fGiftApportion`         AS `fGiftApportion`,
       `c`.`fSaleMoney`             AS `fSaleMoney`,
       `c`.`fMoneySum`              AS `fMoneySum`,
       `c`.`fQuantitySum`           AS `fQuantitySum`,
       `c`.`fPresellPayMoney`       AS `fPresellPayMoney`,
       `c`.`iDeliveryStoreid`       AS `iDeliveryStoreid`,
       `c`.`iDeliveryWarehouseid`   AS `iDeliveryWarehouseid`,
       `c`.`fPointPay`              AS `fPointPay`,
       `c`.`fPointPayMoney`         AS `fPointPayMoney`,
       `c`.`iBusinesstypeid`        AS `iBusinesstypeid`,
       `c`.`iProfitTo`              AS `iProfitTo`,
       `c`.`cRegionCode`            AS `cRegionCode`,
       `c`.`cDeliveradd`            AS `cDeliveradd`,
       `c`.`cCusperson`             AS `cCusperson`,
       `c`.`cMobileNo`              AS `cMobileNo`,
       `c`.`fCardDisApportion`      AS `fCardDisApportion`,
       `c`.`fCardApportion`         AS `fCardApportion`,
       `c`.`bRequireOver`           AS `bRequireOver`,
       `c`.`blocalSale`             AS `blocalSale`,
       `c`.`blocaDelivery`          AS `blocaDelivery`,
       `c`.`iChangeUser`            AS `iChangeUser`,
       `c`.`dChangeTime`            AS `dChangeTime`,
       `c`.`bRestore`               AS `bRestore`,
       `c`.`create_time`            AS `create_time`,
       `c`.`create_date`            AS `create_date`,
       `c`.`modify_time`            AS `modify_time`,
       `c`.`modify_date`            AS `modify_date`,
       `c`.`creator`                AS `creator`,
       `c`.`modifier`               AS `modifier`,
       `c`.`auditor`                AS `auditor`,
       `c`.`audit_time`             AS `audit_time`,
       `c`.`audit_date`             AS `audit_date`,
       `c`.`tplid`                  AS `tplid`,
       `c`.`status`                 AS `status`,
       `c`.`pubts`                  AS `pubts`,
       `c`.`fDiscountSum`           AS `fDiscountSum`,
       `c`.`fQuoteMoneySum`         AS `fQuoteMoneySum`,
       `c`.`fCoQuantitySum`         AS `fCoQuantitySum`,
       `c`.`dPresellDate`           AS `dPresellDate`,
       `c`.`fChangeMoney`           AS `fChangeMoney`,
       `c`.`fCoDiscountSum`         AS `fCoDiscountSum`,
       `c`.`fbitReport`             AS `fbitReport`,
       `c`.`cLogisticid`            AS `cLogisticid`,
       `c`.`cLogisticsNo`           AS `cLogisticsNo`,
       `c`.`cCourierid`             AS `cCourierid`,
       `c`.`cCourierPhone`          AS `cCourierPhone`,
       `c`.`iOwesState`             AS `iOwesState`,
       `c`.`iCustomerid`            AS `iCustomerid`,
       `c`.`cGUID`                  AS `cGUID`,
       `c`.`ioffline`               AS `ioffline`,
       `c`.`fSellerPointBalance`    AS `fSellerPointBalance`,
       `c`.`fSellerPointCurrent`    AS `fSellerPointCurrent`,
       `c`.`fSellerPointPay`        AS `fSellerPointPay`,
       `c`.`printCount`             AS `printCount`,
       `c`.`iEInvoiceState`         AS `iEInvoiceState`,
       `c`.`cEInvoiceURL`           AS `cEInvoiceURL`,
       `c`.`bCoEInvoiceOver`        AS `bCoEInvoiceOver`,
       `c`.`cRetailURL`             AS `cRetailURL`,
       `c`.`iCoEInvoiceWay`         AS `iCoEInvoiceWay`,
       `c`.`dEInvoiceEndData`       AS `dEInvoiceEndData`,
       `c`.`iPrcsStatus`            AS `iPrcsStatus`,
       `c`.`handMakeInvoicePeo`     AS `handMakeInvoicePeo`,
       `c`.`handMakeInvoiceTime`    AS `handMakeInvoiceTime`,
       `c`.`bAmountAdjustment`      AS `bAmountAdjustment`,
       `c`.`bGiveawayList`          AS `bGiveawayList`,
       `c`.`bcustomizedOrder`       AS `bcustomizedOrder`,
       `c`.`bReturnStore`           AS `bReturnStore`,
       `c`.`iReturnWarehousid`      AS `iReturnWarehousid`,
       `c`.`iGiveawayListRetailid`  AS `iGiveawayListRetailid`,
       `c`.`iAmountAdjustRetailid`  AS `iAmountAdjustRetailid`,
       `c`.`iGatheringType`         AS `iGatheringType`,
       `c`.`bUnsubscribe`           AS `bUnsubscribe`,
       `c`.`unsubscribeReason`      AS `unsubscribeReason`,
       `c`.`outOrg`                 AS `outOrg`,
       `c`.`bGiveawayListGenerated` AS `bGiveawayListGenerated`,
       `c`.`bExtendHeader`          AS `bExtendHeader`,
       `c`.`bExtendBody`            AS `bExtendBody`,
       `c`.`iAmountAdjustNum`       AS `iAmountAdjustNum`,
       `c`.`billNo`                 AS `billNo`,
       `c`.`room`                   AS `room`,
       `c`.`iProcessingState`       AS `iProcessingState`,
       `c`.`cPickCode`              AS `cPickCode`,
       `c`.`oldroom`                AS `oldroom`,
       `c`.`dRoomturnDate`          AS `dRoomturnDate`,
       `c`.`ibillSource`            AS `ibillSource`,
       `c`.`esignature`             AS `esignature`,
       `c`.`iposid`                 AS `iposid`,
       `c`.`iCabinetgroup`          AS `iCabinetgroup`,
       `c`.`iCabinetgroupType`      AS `iCabinetgroupType`,
       `c`.`fScanDiscountSum`       AS `fScanDiscountSum`,
       `c`.`bExport`                AS `bExport`,
       `c`.`cStoreRemark`           AS `cStoreRemark`,
       `c`.`iUnravelState`          AS `iUnravelState`,
       `a`.`id`                     AS `iGatheringid`,
       `b`.`fAmount`                AS `fAmount`
from ((`uretaildata`.`rm_gatheringvouch` `a` join `uretaildata`.`rm_paymentwrite` `b` on ((`a`.`id` = `b`.`iGatheringid`)))
         join `uretaildata`.`rm_retailvouch` `c` on ((`b`.`iRetailid` = `c`.`id`)))
where (`c`.`iPresellState` <> 5);

-- comment on column v_rm_gatherretailvouch.id not supported: ID

-- comment on column v_rm_gatherretailvouch.cCode not supported: 单据编号

-- comment on column v_rm_gatherretailvouch.vouchdate not supported: 单据日期

-- comment on column v_rm_gatherretailvouch.iStoreid not supported: 门店id

-- comment on column v_rm_gatherretailvouch.cStoreCode not supported: 门店代码

-- comment on column v_rm_gatherretailvouch.cMachineid not supported: 收银机id

-- comment on column v_rm_gatherretailvouch.iOrgid not supported: 组织

-- comment on column v_rm_gatherretailvouch.tenant_id not supported: 租户

-- comment on column v_rm_gatherretailvouch.iDepartmentid not supported: 部门id

-- comment on column v_rm_gatherretailvouch.dDate not supported: 业务日期

-- comment on column v_rm_gatherretailvouch.iGradeid not supported: 班次id

-- comment on column v_rm_gatherretailvouch.iNegative not supported: 退货状态

-- comment on column v_rm_gatherretailvouch.bHangUp not supported: 是否挂单

-- comment on column v_rm_gatherretailvouch.iMemberid not supported: 会员id

-- comment on column v_rm_gatherretailvouch.cMemberCode not supported: 会员号

-- comment on column v_rm_gatherretailvouch.iMaker not supported: 制单人

-- comment on column v_rm_gatherretailvouch.fGatheringMoney not supported: 收款金额

-- comment on column v_rm_gatherretailvouch.iCoRetailid not supported: 退货原单id

-- comment on column v_rm_gatherretailvouch.fVIPRate not supported: 会员扣率

-- comment on column v_rm_gatherretailvouch.fDiscountRate not supported: 整单折扣率

-- comment on column v_rm_gatherretailvouch.fDiscountMoney not supported: 整单折扣额

-- comment on column v_rm_gatherretailvouch.fEffaceMoney not supported: 抹零折扣额

-- comment on column v_rm_gatherretailvouch.iRelatingRetailid not supported: 关联单据id

-- comment on column v_rm_gatherretailvouch.dMakeDate not supported: 制单日期

-- comment on column v_rm_gatherretailvouch.fbitSettle not supported: 日结状态

-- comment on column v_rm_gatherretailvouch.fPointCurrent not supported: 本单积分

-- comment on column v_rm_gatherretailvouch.fPointBalance not supported: 积分余额

-- comment on column v_rm_gatherretailvouch.fCardBalance not supported: 储值卡账户余额

-- comment on column v_rm_gatherretailvouch.dPlanShipmentDate not supported: 预计发货日期

-- comment on column v_rm_gatherretailvouch.dShipmentDate not supported: 实际发货日期

-- comment on column v_rm_gatherretailvouch.cRemark not supported: 备注

-- comment on column v_rm_gatherretailvouch.iPresellState not supported: 预订单状态

-- comment on column v_rm_gatherretailvouch.iDeliveryState not supported: 交货状态

-- comment on column v_rm_gatherretailvouch.iPayState not supported: 收款状态

-- comment on column v_rm_gatherretailvouch.iTakeway not supported: 提货方式

-- comment on column v_rm_gatherretailvouch.bDeliveryModify not supported: 交货时可修改商品

-- comment on column v_rm_gatherretailvouch.bPreselllockStock not supported: 预订占用可用量

-- comment on column v_rm_gatherretailvouch.fVIPDiscountSum not supported: 会员折扣额

-- comment on column v_rm_gatherretailvouch.fPromotionSum not supported: 促销折扣额

-- comment on column v_rm_gatherretailvouch.fSceneDiscountSum not supported: 现场折扣额

-- comment on column v_rm_gatherretailvouch.fGiftApportion not supported: 优惠券折扣额

-- comment on column v_rm_gatherretailvouch.fSaleMoney not supported: 应售金额合计

-- comment on column v_rm_gatherretailvouch.fMoneySum not supported: 实销金额合计

-- comment on column v_rm_gatherretailvouch.fQuantitySum not supported: 实销数量合计

-- comment on column v_rm_gatherretailvouch.fPresellPayMoney not supported: 预定已支付金额合计

-- comment on column v_rm_gatherretailvouch.iDeliveryStoreid not supported: 交货门店id

-- comment on column v_rm_gatherretailvouch.iDeliveryWarehouseid not supported: 交货仓库

-- comment on column v_rm_gatherretailvouch.fPointPay not supported: 抵款积分

-- comment on column v_rm_gatherretailvouch.fPointPayMoney not supported: 积分抵款金额

-- comment on column v_rm_gatherretailvouch.iBusinesstypeid not supported: 业务类型

-- comment on column v_rm_gatherretailvouch.iProfitTo not supported: 预定业绩归属门店

-- comment on column v_rm_gatherretailvouch.cRegionCode not supported: 收货地区

-- comment on column v_rm_gatherretailvouch.cDeliveradd not supported: 收货人地址

-- comment on column v_rm_gatherretailvouch.cCusperson not supported: 收货联系人

-- comment on column v_rm_gatherretailvouch.cMobileNo not supported: 收货人手机号

-- comment on column v_rm_gatherretailvouch.fCardDisApportion not supported: 回收分摊储值卡折扣金额

-- comment on column v_rm_gatherretailvouch.fCardApportion not supported: 回收分摊储值卡实销金额

-- comment on column v_rm_gatherretailvouch.bRequireOver not supported: 要货后标记状态

-- comment on column v_rm_gatherretailvouch.blocalSale not supported: 本店销售

-- comment on column v_rm_gatherretailvouch.blocaDelivery not supported: 本店交货

-- comment on column v_rm_gatherretailvouch.iChangeUser not supported: 变更人

-- comment on column v_rm_gatherretailvouch.dChangeTime not supported: 变更时间

-- comment on column v_rm_gatherretailvouch.bRestore not supported: 是否补单

-- comment on column v_rm_gatherretailvouch.create_time not supported: 创建时间

-- comment on column v_rm_gatherretailvouch.create_date not supported: 创建日期

-- comment on column v_rm_gatherretailvouch.modify_time not supported: 修改时间

-- comment on column v_rm_gatherretailvouch.modify_date not supported: 修改日期

-- comment on column v_rm_gatherretailvouch.creator not supported: 创建人

-- comment on column v_rm_gatherretailvouch.modifier not supported: 修改人

-- comment on column v_rm_gatherretailvouch.auditor not supported: 审批人

-- comment on column v_rm_gatherretailvouch.audit_time not supported: 审批时间

-- comment on column v_rm_gatherretailvouch.audit_date not supported: 审批日期

-- comment on column v_rm_gatherretailvouch.tplid not supported: 模板id

-- comment on column v_rm_gatherretailvouch.status not supported: 单据状态

-- comment on column v_rm_gatherretailvouch.pubts not supported: 时间戳

-- comment on column v_rm_gatherretailvouch.fDiscountSum not supported: 折扣额

-- comment on column v_rm_gatherretailvouch.fQuoteMoneySum not supported: 零售金额

-- comment on column v_rm_gatherretailvouch.fCoQuantitySum not supported: 已退货数量合计

-- comment on column v_rm_gatherretailvouch.dPresellDate not supported: 预订日期

-- comment on column v_rm_gatherretailvouch.fChangeMoney not supported: 找零金额

-- comment on column v_rm_gatherretailvouch.fbitReport not supported: 日报状态

-- comment on column v_rm_gatherretailvouch.cLogisticid not supported: 物流公司id

-- comment on column v_rm_gatherretailvouch.cLogisticsNo not supported: 快递单号

-- comment on column v_rm_gatherretailvouch.cCourierid not supported: 配送人id

-- comment on column v_rm_gatherretailvouch.cCourierPhone not supported: 配送人手机

-- comment on column v_rm_gatherretailvouch.iOwesState not supported: 赊销状态

-- comment on column v_rm_gatherretailvouch.iCustomerid not supported: 客户id

-- comment on column v_rm_gatherretailvouch.cGUID not supported: 离线保存ID

-- comment on column v_rm_gatherretailvouch.ioffline not supported: 网络状态

-- comment on column v_rm_gatherretailvouch.fSellerPointBalance not supported: 商家积分余额

-- comment on column v_rm_gatherretailvouch.fSellerPointCurrent not supported: 本单商家积分

-- comment on column v_rm_gatherretailvouch.fSellerPointPay not supported: 商家抵款积分

-- comment on column v_rm_gatherretailvouch.printCount not supported: 打印次数

-- comment on column v_rm_gatherretailvouch.iEInvoiceState not supported: 开票状态

-- comment on column v_rm_gatherretailvouch.cEInvoiceURL not supported: 开票网址

-- comment on column v_rm_gatherretailvouch.bCoEInvoiceOver not supported: 退货行已开票

-- comment on column v_rm_gatherretailvouch.cRetailURL not supported: 零售网址

-- comment on column v_rm_gatherretailvouch.iCoEInvoiceWay not supported: 非原单退货行处理方式

-- comment on column v_rm_gatherretailvouch.dEInvoiceEndData not supported: 开票截至日期

-- comment on column v_rm_gatherretailvouch.iPrcsStatus not supported: 加工状态

-- comment on column v_rm_gatherretailvouch.handMakeInvoicePeo not supported: 手工开票人

-- comment on column v_rm_gatherretailvouch.handMakeInvoiceTime not supported: 手工开票时间

-- comment on column v_rm_gatherretailvouch.bAmountAdjustment not supported: 金额调整

-- comment on column v_rm_gatherretailvouch.bGiveawayList not supported: 赠品单

-- comment on column v_rm_gatherretailvouch.bcustomizedOrder not supported: 来源定制单

-- comment on column v_rm_gatherretailvouch.bReturnStore not supported: 退回门店

-- comment on column v_rm_gatherretailvouch.iReturnWarehousid not supported: 退货仓库id

-- comment on column v_rm_gatherretailvouch.iGiveawayListRetailid not supported: 赠品单关联零售单id

-- comment on column v_rm_gatherretailvouch.iAmountAdjustRetailid not supported: 金额调整关联零售单号

-- comment on column v_rm_gatherretailvouch.iGatheringType not supported: 收款模式

-- comment on column v_rm_gatherretailvouch.bUnsubscribe not supported: 可退订

-- comment on column v_rm_gatherretailvouch.unsubscribeReason not supported: 可否退订原因

-- comment on column v_rm_gatherretailvouch.outOrg not supported: 发货组织id

-- comment on column v_rm_gatherretailvouch.bGiveawayListGenerated not supported: 是否已生成赠品单

-- comment on column v_rm_gatherretailvouch.bExtendHeader not supported: 是否扩展表头

-- comment on column v_rm_gatherretailvouch.bExtendBody not supported: 是否扩展表体

-- comment on column v_rm_gatherretailvouch.iAmountAdjustNum not supported: 金额调整次数

-- comment on column v_rm_gatherretailvouch.billNo not supported: 外部系统单号

-- comment on column v_rm_gatherretailvouch.room not supported: 房间id

-- comment on column v_rm_gatherretailvouch.iProcessingState not supported: 处理状态

-- comment on column v_rm_gatherretailvouch.cPickCode not supported: 提货码

-- comment on column v_rm_gatherretailvouch.oldroom not supported: 原房间id

-- comment on column v_rm_gatherretailvouch.dRoomturnDate not supported: 转房时间

-- comment on column v_rm_gatherretailvouch.ibillSource not supported: 单据来源

-- comment on column v_rm_gatherretailvouch.esignature not supported: 电子签名

-- comment on column v_rm_gatherretailvouch.iposid not supported: 终端设备id

-- comment on column v_rm_gatherretailvouch.iCabinetgroup not supported: 柜组

-- comment on column v_rm_gatherretailvouch.iCabinetgroupType not supported: 柜组类型

-- comment on column v_rm_gatherretailvouch.fScanDiscountSum not supported: 扫码折扣额合计

-- comment on column v_rm_gatherretailvouch.bExport not supported: 是否上传U会员

-- comment on column v_rm_gatherretailvouch.cStoreRemark not supported: 门店备注

-- comment on column v_rm_gatherretailvouch.iUnravelState not supported: 拆单结算

-- comment on column v_rm_gatherretailvouch.iGatheringid not supported: ID

-- comment on column v_rm_gatherretailvouch.fAmount not supported: 核销金额

