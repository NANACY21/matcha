create definer = root@`%` view productextendview as
select `b`.`id`                         AS `id`,
       `b`.`productApplyRangeId`        AS `productApplyRangeId`,
       `b`.`purchaseUnitId`             AS `purchaseUnitId`,
       `b`.`purchaseRate`               AS `purchaseRate`,
       `b`.`stockUnitId`                AS `stockUnitId`,
       `b`.`stockRate`                  AS `stockRate`,
       `b`.`batchUnitId`                AS `batchUnitId`,
       `b`.`batchRate`                  AS `batchRate`,
       `b`.`onlineUnitId`               AS `onlineUnitId`,
       `b`.`onlineRate`                 AS `onlineRate`,
       `b`.`offlineUnitId`              AS `offlineUnitId`,
       `b`.`offlineRate`                AS `offlineRate`,
       `b`.`requireUnitId`              AS `requireUnitId`,
       `b`.`requireRate`                AS `requireRate`,
       `b`.`batchPriceUnitId`           AS `batchPriceUnitId`,
       `b`.`batchPriceRate`             AS `batchPriceRate`,
       `b`.`batchPrice`                 AS `batchPrice`,
       `b`.`fMarkPrice`                 AS `fMarkPrice`,
       `b`.`fLowestMarkPrice`           AS `fLowestMarkPrice`,
       `b`.`fSalePrice`                 AS `fSalePrice`,
       `b`.`fMarketPrice`               AS `fMarketPrice`,
       `b`.`fPrimeCosts`                AS `fPrimeCosts`,
       `b`.`fSettleAccountsRate`        AS `fSettleAccountsRate`,
       `b`.`isDisplayPrice`             AS `isDisplayPrice`,
       `b`.`priceAreaMessage`           AS `priceAreaMessage`,
       `b`.`isBatchManage`              AS `isBatchManage`,
       `b`.`isExpiryDateManage`         AS `isExpiryDateManage`,
       `b`.`expireDateNo`               AS `expireDateNo`,
       `b`.`expireDateUnit`             AS `expireDateUnit`,
       `b`.`isSerialNoManage`           AS `isSerialNoManage`,
       `b`.`weight`                     AS `weight`,
       `b`.`volume`                     AS `volume`,
       `b`.`safetyStock`                AS `safetyStock`,
       `b`.`highestStock`               AS `highestStock`,
       `b`.`lowestStock`                AS `lowestStock`,
       `b`.`ropStock`                   AS `ropStock`,
       `b`.`canSale`                    AS `canSale`,
       `b`.`iMinOrderQuantity`          AS `iMinOrderQuantity`,
       `b`.`deliveryDays`               AS `deliveryDays`,
       `b`.`uorderDlyFeeRuleId`         AS `uorderDlyFeeRuleId`,
       `b`.`iEnableCyclePurchase`       AS `iEnableCyclePurchase`,
       `b`.`enableDeposit`              AS `enableDeposit`,
       `b`.`depositDealPayType`         AS `depositDealPayType`,
       `b`.`deposits`                   AS `deposits`,
       `b`.`depositPercentage`          AS `depositPercentage`,
       `b`.`enablemodifyDeposit`        AS `enablemodifyDeposit`,
       `b`.`minimumDeposits`            AS `minimumDeposits`,
       `b`.`depositPayType`             AS `depositPayType`,
       `b`.`pageTitle`                  AS `pageTitle`,
       `b`.`metaDescription`            AS `metaDescription`,
       `b`.`salePoints`                 AS `salePoints`,
       `b`.`lInventoryCount`            AS `lInventoryCount`,
       `b`.`dlyFeeRuleId`               AS `dlyFeeRuleId`,
       `b`.`iBaseSaleCount`             AS `iBaseSaleCount`,
       `b`.`isAllArea`                  AS `isAllArea`,
       `b`.`iEnableEcontract`           AS `iEnableEcontract`,
       `b`.`allowStorePurchase`         AS `allowStorePurchase`,
       `b`.`isPriceChangeAllowed`       AS `isPriceChangeAllowed`,
       `b`.`isSaleInOfflineStore`       AS `isSaleInOfflineStore`,
       `b`.`isOfflineStoreOrder`        AS `isOfflineStoreOrder`,
       `b`.`isOfflineStoreReturn`       AS `isOfflineStoreReturn`,
       `b`.`isWeight`                   AS `isWeight`,
       `b`.`isProcess`                  AS `isProcess`,
       `b`.`iProcessType`               AS `iProcessType`,
       `b`.`isMaterial`                 AS `isMaterial`,
       `b`.`retailPriceDimension`       AS `retailPriceDimension`,
       `b`.`fNoTaxCostPrice`            AS `fNoTaxCostPrice`,
       `b`.`checkByBatch`               AS `checkByBatch`,
       `b`.`iStatus`                    AS `iStatus`,
       `b`.`iUOrderStatus`              AS `iUOrderStatus`,
       `b`.`mallUpTime`                 AS `mallUpTime`,
       `b`.`uorderUpTime`               AS `uorderUpTime`,
       `b`.`mallupcount`                AS `mallupcount`,
       `b`.`malldowncount`              AS `malldowncount`,
       `b`.`uorderupcount`              AS `uorderupcount`,
       `b`.`uorderdowncount`            AS `uorderdowncount`,
       `b`.`minBatchPrice`              AS `minBatchPrice`,
       `b`.`maxBatchPrice`              AS `maxBatchPrice`,
       `b`.`pubts`                      AS `pubts`,
       `b`.`tenant_id`                  AS `tenant_id`,
       `b`.`saleChannel`                AS `saleChannel`,
       `b`.`saleChannelOfOnlineBatch`   AS `saleChannelOfOnlineBatch`,
       `b`.`saleChannelOfOnlineRetail`  AS `saleChannelOfOnlineRetail`,
       `b`.`saleChannelOfOfflineRetail` AS `saleChannelOfOfflineRetail`,
       `b`.`saleChannelOfDistribution`  AS `saleChannelOfDistribution`,
       `b`.`cBarCode`                   AS `cBarCode`,
       `b`.`stopstatus`                 AS `stopstatus`,
       `b`.`stop_time`                  AS `stop_time`,
       `b`.`isCheckFree`                AS `isCheckFree`,
       `a`.`inTaxrate`                  AS `inTaxrate`,
       `a`.`mnemonicCode`               AS `mnemonicCode`,
       `b`.`deliverQuantityChange`      AS `deliverQuantityChange`,
       `b`.`fInStoreExcessLimit`        AS `fInStoreExcessLimit`
from (`ugoods`.`product` `a`
         left join `ugoods`.`productextend` `b` on ((`a`.`id` = `b`.`id`)));

-- comment on column productextendview.id not supported: 商品ID

-- comment on column productextendview.productApplyRangeId not supported: 商品分配范围ID

-- comment on column productextendview.purchaseUnitId not supported: 采购单位

-- comment on column productextendview.purchaseRate not supported: 采购单位换算率

-- comment on column productextendview.stockUnitId not supported: 库存单位

-- comment on column productextendview.stockRate not supported: 库存单位换算率

-- comment on column productextendview.batchUnitId not supported: 批发单位

-- comment on column productextendview.batchRate not supported: 批发单位换算率

-- comment on column productextendview.onlineUnitId not supported: 线上零售单位

-- comment on column productextendview.onlineRate not supported: 线上零售单位换算率

-- comment on column productextendview.offlineUnitId not supported: 线下零售单位

-- comment on column productextendview.offlineRate not supported: 线下零售单位换算率

-- comment on column productextendview.requireUnitId not supported: 要货单位

-- comment on column productextendview.requireRate not supported: 要货单位换算率

-- comment on column productextendview.batchPriceUnitId not supported: 批发报价单位

-- comment on column productextendview.batchPriceRate not supported: 批发报价单位换算率

-- comment on column productextendview.fSettleAccountsRate not supported: 结算费率

-- comment on column productextendview.isDisplayPrice not supported: 线上商城显示价格

-- comment on column productextendview.priceAreaMessage not supported: 线上不显示价格时，需要显示的提示信息

-- comment on column productextendview.isBatchManage not supported: 库存-是否批次管理

-- comment on column productextendview.isExpiryDateManage not supported: 库存-是否有效期管理

-- comment on column productextendview.expireDateNo not supported: 库存-保质期

-- comment on column productextendview.expireDateUnit not supported: 库存-保质期单位

-- comment on column productextendview.isSerialNoManage not supported: 库存-是否序列号管理

-- comment on column productextendview.weight not supported: 库存-重量

-- comment on column productextendview.volume not supported: 库存-体积

-- comment on column productextendview.safetyStock not supported: 库存-安全库存

-- comment on column productextendview.highestStock not supported: 库存-最高库存

-- comment on column productextendview.lowestStock not supported: 库存-最低库存

-- comment on column productextendview.ropStock not supported: 库存-再订货点

-- comment on column productextendview.canSale not supported: 批发-可售状态

-- comment on column productextendview.iMinOrderQuantity not supported: 批发-起订量

-- comment on column productextendview.deliveryDays not supported: 批发-交货周期（天）

-- comment on column productextendview.uorderDlyFeeRuleId not supported: 订货-运费模板

-- comment on column productextendview.iEnableCyclePurchase not supported: 商城-启用周期购

-- comment on column productextendview.enableDeposit not supported: 启用定金业务

-- comment on column productextendview.depositDealPayType not supported: 商城-定金设置类型

-- comment on column productextendview.depositPercentage not supported: 商城-预付定金百分比

-- comment on column productextendview.enablemodifyDeposit not supported: 商城-订单改价时可修改定金

-- comment on column productextendview.depositPayType not supported: 商城-支付尾款方式

-- comment on column productextendview.pageTitle not supported: 商城-SEO设置相关

-- comment on column productextendview.metaDescription not supported: 商城-搜索简介

-- comment on column productextendview.salePoints not supported: 商城-积分数量

-- comment on column productextendview.lInventoryCount not supported: 商城-线上库存量

-- comment on column productextendview.dlyFeeRuleId not supported: 商城-运费模板

-- comment on column productextendview.iBaseSaleCount not supported: 商城-初始销量

-- comment on column productextendview.isAllArea not supported: 商城-是否适用所有区域

-- comment on column productextendview.iEnableEcontract not supported: 商城-是否启用合同管理

-- comment on column productextendview.allowStorePurchase not supported: 零售-允许门店自采

-- comment on column productextendview.isPriceChangeAllowed not supported: 零售-允许开单改价

-- comment on column productextendview.isSaleInOfflineStore not supported: 零售-允许门店销售

-- comment on column productextendview.isOfflineStoreOrder not supported: 零售-允许门店要货

-- comment on column productextendview.isOfflineStoreReturn not supported: 零售-允许门店退货

-- comment on column productextendview.isWeight not supported: 零售-是否称重

-- comment on column productextendview.isProcess not supported: 零售-加工

-- comment on column productextendview.isMaterial not supported: 零售-材料

-- comment on column productextendview.retailPriceDimension not supported: 零售-零售取价维度

-- comment on column productextendview.checkByBatch not supported: 成本-按批次核算

-- comment on column productextendview.iStatus not supported: 商城上下架状态

-- comment on column productextendview.iUOrderStatus not supported: U订货上下架状态

-- comment on column productextendview.mallUpTime not supported: 商城上架时间

-- comment on column productextendview.uorderUpTime not supported: U订货上架时间

-- comment on column productextendview.mallupcount not supported: 商城上架数量

-- comment on column productextendview.malldowncount not supported: 商城下架数量

-- comment on column productextendview.uorderupcount not supported: U订货上架数量

-- comment on column productextendview.uorderdowncount not supported: U订货下架数量

-- comment on column productextendview.minBatchPrice not supported: 最低批发价格

-- comment on column productextendview.maxBatchPrice not supported: 最高批发价格

-- comment on column productextendview.pubts not supported: 时间戳

-- comment on column productextendview.tenant_id not supported: 租户

-- comment on column productextendview.saleChannel not supported: 销售渠道

-- comment on column productextendview.saleChannelOfOnlineBatch not supported: 销售渠道-线上批发

-- comment on column productextendview.saleChannelOfOnlineRetail not supported: 销售渠道-线上零售

-- comment on column productextendview.saleChannelOfOfflineRetail not supported: 销售渠道-线下零售

-- comment on column productextendview.saleChannelOfDistribution not supported: 销售渠道-微分销

-- comment on column productextendview.cBarCode not supported: 条形码

-- comment on column productextendview.stopstatus not supported: 停用状态

-- comment on column productextendview.stop_time not supported: 停用时间

-- comment on column productextendview.isCheckFree not supported: 成本-按规格核算成本

-- comment on column productextendview.inTaxrate not supported: 进项税率（%）

-- comment on column productextendview.mnemonicCode not supported: 助记码

-- comment on column productextendview.deliverQuantityChange not supported: 零售-交货数量改变时

-- comment on column productextendview.fInStoreExcessLimit not supported: 库存-入库超量上限%

