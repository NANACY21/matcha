create
    definer = root@`%` procedure ypj_addbillRule(IN rtn int)
begin  
    IF rtn is NOT NULL   THEN  


		##店内加工入库单增加单据编号处理 0租户
		delete from aa_billnumber where cbillnum='rm_receiving_differences' and tenant_id=0;
		INSERT INTO aa_billnumber (`cbillnum`,`orgid`,`cbillname`,`csubid`,`ballowhandwork`,`brepeatredo`,`istartnumber`,`iseriallen`,`billnumLen`,`billnumInit`,`billnumTruncatType`,`billnumFillType`,`billnumFillMark`,`billnumMode`,`billnumRule`,`tenant_id`)
		VALUES ('rm_receiving_differences',-1,'收货差异单','ST',0,1,1,4,8,1,0,1,0,0,0,0);

		delete from aa_billprefix where cbillnum='rm_receiving_differences' and tenant_id=0;
		delete from aa_billprefabricate where cbillnum='rm_receiving_differences' and tenant_id=0;

		select uuid() into @fixid;
		INSERT INTO aa_billprefix (`cbillnum`,`orgid`,`cprefix`,`iprefixlen`,`cprefixrule`,`cprefixseed`,`iorder`,`bfix`,`cprefixid`,`cprefixtype`,`cprefixsep`,`tenant_id`)
		VALUES ('rm_receiving_differences',-1,'手工输入',4,'SHCY',null,1,0,@fixid,2,null,0);
		INSERT INTO aa_billprefabricate (`cbillnum`,`cprefix`,`cprefixid`,`cprefixtype`,`cfieldname`,`csourcename`,`iprefixtype`,`ipurpose`,`carchname`,`carchfieldname`,`carchclsfieldname`,`ckeyword`,`ckeywordnamefield`,`tenant_id`)
		VALUES ('rm_receiving_differences','手工输入',@fixid,2,null,null,2,null,null,null,null,null,null,0);

		select uuid() into @fixid;
		INSERT INTO aa_billprefix (`cbillnum`,`orgid`,`cprefix`,`iprefixlen`,`cprefixrule`,`cprefixseed`,`iorder`,`bfix`,`cprefixid`,`cprefixtype`,`cprefixsep`,`tenant_id`)
		VALUES ('rm_receiving_differences',-1,'门店代码',4,null,null,2,1,@fixid,2,null,0);
		INSERT INTO aa_billprefabricate (`cbillnum`,`cprefix`,`cprefixid`,`cprefixtype`,`cfieldname`,`csourcename`,`iprefixtype`,`ipurpose`,`carchname`,`carchfieldname`,`carchclsfieldname`,`ckeyword`,`ckeywordnamefield`,`tenant_id`)
		VALUES ('rm_receiving_differences','门店代码',@fixid,0,'store_code','st.storeprorecord.StoreProRecord',0,null,null,null,null,null,null,0);

		select uuid() into @fixid;
		INSERT INTO aa_billprefix (`cbillnum`,`orgid`,`cprefix`,`iprefixlen`,`cprefixrule`,`cprefixseed`,`iorder`,`bfix`,`cprefixid`,`cprefixtype`,`cprefixsep`,`tenant_id`)
		VALUES ('rm_receiving_differences',-1,'单据日期',8,'年月日','日',3,1,@fixid,2,null,0);
		INSERT INTO aa_billprefabricate (`cbillnum`,`cprefix`,`cprefixid`,`cprefixtype`,`cfieldname`,`csourcename`,`iprefixtype`,`ipurpose`,`carchname`,`carchfieldname`,`carchclsfieldname`,`ckeyword`,`ckeywordnamefield`,`tenant_id`)
		VALUES ('rm_receiving_differences','单据日期',@fixid,1,'vouchdate','st.storeprorecord.StoreProRecord',1,null,null,null,null,null,null,0);



		##升级 店内加工入库单增加单据编号处理 非0租户
		delete from aa_billnumber where cbillnum='rm_receiving_differences' and tenant_id<>0;
		INSERT INTO aa_billnumber (`cbillnum`,`orgid`,`cbillname`,`csubid`,`ballowhandwork`,`brepeatredo`,`istartnumber`,`iseriallen`,`billnumLen`,`billnumInit`,`billnumTruncatType`,`billnumFillType`,`billnumFillMark`,`billnumMode`,`billnumRule`,`tenant_id`)
		select cbillnum,orgid,cbillname,csubid,ballowhandwork,brepeatredo,istartnumber,iseriallen,billnumLen,billnumInit,billnumTruncatType,billnumFillType,billnumFillMark,billnumMode,billnumRule,tenant.id
				from aa_billnumber 
				left join tenant on 1=1 and tenant.id<>0
				where cbillnum='rm_receiving_differences' and tenant_id=0;

		delete from aa_billprefix where cbillnum='rm_receiving_differences' and tenant_id<>0;
		INSERT INTO aa_billprefix (`cbillnum`,`orgid`,`cprefix`,`iprefixlen`,`cprefixrule`,`cprefixseed`,`iorder`,`bfix`,`cprefixid`,`cprefixtype`,`cprefixsep`,`tenant_id`)
		select cbillnum,orgid,cprefix,iprefixlen,cprefixrule,cprefixseed,iorder,bfix,cprefixid,cprefixtype,cprefixsep,tenant.id
				from aa_billprefix 
				left join tenant on 1=1 and tenant.id<>0
				where cbillnum='rm_receiving_differences' and tenant_id=0;

		delete from aa_billprefabricate where cbillnum='rm_receiving_differences' and tenant_id<>0;
		INSERT INTO aa_billprefabricate (`cbillnum`,`cprefix`,`cprefixid`,`cprefixtype`,`cfieldname`,`csourcename`,`iprefixtype`,`ipurpose`,`carchname`,`carchfieldname`,`carchclsfieldname`,`ckeyword`,`ckeywordnamefield`,`tenant_id`)
		select cbillnum,cprefix,cprefixid,cprefixtype,cfieldname,csourcename,iprefixtype,ipurpose,carchname,carchfieldname,carchclsfieldname,ckeyword,ckeywordnamefield,tenant.id
				from aa_billprefabricate 
				left join tenant on 1=1 and tenant.id<>0
				where cbillnum='rm_receiving_differences' and tenant_id=0;


END IF;  
end;

