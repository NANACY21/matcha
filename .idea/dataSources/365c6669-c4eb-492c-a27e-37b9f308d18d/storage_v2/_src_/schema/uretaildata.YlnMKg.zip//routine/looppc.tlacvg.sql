create
    definer = root@`%` procedure looppc()
begin
declare i int; 
set i = 1; 
 
repeat 
set @item = CONCAT('商品规格' , CONVERT(i,CHAR));
set @classId = CONCAT('free' , CONVERT(i,CHAR));
 
INSERT INTO `uretaildata`.`userdef_base` ( `classname`, `classId`, `type`, `item`, `length`, `maxinputlen`, `decimaldigits`, `ismultisel`, `isinput`, `isenabled`, `tenant_id`, `pubts`, `isdeleted`) 
VALUES ('商品档案', @classId, NULL, @item, '255', '255', NULL, '0', '0', NULL, '339449620091136', now(), '0');
  
set i = i + 1; 
until i > 10  
end repeat;  
 
end;

