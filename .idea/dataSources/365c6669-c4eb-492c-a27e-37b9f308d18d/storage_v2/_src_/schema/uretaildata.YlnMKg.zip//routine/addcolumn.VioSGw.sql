create
    definer = root@`%` procedure addcolumn()
BEGIN 
	IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = 'rm_retailvouchdetailextend' AND column_name = 'sIsBack') THEN
		alter table `rm_retailvouchdetailextend`  add COLUMN `sIsBack` int(10) ;
	end if ;
END;

