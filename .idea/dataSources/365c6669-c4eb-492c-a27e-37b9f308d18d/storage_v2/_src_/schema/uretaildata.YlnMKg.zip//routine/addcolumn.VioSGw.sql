create
    definer = root@`%` procedure addcolumn()
BEGIN 
	IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = 'rm_retailvouchdetailextend' AND column_name = 'mainPriceFromSub') THEN
		alter table `rm_retailvouchdetailextend`  add COLUMN `mainPriceFromSub` tinyint(1) default 0;
	end if ;
END;

