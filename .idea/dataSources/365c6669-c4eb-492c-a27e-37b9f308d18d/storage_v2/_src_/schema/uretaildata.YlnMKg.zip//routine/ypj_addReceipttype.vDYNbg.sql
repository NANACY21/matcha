create
    definer = root@`%` procedure ypj_addReceipttype(IN rtn int)
begin  
    IF rtn is NOT NULL   THEN  
	
	DELETE FROM aa_receipttype WHERE code ='S10' and name ='收货差异';

	select ifnull(max(id),0)+1 into @bus_id1 from aa_receipttype;
	INSERT INTO `uretaildata`.`aa_receipttype`(`memo`, `parent_id`, `level`, `path`, `sort_num`, `isEnd`, `code`, `name`, `tenant_id`, `id`, `pubts`) 
	SELECT '', NULL, 1,  CONCAT(id , '|'), 0, b'1', 'S10', '收货差异', id, @bus_id1, now() from tenant where id<>0
	UNION
	SELECT '', NULL, 1,  CONCAT(0 , '|'), 0, b'1', 'S10', '收货差异', 0, @bus_id1, now() 
	;

	DELETE FROM aa_businesstype WHERE code ='S10001' and name ='收货差异';
	INSERT INTO `uretaildata`.`aa_businesstype`(`receipttype_id`, `erpcode`, `saletype`, `isPreCalcBalance`, `isDistribCenter`, `isUpdItemBySend`, `isDefault`, `MinPercentGiveMoneyPre`, `storeType`, `allocateModel`, `otherOutType`, `storeOutType`, `otherInType`, `storeInType`, `gatheringType`, `isSaveAndAudit`, `isSystem`, `memo`, `create_time`, `create_date`, `modify_time`, `modify_date`, `creator`, `modifier`, `stopstatus`, `stop_time`, `code`, `name`, `tenant_id`,  `pubts`, `noticemodel`, `requireItemModel`, `checkType`, `bPurchaseAmountSend`, `materialOutType`, `stockCType`, `procurement_id`, `salesOutType`, `madeType`, `controlType`, `retailSource`, `mcType`, `inwhErpCode`, `depositType`, `iOwesState`, `ipushbustypeid`)
	SELECT @bus_id1, '', NULL, b'0', NULL, b'0', b'0', 0.00000000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, b'0', b'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, b'0', NULL, 'S10001', '收货差异', id,  now(), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, b'1', NULL from tenant where id<>0
	UNION
	SELECT @bus_id1, '', NULL, b'0', NULL, b'0', b'0', 0.00000000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, b'0', b'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, b'0', NULL, 'S10001', '收货差异', 0,  now(), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, b'1', NULL from tenant where id<>0
	;

END IF;  
end;

