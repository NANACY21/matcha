create
    definer = uretail@`192.168.1.%` function fn_yearweek(d datetime) returns int
BEGIN
	

	RETURN YEARWEEK(d);
END;

