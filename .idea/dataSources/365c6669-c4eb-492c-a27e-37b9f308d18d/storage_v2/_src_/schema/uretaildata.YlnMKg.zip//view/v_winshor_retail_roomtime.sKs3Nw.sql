create definer = root@`%` view v_winshor_retail_roomtime as
select `h`.`id`                                 AS `id`,
       `h`.`room`                               AS `room`,
       min(replace(`dc`.`cDefineB1`, '/', '-')) AS `begintime`,
       max(replace(`dc`.`cDefineB2`, '/', '-')) AS `endtime`,
       `hd`.`cDefineH8`                         AS `timeperiod`
from (((`uretaildata`.`rm_retailvouch` `h` left join `uretaildata`.`rm_retailvouchcustom` `hd` on ((`h`.`id` = `hd`.`iRetailVouchId`))) left join `uretaildata`.`rm_retailvouchdetail` `d` on ((`h`.`id` = `d`.`iRetailid`)))
         left join `uretaildata`.`rm_retailvouchdetailcustom` `dc` on ((`d`.`id` = `dc`.`iRetailVouchDetailId`)))
where ((`d`.`iReturnStatus` <> '2') and (`dc`.`cDefineB1` is not null))
group by `h`.`id`, `h`.`room`;

-- comment on column v_winshor_retail_roomtime.id not supported: ID

-- comment on column v_winshor_retail_roomtime.room not supported: 房间id

-- comment on column v_winshor_retail_roomtime.timeperiod not supported: 自定义项8

