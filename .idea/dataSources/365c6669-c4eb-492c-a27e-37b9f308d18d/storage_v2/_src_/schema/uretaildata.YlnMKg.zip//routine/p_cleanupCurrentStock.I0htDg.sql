create
    definer = root@`%` procedure p_cleanupCurrentStock(IN tenantid bigint)
begin
	
	
    declare var_iGroup_ID bigint;
    declare var_cMainTable varchar(200);
	declare var_cDeteilTable varchar(200);
	declare var_cMainId varchar(200);
	declare var_cdefWhere varchar(1000);
	declare var_iBillDirection int;
    declare var_cTableFieldname varchar(1200);
	declare var_cStockTableField varchar(1200);
	declare var_cCalFormulasSql varchar(1000);    
	declare var_bMain smallint; 
	declare var_billFieldSql varchar(4000);
	declare var_StockFieldSql varchar(4000);
	declare var_FromJoinTable varchar(1000);
    DECLARE done int DEFAULT 0;
    
    declare cur1 CURSOR FOR select id,cMainTable,cDeteilTable,cMainId,cdefWhere,iBillDirection from st_billtostockgroup;
    
    declare cur2 CURSOR FOR select cTableFieldname,cStockTableField,cCalFormulasSql,bMain from st_billtostockgroup_item where iGroup_ID=var_iGroup_ID ;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
 	
	drop TABLE if EXISTS tmp_currentstockdetails;
	CREATE TEMPORARY TABLE tmp_currentstockdetails SELECT * FROM currentstock where 1=2;  
    open cur1;
    read_loop: LOOP
        fetch cur1 into var_iGroup_ID,var_cMainTable,var_cDeteilTable,var_cMainId,var_cdefWhere,var_iBillDirection;
        IF done=1 THEN
			LEAVE read_loop;
        END IF;
        
        open cur2;
		set var_FromJoinTable="";
		set var_billFieldSql="";
		set var_StockFieldSql="";
        inner_loop: LOOP
            fetch cur2 into var_cTableFieldname,var_cStockTableField,var_cCalFormulasSql,var_bMain;
            IF done=1 THEN
				LEAVE inner_loop;
            END IF;
			if var_bMain=1 then
				set @tableprefix="main.";
			else
				set @tableprefix="details.";
			end if;
			
			if (var_cCalFormulasSql<>"" and var_cCalFormulasSql is not null) then 
				set var_cTableFieldname=var_cCalFormulasSql;
			elseif (substring(var_cStockTableField,1,4)="free" or var_cStockTableField='sBatchNo') then
				set var_cTableFieldname=concat(concat(concat("(case when ",concat(@tableprefix,var_cTableFieldname)),"='' then null else "),concat(concat(@tableprefix,var_cTableFieldname)," end)"));
			else
				set var_cTableFieldname=concat(@tableprefix,var_cTableFieldname);
			end if;
			if var_cStockTableField="fCurrentQty" or var_cStockTableField="fPreretailQty"  or var_cStockTableField="fInnoticeQty" then 
				set var_cTableFieldname=concat(concat(var_iBillDirection,"*"),var_cTableFieldname);
			end if;
			if var_billFieldSql="" then
				set var_billFieldSql=concat(var_billFieldSql,var_cTableFieldname);
			else
				set var_billFieldSql=concat(var_billFieldSql,concat(",",var_cTableFieldname));
			end if;
			if var_StockFieldSql="" then
				set var_StockFieldSql=concat(var_StockFieldSql,var_cStockTableField);
			else
				set var_StockFieldSql=concat(var_StockFieldSql,concat(",",var_cStockTableField));
			end if;
        END LOOP inner_loop;
        close cur2;
        
        
		set var_FromJoinTable=concat(" from ",var_cMainTable);
		set var_FromJoinTable=concat(var_FromJoinTable," main left join ");
		set var_FromJoinTable=concat(var_FromJoinTable,var_cDeteilTable);
		set var_FromJoinTable=concat(var_FromJoinTable," details on main.id=details.");
		set var_FromJoinTable=concat(var_FromJoinTable,var_cMainId);
		set var_FromJoinTable=concat(var_FromJoinTable," where main.tenant_id=");
		set var_FromJoinTable=concat(var_FromJoinTable,tenantid);

		if (var_cdefWhere is not null and var_cdefWhere<>"") then
			set var_FromJoinTable=concat(var_FromJoinTable,var_cdefWhere);
		end if;
		set @execSql="";
		set @execSql=concat("INSERT INTO tmp_currentstockdetails (",var_StockFieldSql);
		set @execSql=concat(@execSql,",tenant_id) select ");
		set @execSql=concat(@execSql,var_billFieldSql);
		set @execSql=concat(@execSql,",");
		set @execSql=concat(@execSql,tenantid);
		set @execSql=concat(@execSql,var_FromJoinTable); 
		
        prepare stmt from @execSql;  
        EXECUTE stmt;  
        deallocate prepare stmt;  
        
        
        SET done = 0;   
    END LOOP read_loop;
    close cur1;
	
	
	set @exeSql="";
	set @exeSql=concat("delete from currentstock where tenant_id=",tenantid);        
    prepare stmt from @exeSql;  
    EXECUTE stmt;  
    deallocate prepare stmt; 	
	
	set @exeSql="";
	set @exeSql="insert into currentstock (iWarehouseId,iStoreID,iProductId,iProductSkuId,dProduceDate,dInvalidDate,sBatchNo,fInnoticeQty,fCurrentQty,fPreretailQty,free1,free2,free3,free4,free5,free6,free7,free8,free9,free10,tenant_id) ";  
	set @exeSql=concat(@exeSql," select iWarehouseId,max(iStoreID) as iStoreID,iProductId,iProductSkuId,max(dProduceDate) dProduceDate,max(dInvalidDate) dInvalidDate,sBatchNo,sum(if(isnull(fInnoticeQty),0,fInnoticeQty)) as fInnoticeQty,sum(if(isnull(fCurrentQty),0,fCurrentQty)) as fCurrentQty,sum(if(isnull(fPreretailQty),0,fPreretailQty)) as fPreretailQty,free1,free2,free3,free4,free5,free6,free7,free8,free9,free10,");
	set @exeSql=concat(@exeSql,tenantid);
	set @exeSql=concat(@exeSql," from tmp_currentstockdetails group by iWarehouseId,iProductId,iProductSkuId,sBatchNo,free1,free2,free3,free4,free5,free6,free7,free8,free9,free10");
    prepare stmt from @exeSql;  
    EXECUTE stmt;  
    deallocate prepare stmt; 
	
	set @exeSql="";
	set @exeSql="delete from currentstock where fCurrentQty=0 and fInnoticeQty=0 and fPreretailQty=0 and tenant_id=";  
	set @exeSql=concat(@exeSql,tenantid);  
	prepare stmt from @exeSql;  
    EXECUTE stmt;  
    deallocate prepare stmt; 	
end;

