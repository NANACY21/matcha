create
    definer = root@`%` procedure updateaa_businesstype()
BEGIN 
	if not exists (select * from aa_businesstype where code = 'A40001' and isDefault=1 ) THEN
	    update aa_businesstype  set isDefault=1 where isSystem=1 and `code`='A40001'  and isDefault=0 ;
	end if ;
END;

