create definer = root@`%` view v_rm_gatherretailvouchdetail as
select `d`.`iRetailid`               AS `iRetailid`,
       `d`.`cProductid`              AS `cProductid`,
       `d`.`iSKUid`                  AS `iSKUid`,
       `d`.`iWarehouseid`            AS `iWarehouseid`,
       `d`.`cBatchNo`                AS `cBatchNo`,
       `d`.`iBathid`                 AS `iBathid`,
       `d`.`dProduceDate`            AS `dProduceDate`,
       `d`.`dInvalidDate`            AS `dInvalidDate`,
       `d`.`fQuantity`               AS `fQuantity`,
       `d`.`fMoney`                  AS `fMoney`,
       `d`.`fQuotePrice`             AS `fQuotePrice`,
       `d`.`fVIPPrice`               AS `fVIPPrice`,
       `d`.`fPrice`                  AS `fPrice`,
       `d`.`fDiscountRate`           AS `fDiscountRate`,
       `d`.`fDiscount`               AS `fDiscount`,
       `d`.`cMemo`                   AS `cMemo`,
       `d`.`iOrder`                  AS `iOrder`,
       `d`.`iEmployeeid`             AS `iEmployeeid`,
       `d`.`iSuperior`               AS `iSuperior`,
       `d`.`iCoRetailDetailId`       AS `iCoRetailDetailId`,
       `d`.`fCoQuantity`             AS `fCoQuantity`,
       `d`.`fCoMoney`                AS `fCoMoney`,
       `d`.`fCoDiscount`             AS `fCoDiscount`,
       `d`.`fSceneDiscountRate`      AS `fSceneDiscountRate`,
       `d`.`fSceneDiscount`          AS `fSceneDiscount`,
       `d`.`bSpecial`                AS `bSpecial`,
       `d`.`fRealPrice`              AS `fRealPrice`,
       `d`.`iProductModel`           AS `iProductModel`,
       `d`.`fEffaceMoney`            AS `fEffaceMoney`,
       `d`.`fSceneDiscountType`      AS `fSceneDiscountType`,
       `d`.`fSceneDiscountPrice`     AS `fSceneDiscountPrice`,
       `d`.`fPromotionPrice`         AS `fPromotionPrice`,
       `d`.`fGiftTokenDiscount`      AS `fGiftTokenDiscount`,
       `d`.`fPointPayDiscount`       AS `fPointPayDiscount`,
       `d`.`iBackid`                 AS `iBackid`,
       `d`.`iSupperOperatorid`       AS `iSupperOperatorid`,
       `d`.`fCardDisApportion`       AS `fCardDisApportion`,
       `d`.`fCardApportion`          AS `fCardApportion`,
       `d`.`fPointCurrent`           AS `fPointCurrent`,
       `d`.`bCanDiscount`            AS `bCanDiscount`,
       `d`.`iPromotionProduct`       AS `iPromotionProduct`,
       `d`.`fPointMultiple`          AS `fPointMultiple`,
       `d`.`fPointGive`              AS `fPointGive`,
       `d`.`fPointDiscount`          AS `fPointDiscount`,
       `d`.`cProductPath`            AS `cProductPath`,
       `d`.`cFree1`                  AS `cFree1`,
       `d`.`cFree2`                  AS `cFree2`,
       `d`.`cFree3`                  AS `cFree3`,
       `d`.`cFree4`                  AS `cFree4`,
       `d`.`cFree5`                  AS `cFree5`,
       `d`.`cFree6`                  AS `cFree6`,
       `d`.`cFree7`                  AS `cFree7`,
       `d`.`cFree8`                  AS `cFree8`,
       `d`.`cFree9`                  AS `cFree9`,
       `d`.`cFree10`                 AS `cFree10`,
       `d`.`dCoSaleDate`             AS `dCoSaleDate`,
       `d`.`create_time`             AS `create_time`,
       `d`.`create_date`             AS `create_date`,
       `d`.`modify_time`             AS `modify_time`,
       `d`.`modify_date`             AS `modify_date`,
       `d`.`creator`                 AS `creator`,
       `d`.`modifier`                AS `modifier`,
       `d`.`id`                      AS `id`,
       `d`.`pubts`                   AS `pubts`,
       `d`.`fPromotionDiscount`      AS `fPromotionDiscount`,
       `d`.`fQuoteMoney`             AS `fQuoteMoney`,
       `d`.`fVIPDiscount`            AS `fVIPDiscount`,
       `d`.`fVIPRate`                AS `fVIPRate`,
       `d`.`fBackOutQuantity`        AS `fBackOutQuantity`,
       `d`.`iRelatingRetailDetailId` AS `iRelatingRetailDetailId`,
       `d`.`foldPrice`               AS `foldPrice`,
       `d`.`foldDiscount`            AS `foldDiscount`,
       `d`.`fCardCoApportion`        AS `fCardCoApportion`,
       `d`.`fCoCardApportion`        AS `fCoCardApportion`,
       `d`.`cSerialNo`               AS `cSerialNo`,
       `d`.`fSellerPointCurrent`     AS `fSellerPointCurrent`,
       `d`.`fSellerPointGive`        AS `fSellerPointGive`,
       `d`.`fSellerPointMultiple`    AS `fSellerPointMultiple`,
       `d`.`fSellerPointDiscount`    AS `fSellerPointDiscount`,
       `d`.`fProcessedQuantity`      AS `fProcessedQuantity`,
       `d`.`fLowestPrice`            AS `fLowestPrice`,
       `d`.`cPriceReason`            AS `cPriceReason`,
       `d`.`iGoodsPositionId`        AS `iGoodsPositionId`,
       `d`.`fDeductionAmount`        AS `fDeductionAmount`,
       `d`.`fAdjustAmount`           AS `fAdjustAmount`,
       `d`.`iAmountAdjustDetailid`   AS `iAmountAdjustDetailid`,
       `d`.`fbeforeEffaceMoney`      AS `fbeforeEffaceMoney`,
       `d`.`fbeforeEffacePrice`      AS `fbeforeEffacePrice`,
       `d`.`fNCardCoApportion`       AS `fNCardCoApportion`,
       `d`.`fNCoCardApportion`       AS `fNCoCardApportion`,
       `d`.`fNCardDisApportion`      AS `fNCardDisApportion`,
       `d`.`fNCardApportion`         AS `fNCardApportion`,
       `d`.`cStorageCardNum`         AS `cStorageCardNum`,
       `d`.`kitproduct`              AS `kitproduct`,
       `d`.`ikitType`                AS `ikitType`,
       `d`.`fMoneyRatio`             AS `fMoneyRatio`,
       `d`.`dCookPrtDate`            AS `dCookPrtDate`,
       `d`.`fOutQuantity`            AS `fOutQuantity`,
       `d`.`iReturnStatus`           AS `iReturnStatus`,
       `d`.`iReturnPerson`           AS `iReturnPerson`,
       `d`.`dRetCookPrtDate`         AS `dRetCookPrtDate`,
       `d`.`iGroupNum`               AS `iGroupNum`,
       `d`.`iGroupPerson`            AS `iGroupPerson`,
       `d`.`dGroupDate`              AS `dGroupDate`,
       `d`.`fOnlineQuantity`         AS `fOnlineQuantity`,
       `d`.`fRechargeMoney`          AS `fRechargeMoney`,
       `d`.`fGiveMoney`              AS `fGiveMoney`,
       `d`.`fBalance`                AS `fBalance`,
       `d`.`kitgroup`                AS `kitgroup`,
       `d`.`cCouponsn`               AS `cCouponsn`,
       `d`.`cCouponId`               AS `cCouponId`,
       `d`.`fCouponPayApportion`     AS `fCouponPayApportion`,
       `d`.`fCouponDisApportion`     AS `fCouponDisApportion`,
       `d`.`key`                     AS `key`,
       `d`.`parentkey`               AS `parentkey`,
       `d`.`originalkey`             AS `originalkey`,
       `d`.`imalldetailid`           AS `imalldetailid`,
       `d`.`iproducticon`            AS `iproducticon`,
       `d`.`couponType`              AS `couponType`,
       `d`.`cookPrintSn`             AS `cookPrintSn`,
       `d`.`iSendPoint`              AS `iSendPoint`,
       `d`.`iCabinetgroup`           AS `iCabinetgroup`,
       `d`.`iCabinetgroupType`       AS `iCabinetgroupType`,
       `d`.`beginCouponsn`           AS `beginCouponsn`,
       `d`.`endCouponsn`             AS `endCouponsn`,
       `d`.`fScanDiscount`           AS `fScanDiscount`,
       `d`.`foldQuotePrice`          AS `foldQuotePrice`,
       `d`.`walletAccount`           AS `walletAccount`,
       `d`.`iReturntype`             AS `iReturntype`,
       `d`.`cPromotionNames`         AS `cPromotionNames`,
       `a`.`id`                      AS `iGatheringid`
from (((`uretaildata`.`rm_gatheringvouch` `a` join `uretaildata`.`rm_paymentwrite` `b` on ((`a`.`id` = `b`.`iGatheringid`))) join `uretaildata`.`rm_retailvouch` `c` on ((`b`.`iRetailid` = `c`.`id`)))
         join `uretaildata`.`rm_retailvouchdetail` `d` on ((`c`.`id` = `d`.`iRetailid`)))
where (`c`.`iPresellState` <> 5);

-- comment on column v_rm_gatherretailvouchdetail.iRetailid not supported: 零售单id

-- comment on column v_rm_gatherretailvouchdetail.cProductid not supported: 商品id

-- comment on column v_rm_gatherretailvouchdetail.iSKUid not supported: 商品SKUID

-- comment on column v_rm_gatherretailvouchdetail.iWarehouseid not supported: 仓库id

-- comment on column v_rm_gatherretailvouchdetail.iBathid not supported: 批号id

-- comment on column v_rm_gatherretailvouchdetail.dProduceDate not supported: 生产日期

-- comment on column v_rm_gatherretailvouchdetail.dInvalidDate not supported: 失效日期

-- comment on column v_rm_gatherretailvouchdetail.fQuantity not supported: 数量

-- comment on column v_rm_gatherretailvouchdetail.fMoney not supported: 金额

-- comment on column v_rm_gatherretailvouchdetail.fQuotePrice not supported: 零售价

-- comment on column v_rm_gatherretailvouchdetail.fVIPPrice not supported: 会员价

-- comment on column v_rm_gatherretailvouchdetail.fPrice not supported: 单价

-- comment on column v_rm_gatherretailvouchdetail.fDiscountRate not supported: 扣率

-- comment on column v_rm_gatherretailvouchdetail.fDiscount not supported: 扣额

-- comment on column v_rm_gatherretailvouchdetail.cMemo not supported: 备注

-- comment on column v_rm_gatherretailvouchdetail.iOrder not supported: 顺序号

-- comment on column v_rm_gatherretailvouchdetail.iEmployeeid not supported: 营业员id

-- comment on column v_rm_gatherretailvouchdetail.iSuperior not supported: 营业员上级id

-- comment on column v_rm_gatherretailvouchdetail.iCoRetailDetailId not supported: 原单退货原单子表id

-- comment on column v_rm_gatherretailvouchdetail.fCoQuantity not supported: 退货数量

-- comment on column v_rm_gatherretailvouchdetail.fCoMoney not supported: 退货金额

-- comment on column v_rm_gatherretailvouchdetail.fCoDiscount not supported: 退货折扣

-- comment on column v_rm_gatherretailvouchdetail.fSceneDiscountRate not supported: 现场折扣率

-- comment on column v_rm_gatherretailvouchdetail.fSceneDiscount not supported: 现场折扣额

-- comment on column v_rm_gatherretailvouchdetail.bSpecial not supported: 是否特价商品

-- comment on column v_rm_gatherretailvouchdetail.fRealPrice not supported: 分摊价

-- comment on column v_rm_gatherretailvouchdetail.iProductModel not supported: 商品模式

-- comment on column v_rm_gatherretailvouchdetail.fEffaceMoney not supported: 抹零折扣额

-- comment on column v_rm_gatherretailvouchdetail.fSceneDiscountType not supported: 现场折扣类型

-- comment on column v_rm_gatherretailvouchdetail.fSceneDiscountPrice not supported: 现场折扣价格

-- comment on column v_rm_gatherretailvouchdetail.fPromotionPrice not supported: 促销价格

-- comment on column v_rm_gatherretailvouchdetail.fGiftTokenDiscount not supported: 礼券折扣额

-- comment on column v_rm_gatherretailvouchdetail.fPointPayDiscount not supported: 积分折扣额

-- comment on column v_rm_gatherretailvouchdetail.iBackid not supported: 退货原因id

-- comment on column v_rm_gatherretailvouchdetail.iSupperOperatorid not supported: 折扣授权人

-- comment on column v_rm_gatherretailvouchdetail.fCardDisApportion not supported: 回收分摊储值卡折扣金额

-- comment on column v_rm_gatherretailvouchdetail.fCardApportion not supported: 回收分摊储值卡实销金额

-- comment on column v_rm_gatherretailvouchdetail.fPointCurrent not supported: 本次明细行积分

-- comment on column v_rm_gatherretailvouchdetail.bCanDiscount not supported: 参与折扣计算

-- comment on column v_rm_gatherretailvouchdetail.iPromotionProduct not supported: 促销品

-- comment on column v_rm_gatherretailvouchdetail.fPointMultiple not supported: N倍积分

-- comment on column v_rm_gatherretailvouchdetail.fPointGive not supported: 赠送积分

-- comment on column v_rm_gatherretailvouchdetail.fPointDiscount not supported: 分摊抵款积分

-- comment on column v_rm_gatherretailvouchdetail.cProductPath not supported: 商品类别全路径

-- comment on column v_rm_gatherretailvouchdetail.cFree1 not supported: 商品规格1

-- comment on column v_rm_gatherretailvouchdetail.cFree2 not supported: 商品规格2

-- comment on column v_rm_gatherretailvouchdetail.cFree3 not supported: 商品规格3

-- comment on column v_rm_gatherretailvouchdetail.cFree4 not supported: 商品规格4

-- comment on column v_rm_gatherretailvouchdetail.cFree5 not supported: 商品规格5

-- comment on column v_rm_gatherretailvouchdetail.cFree6 not supported: 商品规格6

-- comment on column v_rm_gatherretailvouchdetail.cFree7 not supported: 商品规格7

-- comment on column v_rm_gatherretailvouchdetail.cFree8 not supported: 商品规格8

-- comment on column v_rm_gatherretailvouchdetail.cFree9 not supported: 商品规格9

-- comment on column v_rm_gatherretailvouchdetail.cFree10 not supported: 商品规格10

-- comment on column v_rm_gatherretailvouchdetail.dCoSaleDate not supported: 原销售日期

-- comment on column v_rm_gatherretailvouchdetail.create_time not supported: 创建时间

-- comment on column v_rm_gatherretailvouchdetail.create_date not supported: 创建日期

-- comment on column v_rm_gatherretailvouchdetail.modify_time not supported: 修改时间

-- comment on column v_rm_gatherretailvouchdetail.modify_date not supported: 修改日期

-- comment on column v_rm_gatherretailvouchdetail.creator not supported: 创建人

-- comment on column v_rm_gatherretailvouchdetail.modifier not supported: 修改人

-- comment on column v_rm_gatherretailvouchdetail.id not supported: ID

-- comment on column v_rm_gatherretailvouchdetail.pubts not supported: 时间戳

-- comment on column v_rm_gatherretailvouchdetail.fPromotionDiscount not supported: 促销折扣额

-- comment on column v_rm_gatherretailvouchdetail.fQuoteMoney not supported: 零售金额

-- comment on column v_rm_gatherretailvouchdetail.fVIPDiscount not supported: 会员折扣额

-- comment on column v_rm_gatherretailvouchdetail.fVIPRate not supported: 会员折扣率%

-- comment on column v_rm_gatherretailvouchdetail.fBackOutQuantity not supported: 后台出库数量

-- comment on column v_rm_gatherretailvouchdetail.iRelatingRetailDetailId not supported: 关联单据子表id

-- comment on column v_rm_gatherretailvouchdetail.foldPrice not supported: 原销售价

-- comment on column v_rm_gatherretailvouchdetail.foldDiscount not supported: 原单折扣额

-- comment on column v_rm_gatherretailvouchdetail.fCardCoApportion not supported: 原单退货储值结算分摊金额

-- comment on column v_rm_gatherretailvouchdetail.fCoCardApportion not supported: 已退储值结算分摊额

-- comment on column v_rm_gatherretailvouchdetail.cSerialNo not supported: 序列号

-- comment on column v_rm_gatherretailvouchdetail.fSellerPointCurrent not supported: 商家消费积分

-- comment on column v_rm_gatherretailvouchdetail.fSellerPointGive not supported: 商家赠送积分

-- comment on column v_rm_gatherretailvouchdetail.fSellerPointMultiple not supported: 商家积分倍数

-- comment on column v_rm_gatherretailvouchdetail.fSellerPointDiscount not supported: 商家分摊抵扣积分

-- comment on column v_rm_gatherretailvouchdetail.fProcessedQuantity not supported: 已加工数量

-- comment on column v_rm_gatherretailvouchdetail.fLowestPrice not supported: 最低售价

-- comment on column v_rm_gatherretailvouchdetail.cPriceReason not supported: 价格审批原因

-- comment on column v_rm_gatherretailvouchdetail.fDeductionAmount not supported: 商超扣款金额

-- comment on column v_rm_gatherretailvouchdetail.fAdjustAmount not supported: 调整金额

-- comment on column v_rm_gatherretailvouchdetail.iAmountAdjustDetailid not supported: 金额调整关联子表id

-- comment on column v_rm_gatherretailvouchdetail.fbeforeEffaceMoney not supported: 抹零前金额

-- comment on column v_rm_gatherretailvouchdetail.fbeforeEffacePrice not supported: 抹零前单价

-- comment on column v_rm_gatherretailvouchdetail.fNCardCoApportion not supported: 原单退货储值卡结算分摊额

-- comment on column v_rm_gatherretailvouchdetail.fNCoCardApportion not supported: 储值卡结算分摊额

-- comment on column v_rm_gatherretailvouchdetail.fNCardDisApportion not supported: 储值卡折扣分摊额

-- comment on column v_rm_gatherretailvouchdetail.fNCardApportion not supported: 已退储值卡结算分摊额

-- comment on column v_rm_gatherretailvouchdetail.cStorageCardNum not supported: 储值卡卡号

-- comment on column v_rm_gatherretailvouchdetail.kitproduct not supported: 套件商品id

-- comment on column v_rm_gatherretailvouchdetail.ikitType not supported: 套件属性

-- comment on column v_rm_gatherretailvouchdetail.fMoneyRatio not supported: 金额权重比例

-- comment on column v_rm_gatherretailvouchdetail.dCookPrtDate not supported: 销售厨打时间

-- comment on column v_rm_gatherretailvouchdetail.fOutQuantity not supported: 已出品数量

-- comment on column v_rm_gatherretailvouchdetail.iReturnStatus not supported: 退品状态

-- comment on column v_rm_gatherretailvouchdetail.iReturnPerson not supported: 退品人

-- comment on column v_rm_gatherretailvouchdetail.dRetCookPrtDate not supported: 退品厨打时间

-- comment on column v_rm_gatherretailvouchdetail.iGroupNum not supported: 组号

-- comment on column v_rm_gatherretailvouchdetail.iGroupPerson not supported: 组操作员

-- comment on column v_rm_gatherretailvouchdetail.dGroupDate not supported: 组新增时间

-- comment on column v_rm_gatherretailvouchdetail.fOnlineQuantity not supported: 线上商品数量

-- comment on column v_rm_gatherretailvouchdetail.fRechargeMoney not supported: 充值金额

-- comment on column v_rm_gatherretailvouchdetail.fGiveMoney not supported: 赠送金额

-- comment on column v_rm_gatherretailvouchdetail.fBalance not supported: 余额

-- comment on column v_rm_gatherretailvouchdetail.kitgroup not supported: 套件分组

-- comment on column v_rm_gatherretailvouchdetail.cCouponsn not supported: 卡券号

-- comment on column v_rm_gatherretailvouchdetail.cCouponId not supported: 卡券id

-- comment on column v_rm_gatherretailvouchdetail.fCouponPayApportion not supported: 卡券结算分摊额

-- comment on column v_rm_gatherretailvouchdetail.fCouponDisApportion not supported: 卡券折扣分摊额

-- comment on column v_rm_gatherretailvouchdetail.`key` not supported: 前端key

-- comment on column v_rm_gatherretailvouchdetail.parentkey not supported: 前端parentkey

-- comment on column v_rm_gatherretailvouchdetail.originalkey not supported: 前端originalkey

-- comment on column v_rm_gatherretailvouchdetail.imalldetailid not supported: 电商子表id

-- comment on column v_rm_gatherretailvouchdetail.iproducticon not supported: 商品图标

-- comment on column v_rm_gatherretailvouchdetail.couponType not supported: 卡券类型

-- comment on column v_rm_gatherretailvouchdetail.cookPrintSn not supported: 厨打序号

-- comment on column v_rm_gatherretailvouchdetail.iSendPoint not supported: 是否积分

-- comment on column v_rm_gatherretailvouchdetail.iCabinetgroup not supported: 柜组

-- comment on column v_rm_gatherretailvouchdetail.iCabinetgroupType not supported: 柜组类型

-- comment on column v_rm_gatherretailvouchdetail.beginCouponsn not supported: 起始卡号

-- comment on column v_rm_gatherretailvouchdetail.endCouponsn not supported: 结束卡号

-- comment on column v_rm_gatherretailvouchdetail.fScanDiscount not supported: 扫码折扣额

-- comment on column v_rm_gatherretailvouchdetail.foldQuotePrice not supported: 原零售价

-- comment on column v_rm_gatherretailvouchdetail.walletAccount not supported: 会员钱包id

-- comment on column v_rm_gatherretailvouchdetail.iReturntype not supported: 退品状态

-- comment on column v_rm_gatherretailvouchdetail.cPromotionNames not supported: 促销活动

-- comment on column v_rm_gatherretailvouchdetail.iGatheringid not supported: ID

