create
    definer = root@`%` procedure createDateSaleTrend()
begin
		declare indexdate DATE;
		set indexdate = DATE_FORMAT('2020-05-18','%Y-%m-%d');
		while indexdate <= DATE_FORMAT('2020-05-18','%Y-%m-%d')
		do
			insert into date_saleTrend(temp_interval) values(DATE_FORMAT(indexdate,'%Y-%m-%d'));
			set indexdate = ADDDATE(indexdate,1);
		end while;
 		end;

