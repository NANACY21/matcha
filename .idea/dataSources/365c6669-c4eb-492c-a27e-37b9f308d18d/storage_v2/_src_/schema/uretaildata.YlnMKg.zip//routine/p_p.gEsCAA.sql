create
    definer = root@`%` procedure p_p()
begin 
	declare i int;
	set i = 1;
	while i <=30 do
		set @cFieldName=concat('product.productProps.define',i);
		set @cName=concat('product_productProps!define',i);
		UPDATE `billitem_base` SET `cFieldName`=@cFieldName
		WHERE ibillid in (
			select id from bill_base where cbillno='st_transferapply' ) 
		and cName=@cName ;
		set i = i + 1;
	end while;
end;

