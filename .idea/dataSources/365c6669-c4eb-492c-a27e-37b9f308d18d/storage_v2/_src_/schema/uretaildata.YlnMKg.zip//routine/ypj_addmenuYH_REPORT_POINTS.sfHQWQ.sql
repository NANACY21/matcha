create
    definer = root@`%` procedure ypj_addmenuYH_REPORT_POINTS(IN rtn int)
begin  
    IF rtn is NOT NULL   THEN  
		
		delete from pb_menu_base where menu_code in('YH_REPORT_POINTS ');
		delete from pb_menu_lang where menu_code in('YH_REPORT_POINTS');


		INSERT INTO pb_menu_base(`id`, `menu_code`, `subid`, `ilevel`, `pmenu_code`, `auth_id`, `ordernum`, `depends`, `flag`, `imagename`, `viewtype`, `menu_url`, `metatype`, `metakey`, `pubts`, `ideleted`, `bendgrade`, `bEA`, `icon`, `auth_level`, `isshoprelated`, `tenant_id`, `propertytype`, `terminalType`, `isSystem`) 
		select '0', 'YH_REPORT_POINTS', 'ST', '1', 'YH', 'st_demandapply_pointslist', '31', NULL, '1', NULL, 'meta', NULL, 'voucherlist', 'st_demandapply_DemandapplyReport', now(), '0', '1', '1', NULL, '3', '1', id, NULL, '1', '1' from tenant where id<>0
		union 
		select '0', 'YH_REPORT_POINTS', 'ST', '1', 'YH', 'st_demandapply_pointslist', '31', NULL, '1', NULL, 'meta', NULL, 'voucherlist', 'st_demandapply_DemandapplyReport', now(), '0', '1', '1', NULL, '3', '1', 0, NULL, '1', '1';

		INSERT INTO pb_menu_lang(`id`, `menu_code`, `menu_name`, `localeid`, `pubts`, `ideleted`, `tenant_id`) 
		select '0', 'YH_REPORT_POINTS', '分货单', 'zh-cn', now(), '0', id from tenant where id<>0
		union 
		select '0', 'YH_REPORT_POINTS', '分货单', 'zh-cn', now(), '0', 0;

		##分货单
		DELETE from `auth` WHERE code = 'st_demandapply_DemandapplyReport';
		INSERT INTO `auth` (`code`, `name`, `parent_id`, `level`, `path`, `sort_num`, `isEnd`, `pubts`, `auth_level`, `note`, `alias_code`, `subId`) 
		VALUES ('st_demandapply_DemandapplyReport', '分货单', 'YH', '2', NULL, '48', b'0', now(), '2', NULL, NULL, 'URetail');


		##auth
		DELETE from `auth` WHERE code='st_demandapply_pointslist';
		INSERT INTO `uretaildata`.`auth`(`code`, `name`, `parent_id`, `level`, `path`, `sort_num`, `isEnd`,  `pubts`, `auth_level`, `note`, `alias_code`, `subId`, `datarule`) VALUES ('st_demandapply_pointslist', '查看', 'st_demandapply_DemandapplyReport', 3, NULL, 2, b'1', now(), 2, NULL, NULL, 'URetail', NULL);




END IF;  
end;

