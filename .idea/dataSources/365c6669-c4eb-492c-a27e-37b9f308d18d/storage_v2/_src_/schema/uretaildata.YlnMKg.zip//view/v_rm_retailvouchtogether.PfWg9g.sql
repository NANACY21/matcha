create definer = root@`%` view v_rm_retailvouchtogether as
(
select max(`uretaildata`.`rm_retailvouchdetail`.`id`)                      AS `id`,
       ifnull(sum(`uretaildata`.`rm_retailvouchdetail`.`fQuantity`), 0)    AS `fQuantitySum`,
       ifnull(sum(`uretaildata`.`rm_retailvouchdetail`.`fCoQuantity`), 0)  AS `fCoQuantitySum`,
       ifnull(sum(`uretaildata`.`rm_retailvouchdetail`.`fOutQuantity`), 0) AS `fOutQuantitySum`,
       `uretaildata`.`rm_retailvouchdetail`.`cProductid`                   AS `cProductid`,
       `uretaildata`.`rm_retailvouch`.`iStoreid`                           AS `iStoreid`,
       max(`uretaildata`.`rm_retailvouch`.`room`)                          AS `room`,
       max(`uretaildata`.`rm_retailvouch`.`cCode`)                         AS `cCode`,
       `uretaildata`.`rm_retailvouch`.`tenant_id`                          AS `tenant_id`
from (`uretaildata`.`rm_retailvouch`
         join `uretaildata`.`rm_retailvouchdetail`
              on ((`uretaildata`.`rm_retailvouch`.`id` = `uretaildata`.`rm_retailvouchdetail`.`iRetailid`)))
where ((`uretaildata`.`rm_retailvouchdetail`.`dCookPrtDate` > (sysdate() + interval -(1) day)) and
       (`uretaildata`.`rm_retailvouch`.`iPresellState` in (0, 1, 3)) and
       (`uretaildata`.`rm_retailvouchdetail`.`iReturnStatus` not in (1, 2)) and
       (((ifnull(`uretaildata`.`rm_retailvouchdetail`.`fQuantity`, 0) -
          ifnull(`uretaildata`.`rm_retailvouchdetail`.`fCoQuantity`, 0)) -
         ifnull(`uretaildata`.`rm_retailvouchdetail`.`fOutQuantity`, 0)) > 0))
group by `uretaildata`.`rm_retailvouchdetail`.`cProductid`, `uretaildata`.`rm_retailvouch`.`tenant_id`,
         `uretaildata`.`rm_retailvouch`.`iStoreid`);

-- comment on column v_rm_retailvouchtogether.id not supported: ID

-- comment on column v_rm_retailvouchtogether.cProductid not supported: 商品id

-- comment on column v_rm_retailvouchtogether.iStoreid not supported: 门店id

-- comment on column v_rm_retailvouchtogether.room not supported: 房间id

-- comment on column v_rm_retailvouchtogether.cCode not supported: 单据编号

-- comment on column v_rm_retailvouchtogether.tenant_id not supported: 租户

