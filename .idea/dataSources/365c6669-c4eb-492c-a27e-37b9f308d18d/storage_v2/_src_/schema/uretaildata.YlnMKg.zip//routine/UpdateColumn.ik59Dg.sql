create
    definer = root@`%` procedure UpdateColumn(IN tablename varchar(50), IN columnname varchar(50),
                                              IN executeStr varchar(100), IN executeType varchar(50))
BEGIN
       DECLARE  CurrentDatabase VARCHAR(100);
       SELECT DATABASE() INTO CurrentDatabase;
       set @tablename = tablename;
       set @columnname = columnname;
       set @executeType = executeType;
       set @executeStr = executeStr;
set @count = (select count(*) from information_schema.COLUMNS where table_schema=CurrentDatabase and  TABLE_NAME=',@tablename,' and COLUMN_NAME=',@columnname,');
       if @executeType       = 'add' and @count = 0 then 
              PREPARE stmt1 FROM @executeStr;
              EXECUTE stmt1;
       ELSEIF @executeType      = 'alter' and @count >0 then  
              PREPARE stmt1 FROM @executeStr;
              EXECUTE stmt1;
       end IF;
END;

