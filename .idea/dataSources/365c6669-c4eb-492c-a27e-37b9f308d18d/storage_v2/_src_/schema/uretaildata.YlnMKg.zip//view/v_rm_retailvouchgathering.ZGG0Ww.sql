create definer = root@`%` view v_rm_retailvouchgathering as
select `a`.`id`                                                        AS `id`,
       `a`.`pubts`                                                     AS `pubts`,
       `b`.`iRetailid`                                                 AS `iRetailid`,
       `b`.`iGatheringid`                                              AS `iGatheringid`,
       `a`.`iPaymentid`                                                AS `iPaymentid`,
       `a`.`fMoney`                                                    AS `fMoney`,
       `a`.`iOrder`                                                    AS `iOrder`,
       `a`.`iPaytype`                                                  AS `iPaytype`,
       `a`.`fCardDisApportion`                                         AS `fCardDisApportion`,
       `a`.`fCardApportion`                                            AS `fCardApportion`,
       `a`.`fCardRecharg`                                              AS `fCardRecharg`,
       `a`.`fCardCoPay`                                                AS `fCardCoPay`,
       `a`.`bIsChange`                                                 AS `bIsChange`,
       `a`.`iGatheringReportid`                                        AS `iGatheringReportid`,
       (case when (`a`.`bIsChange` = 1) then '找零' else `c`.`name` end) AS `Paymentname`,
       `d`.`iPresellState`                                             AS `iPresellState`
from ((((`uretaildata`.`rm_gatheringvouchdetail` `a` join `uretaildata`.`rm_paymentwrite` `b` on ((`a`.`iGatheringid` = `b`.`iGatheringid`))) join `uretaildata`.`rm_gatheringvouch` `e` on ((`a`.`iGatheringid` = `e`.`id`))) join `uretaildata`.`rm_retailvouch` `d` on ((`b`.`iRetailid` = `d`.`id`)))
         join `uretaildata`.`aa_payment_method` `c` on ((`a`.`iPaymentid` = `c`.`id`)))
where (`e`.`ipayadjust` <> 1);

-- comment on column v_rm_retailvouchgathering.id not supported: ID

-- comment on column v_rm_retailvouchgathering.pubts not supported: 时间戳

-- comment on column v_rm_retailvouchgathering.iRetailid not supported: 零售单id

-- comment on column v_rm_retailvouchgathering.iGatheringid not supported: 收款单id

-- comment on column v_rm_retailvouchgathering.iPaymentid not supported: 收款方式

-- comment on column v_rm_retailvouchgathering.fMoney not supported: 收款金额

-- comment on column v_rm_retailvouchgathering.iOrder not supported: 顺序号

-- comment on column v_rm_retailvouchgathering.iPaytype not supported: 支付类型

-- comment on column v_rm_retailvouchgathering.fCardDisApportion not supported: 回收分摊储值卡折扣金额

-- comment on column v_rm_retailvouchgathering.fCardApportion not supported: 回收分摊储值卡折扣金额

-- comment on column v_rm_retailvouchgathering.fCardRecharg not supported: 储值退货充值金额

-- comment on column v_rm_retailvouchgathering.fCardCoPay not supported: 原单退货储值结算金额

-- comment on column v_rm_retailvouchgathering.bIsChange not supported: 是否找零

-- comment on column v_rm_retailvouchgathering.iGatheringReportid not supported: 收款日报id

-- comment on column v_rm_retailvouchgathering.iPresellState not supported: 预订单状态

