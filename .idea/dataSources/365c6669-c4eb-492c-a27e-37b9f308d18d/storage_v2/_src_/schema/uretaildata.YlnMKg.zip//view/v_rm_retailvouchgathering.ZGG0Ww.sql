create definer = root@`%` view v_rm_retailvouchgathering as
select `a`.`id`                                                        AS `id`,
       `a`.`pubts`                                                     AS `pubts`,
       `b`.`iRetailid`                                                 AS `iRetailid`,
       `b`.`iGatheringid`                                              AS `iGatheringid`,
       `a`.`iPaymentid`                                                AS `iPaymentid`,
       `a`.`fMoney`                                                    AS `fMoney`,
       `a`.`iOrder`                                                    AS `iOrder`,
       `a`.`iPaytype`                                                  AS `iPaytype`,
       `a`.`fCardDisApportion`                                         AS `fCardDisApportion`,
       `a`.`fCardApportion`                                            AS `fCardApportion`,
       `a`.`fCardRecharg`                                              AS `fCardRecharg`,
       `a`.`fCardCoPay`                                                AS `fCardCoPay`,
       `a`.`bIsChange`                                                 AS `bIsChange`,
       `a`.`iGatheringReportid`                                        AS `iGatheringReportid`,
       (case when (`a`.`bIsChange` = 1) then '找零' else `c`.`name` end) AS `Paymentname`,
       `d`.`iPresellState`                                             AS `iPresellState`
from ((((`uretaildata`.`rm_gatheringvouchdetail` `a` join `uretaildata`.`rm_paymentwrite` `b` on ((`a`.`iGatheringid` = `b`.`iGatheringid`))) join `uretaildata`.`rm_gatheringvouch` `e` on ((`a`.`iGatheringid` = `e`.`id`))) join `uretaildata`.`rm_retailvouch` `d` on ((`b`.`iRetailid` = `d`.`id`)))
         join `uretaildata`.`aa_payment_method` `c` on ((`a`.`iPaymentid` = `c`.`id`)))
where (`e`.`ipayadjust` <> 1);

