create
    definer = root@`%` procedure wb()
begin 
	declare i int;
	set i = 1;
	while i <=30 do
		set @cFieldName=concat('product.productProps.define',i);
		set @cName=concat('prodefine',i);
		UPDATE `billitem_base` SET `cFieldName`=@cFieldName
		WHERE ibillid in (select id from bill_base where cbillno='st_storeprorecord') and cName=@cName;
		set i = i + 1;
	end while;
end;

