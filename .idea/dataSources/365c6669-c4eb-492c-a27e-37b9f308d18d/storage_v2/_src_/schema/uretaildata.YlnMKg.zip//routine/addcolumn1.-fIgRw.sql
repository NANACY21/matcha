create
    definer = root@`%` procedure addcolumn1()
BEGIN 
	IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = 'rm_report_association_gather' AND column_name = 'pubts') THEN
		alter table `rm_report_association_gather`  add COLUMN `pubts` timestamp COMMENT '时间戳' NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
	end if ;
	
	IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = 'rm_report_association_gather' AND column_name = 'tenant_id') THEN
		alter table `rm_report_association_gather`  add COLUMN `tenant_id` bigint NOT NULL COMMENT '租户';
	end if ;
END;

