create definer = root@`%` view pu_v_venlook as
select distinct `uretaildata`.`pu_venandinv`.`vendor_id` AS `id`,
                ''                                       AS `code`,
                'tempName111'                            AS `name`,
                `uretaildata`.`pu_venandinv`.`vendor_id` AS `vendor_id`,
                `uretaildata`.`pu_venandinv`.`lookat`    AS `lookat`,
                `uretaildata`.`pu_venandinv`.`tenant_id` AS `tenant_id`,
                ''                                       AS `parent_id`,
                1                                        AS `level`,
                ''                                       AS `path`,
                1                                        AS `sort_num`,
                1                                        AS `isEnd`,
                ''                                       AS `pubts`
from `uretaildata`.`pu_venandinv`;

-- comment on column pu_v_venlook.id not supported: 供应商id

-- comment on column pu_v_venlook.vendor_id not supported: 供应商id

-- comment on column pu_v_venlook.lookat not supported: 维度

-- comment on column pu_v_venlook.tenant_id not supported: 租户

