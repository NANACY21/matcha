create
    definer = root@`%` procedure p_aa_getperson(IN strtblname varchar(200), IN strwhere varchar(3000))
begin
	
	set @tblname=strtblname;
	if trim(strwhere)<>'' then 
		set @where=concat(' and ',strwhere);
	else
		set @where='';
	end if;

	
	
	
	

	set @str=concat('insert into ',@tblname,' (id,code,name) 
	select id,code,name from aa_person where 1=1 ',@where);
	prepare stmt from @str;
	execute stmt;
	deallocate prepare stmt;
end;

