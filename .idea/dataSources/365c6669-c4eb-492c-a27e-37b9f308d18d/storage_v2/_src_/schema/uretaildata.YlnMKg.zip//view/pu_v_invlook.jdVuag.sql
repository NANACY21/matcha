create definer = root@`%` view pu_v_invlook as
select distinct `uretaildata`.`pu_venandinv`.`product_id` AS `id`,
                ''                                        AS `code`,
                'tempName222'                             AS `name`,
                `uretaildata`.`pu_venandinv`.`product_id` AS `product_id`,
                `uretaildata`.`pu_venandinv`.`lookat`     AS `lookat`,
                `uretaildata`.`pu_venandinv`.`tenant_id`  AS `tenant_id`,
                ''                                        AS `parent_id`,
                1                                         AS `level`,
                ''                                        AS `path`,
                1                                         AS `sort_num`,
                1                                         AS `isEnd`,
                ''                                        AS `pubts`
from `uretaildata`.`pu_venandinv`;

