create definer = root@`%` view pu_v_invlook as
select distinct `uretaildata`.`pu_venandinv`.`product_id` AS `id`,
                ''                                        AS `code`,
                'tempName222'                             AS `name`,
                `uretaildata`.`pu_venandinv`.`product_id` AS `product_id`,
                `uretaildata`.`pu_venandinv`.`lookat`     AS `lookat`,
                `uretaildata`.`pu_venandinv`.`tenant_id`  AS `tenant_id`,
                ''                                        AS `parent_id`,
                1                                         AS `level`,
                ''                                        AS `path`,
                1                                         AS `sort_num`,
                1                                         AS `isEnd`,
                ''                                        AS `pubts`
from `uretaildata`.`pu_venandinv`;

-- comment on column pu_v_invlook.id not supported: 物料id

-- comment on column pu_v_invlook.product_id not supported: 物料id

-- comment on column pu_v_invlook.lookat not supported: 维度

-- comment on column pu_v_invlook.tenant_id not supported: 租户

