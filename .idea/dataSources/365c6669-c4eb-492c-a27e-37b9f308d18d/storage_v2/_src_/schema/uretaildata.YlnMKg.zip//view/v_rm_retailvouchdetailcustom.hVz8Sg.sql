create definer = root@`%` view v_rm_retailvouchdetailcustom as
select `uretaildata`.`rm_retailvouchdetailcustom`.`iRetailVouchDetailId` AS `iRetailVouchDetailId`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB1`            AS `define1`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB2`            AS `define2`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB3`            AS `define3`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB4`            AS `define4`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB5`            AS `define5`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB6`            AS `define6`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB7`            AS `define7`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB8`            AS `define8`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB9`            AS `define9`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB10`           AS `define10`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB11`           AS `define11`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB12`           AS `define12`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB13`           AS `define13`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB14`           AS `define14`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB15`           AS `define15`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB16`           AS `define16`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB17`           AS `define17`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB18`           AS `define18`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB19`           AS `define19`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB20`           AS `define20`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB21`           AS `define21`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB22`           AS `define22`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB23`           AS `define23`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB24`           AS `define24`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB25`           AS `define25`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB26`           AS `define26`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB27`           AS `define27`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB28`           AS `define28`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB29`           AS `define29`,
       `uretaildata`.`rm_retailvouchdetailcustom`.`cDefineB30`           AS `define30`
from `uretaildata`.`rm_retailvouchdetailcustom`;

-- comment on column v_rm_retailvouchdetailcustom.iRetailVouchDetailId not supported: 所属零售单子表

-- comment on column v_rm_retailvouchdetailcustom.define1 not supported: 自定义项1

-- comment on column v_rm_retailvouchdetailcustom.define2 not supported: 自定义项2

-- comment on column v_rm_retailvouchdetailcustom.define3 not supported: 自定义项3

-- comment on column v_rm_retailvouchdetailcustom.define4 not supported: 自定义项4

-- comment on column v_rm_retailvouchdetailcustom.define5 not supported: 自定义项5

-- comment on column v_rm_retailvouchdetailcustom.define6 not supported: 自定义项6

-- comment on column v_rm_retailvouchdetailcustom.define7 not supported: 自定义项7

-- comment on column v_rm_retailvouchdetailcustom.define8 not supported: 自定义项8

-- comment on column v_rm_retailvouchdetailcustom.define9 not supported: 自定义项9

-- comment on column v_rm_retailvouchdetailcustom.define10 not supported: 自定义项10

-- comment on column v_rm_retailvouchdetailcustom.define11 not supported: 自定义项11

-- comment on column v_rm_retailvouchdetailcustom.define12 not supported: 自定义项12

-- comment on column v_rm_retailvouchdetailcustom.define13 not supported: 自定义项13

-- comment on column v_rm_retailvouchdetailcustom.define14 not supported: 自定义项14

-- comment on column v_rm_retailvouchdetailcustom.define15 not supported: 自定义项15

-- comment on column v_rm_retailvouchdetailcustom.define16 not supported: 自定义项16

-- comment on column v_rm_retailvouchdetailcustom.define17 not supported: 自定义项17

-- comment on column v_rm_retailvouchdetailcustom.define18 not supported: 自定义项18

-- comment on column v_rm_retailvouchdetailcustom.define19 not supported: 自定义项19

-- comment on column v_rm_retailvouchdetailcustom.define20 not supported: 自定义项20

-- comment on column v_rm_retailvouchdetailcustom.define21 not supported: 自定义项21

-- comment on column v_rm_retailvouchdetailcustom.define22 not supported: 自定义项22

-- comment on column v_rm_retailvouchdetailcustom.define23 not supported: 自定义项23

-- comment on column v_rm_retailvouchdetailcustom.define24 not supported: 自定义项24

-- comment on column v_rm_retailvouchdetailcustom.define25 not supported: 自定义项25

-- comment on column v_rm_retailvouchdetailcustom.define26 not supported: 自定义项26

-- comment on column v_rm_retailvouchdetailcustom.define27 not supported: 自定义项27

-- comment on column v_rm_retailvouchdetailcustom.define28 not supported: 自定义项28

-- comment on column v_rm_retailvouchdetailcustom.define29 not supported: 自定义项29

-- comment on column v_rm_retailvouchdetailcustom.define30 not supported: 自定义项30

