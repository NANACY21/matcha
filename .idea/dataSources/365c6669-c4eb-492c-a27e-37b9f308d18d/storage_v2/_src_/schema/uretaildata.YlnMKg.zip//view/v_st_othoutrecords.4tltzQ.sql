create definer = root@`%` view v_st_othoutrecords as
select `b`.`iWarehouseId`     AS `iWarehouseid`,
       `a`.`cMemo`            AS `cMemo`,
       `a`.`define1`          AS `define1`,
       `a`.`define10`         AS `define10`,
       `a`.`define11`         AS `define11`,
       `a`.`define12`         AS `define12`,
       `a`.`define13`         AS `define13`,
       `a`.`define14`         AS `define14`,
       `a`.`define15`         AS `define15`,
       `a`.`define16`         AS `define16`,
       `a`.`define17`         AS `define17`,
       `a`.`define18`         AS `define18`,
       `a`.`define19`         AS `define19`,
       `a`.`define2`          AS `define2`,
       `a`.`define20`         AS `define20`,
       `a`.`define21`         AS `define21`,
       `a`.`define22`         AS `define22`,
       `a`.`define23`         AS `define23`,
       `a`.`define24`         AS `define24`,
       `a`.`define25`         AS `define25`,
       `a`.`define26`         AS `define26`,
       `a`.`define27`         AS `define27`,
       `a`.`define28`         AS `define28`,
       `a`.`define29`         AS `define29`,
       `a`.`define3`          AS `define3`,
       `a`.`define30`         AS `define30`,
       `a`.`define4`          AS `define4`,
       `a`.`define5`          AS `define5`,
       `a`.`define6`          AS `define6`,
       `a`.`define7`          AS `define7`,
       `a`.`define8`          AS `define8`,
       `a`.`define9`          AS `define9`,
       `a`.`dInvalidDate`     AS `dInvalidDate`,
       `a`.`dProduceDate`     AS `dProduceDate`,
       `a`.`dRecordDate`      AS `dRecordDate`,
       `a`.`fQuantity`        AS `fQuantity`,
       `a`.`free1`            AS `cFree1`,
       `a`.`free10`           AS `cFree10`,
       `a`.`free2`            AS `cFree2`,
       `a`.`free3`            AS `cFree3`,
       `a`.`free4`            AS `cFree4`,
       `a`.`free5`            AS `cFree5`,
       `a`.`free6`            AS `cFree6`,
       `a`.`free7`            AS `cFree7`,
       `a`.`free8`            AS `cFree8`,
       `a`.`free9`            AS `cFree9`,
       `a`.`id`               AS `id`,
       `a`.`iGoodsPositionId` AS `iGoodsPositionId`,
       `a`.`iMainId`          AS `iMainId`,
       `a`.`iProductid`       AS `cProductid`,
       `a`.`iProductSkuid`    AS `iSKUid`,
       `a`.`iUnitId`          AS `iUnitId`,
       `a`.`makerule_code`    AS `makerule_code`,
       `a`.`natMoney`         AS `natMoney`,
       `a`.`natSum`           AS `natSum`,
       `a`.`natTax`           AS `natTax`,
       `a`.`natTaxUnitPrice`  AS `natTaxUnitPrice`,
       `a`.`natUnitPrice`     AS `natUnitPrice`,
       `a`.`oriMoney`         AS `oriMoney`,
       `a`.`oriSum`           AS `oriSum`,
       `a`.`oriTax`           AS `oriTax`,
       `a`.`oriTaxUnitPrice`  AS `oriTaxUnitPrice`,
       `a`.`oriUnitPrice`     AS `oriUnitPrice`,
       `a`.`pubts`            AS `pubts`,
       `a`.`rowno`            AS `rowno`,
       `a`.`sBatchNo`         AS `sBatchNo`,
       `a`.`source`           AS `source`,
       `a`.`sourceautoid`     AS `sourceautoid`,
       `a`.`sourceid`         AS `sourceid`,
       `a`.`taxRate`          AS `taxRate`,
       `a`.`upcode`           AS `upcode`
from (`uretaildata`.`st_othoutrecords` `a`
         left join `uretaildata`.`st_othoutrecord` `b` on ((`a`.`iMainId` = `b`.`id`)));

-- comment on column v_st_othoutrecords.iWarehouseid not supported: 仓库

-- comment on column v_st_othoutrecords.cMemo not supported: 备注

-- comment on column v_st_othoutrecords.define1 not supported: 批次属性1

-- comment on column v_st_othoutrecords.define10 not supported: 批次属性10

-- comment on column v_st_othoutrecords.define11 not supported: 批次属性11

-- comment on column v_st_othoutrecords.define12 not supported: 批次属性12

-- comment on column v_st_othoutrecords.define13 not supported: 批次属性13

-- comment on column v_st_othoutrecords.define14 not supported: 批次属性14

-- comment on column v_st_othoutrecords.define15 not supported: 批次属性15

-- comment on column v_st_othoutrecords.define16 not supported: 批次属性16

-- comment on column v_st_othoutrecords.define17 not supported: 批次属性17

-- comment on column v_st_othoutrecords.define18 not supported: 批次属性18

-- comment on column v_st_othoutrecords.define19 not supported: 批次属性19

-- comment on column v_st_othoutrecords.define2 not supported: 批次属性2

-- comment on column v_st_othoutrecords.define20 not supported: 批次属性20

-- comment on column v_st_othoutrecords.define21 not supported: 批次属性21

-- comment on column v_st_othoutrecords.define22 not supported: 批次属性22

-- comment on column v_st_othoutrecords.define23 not supported: 批次属性23

-- comment on column v_st_othoutrecords.define24 not supported: 批次属性24

-- comment on column v_st_othoutrecords.define25 not supported: 批次属性25

-- comment on column v_st_othoutrecords.define26 not supported: 批次属性26

-- comment on column v_st_othoutrecords.define27 not supported: 批次属性27

-- comment on column v_st_othoutrecords.define28 not supported: 批次属性28

-- comment on column v_st_othoutrecords.define29 not supported: 批次属性29

-- comment on column v_st_othoutrecords.define3 not supported: 批次属性3

-- comment on column v_st_othoutrecords.define30 not supported: 批次属性30

-- comment on column v_st_othoutrecords.define4 not supported: 批次属性4

-- comment on column v_st_othoutrecords.define5 not supported: 批次属性5

-- comment on column v_st_othoutrecords.define6 not supported: 批次属性6

-- comment on column v_st_othoutrecords.define7 not supported: 批次属性7

-- comment on column v_st_othoutrecords.define8 not supported: 批次属性8

-- comment on column v_st_othoutrecords.define9 not supported: 批次属性9

-- comment on column v_st_othoutrecords.dInvalidDate not supported: 失效日期

-- comment on column v_st_othoutrecords.dProduceDate not supported: 生产日期

-- comment on column v_st_othoutrecords.dRecordDate not supported: 出库日期

-- comment on column v_st_othoutrecords.fQuantity not supported: 数量

-- comment on column v_st_othoutrecords.cFree1 not supported: 自由项1

-- comment on column v_st_othoutrecords.cFree10 not supported: 自由项10

-- comment on column v_st_othoutrecords.cFree2 not supported: 自由项2

-- comment on column v_st_othoutrecords.cFree3 not supported: 自由项3

-- comment on column v_st_othoutrecords.cFree4 not supported: 自由项4

-- comment on column v_st_othoutrecords.cFree5 not supported: 自由项5

-- comment on column v_st_othoutrecords.cFree6 not supported: 自由项6

-- comment on column v_st_othoutrecords.cFree7 not supported: 自由项7

-- comment on column v_st_othoutrecords.cFree8 not supported: 自由项8

-- comment on column v_st_othoutrecords.cFree9 not supported: 自由项9

-- comment on column v_st_othoutrecords.id not supported: ID

-- comment on column v_st_othoutrecords.iMainId not supported: mainid

-- comment on column v_st_othoutrecords.cProductid not supported: 商品

-- comment on column v_st_othoutrecords.iSKUid not supported: 商品skuid

-- comment on column v_st_othoutrecords.iUnitId not supported: 单位id

-- comment on column v_st_othoutrecords.natMoney not supported: 本币无税金额

-- comment on column v_st_othoutrecords.natSum not supported: 本币含税金额

-- comment on column v_st_othoutrecords.natTax not supported: 本币税额

-- comment on column v_st_othoutrecords.natTaxUnitPrice not supported: 本币含税单价

-- comment on column v_st_othoutrecords.natUnitPrice not supported: 本币无税单价

-- comment on column v_st_othoutrecords.oriMoney not supported: 原币无税金额

-- comment on column v_st_othoutrecords.oriSum not supported: 原币含税金额

-- comment on column v_st_othoutrecords.oriTax not supported: 原币税额

-- comment on column v_st_othoutrecords.oriTaxUnitPrice not supported: 原币含税单价

-- comment on column v_st_othoutrecords.oriUnitPrice not supported: 原币无税单价

-- comment on column v_st_othoutrecords.pubts not supported: 时间戳

-- comment on column v_st_othoutrecords.rowno not supported: 行号

-- comment on column v_st_othoutrecords.taxRate not supported: 税率

