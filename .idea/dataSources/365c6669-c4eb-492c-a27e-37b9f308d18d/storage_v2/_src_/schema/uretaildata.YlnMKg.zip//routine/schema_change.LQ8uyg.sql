create
    definer = root@`%` procedure schema_change()
BEGIN 
	IF NOT EXISTS (SELECT * FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'rm_paymentwrite' AND index_name = 'igatheringid') THEN  
		 ALTER TABLE `rm_paymentwrite` ADD INDEX igatheringid ( `igatheringid` );
	END IF;  
	IF NOT EXISTS (SELECT * FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'rm_paymentwrite' AND index_name = 'iretailid') THEN  
		 ALTER TABLE `rm_paymentwrite` ADD INDEX iretailid ( `iretailid` );
	END IF;  
	IF NOT EXISTS (SELECT * FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'rm_paymentwrite' AND index_name = 'tenant_id') THEN  
		 ALTER TABLE `rm_paymentwrite` ADD INDEX tenant_id ( `tenant_id` );
	END IF;  
END;

