create
    definer = username2021@`%` procedure p_adjustbillitemorder(IN billNo varchar(50))
begin

declare done int default 0;
declare successCount int default 0;
declare warningCount int default 0;
declare errorCount int default 0;
declare skipCount int default 0;
declare tenantid BIGINT;
declare billid BIGINT;
declare startIndex int default 0;

declare cur cursor for select id from tenant where isopen=1;

declare continue HANDLER for not found set done = 1;

open cur;
	update_loop:Loop
		fetch cur into tenantid;
		if done then
			leave update_loop;
		end if;

		select id into billid from bill_base where cbillno = billNo and tenant_id = tenantid;
		select MIN(iOrder) into startIndex from billitem_base where iBillId = billid and tenant_id = tenantid;



		if startIndex is null then
			set errorCount = errorCount + 1;
		elseif startIndex = 0 then
			set startIndex = 0;
			set warningCount = warningCount + 1;
			set successCount = successCount + 1;
			update billitem_base set iOrder = case when iOrder = 0 then 1 else iOrder * 10 end where ibillid = billid order by iOrder;
			update billitem_base set iTabIndex = iOrder where ibillid = billid;
		elseif startIndex < 10 then
			set startIndex = 0;
			set successCount = successCount + 1;
			update billitem_base set iOrder = iOrder * 10 where ibillid = billid order by iOrder;
			update billitem_base set iTabIndex = iOrder where ibillid = billid;
		else
			set skipCount = skipCount + 1;
		end if;
	end loop update_loop;
close cur;


select MIN(item.iOrder) into startIndex from billitem_base item inner join bill_base base on base.id = item.ibillid and base.cbillno = billNo and base.tenant_id = 0;

if startIndex is null then
	set errorCount = errorCount + 1;
elseif startIndex = 0 then
	set warningCount = warningCount + 1;
	set successCount = successCount + 1;
	update billitem_base item inner join bill_base base on base.id = item.ibillid and base.cbillno = billNo and base.tenant_id = 0
	set item.iOrder = case when item.iOrder = 0 then 1 else item.iOrder * 10 end,
	item.iTabIndex = case when item.iTabIndex = 0 then 1 else item.iTabIndex * 10 end;
elseif startIndex < 10 then
	set successCount = successCount + 1;
	update billitem_base item inner join bill_base base on base.id = item.ibillid and base.cbillno = billNo and base.tenant_id = 0
	set item.iOrder = item.iOrder * 10, item.iTabIndex = item.iTabIndex * 10;
else
	set skipCount = skipCount + 1;
end if;


select done as '执行完成';
select successCount as '成功条数';
select warningCount as '警告条数（起始order为0）';
select errorCount as '错误条数（起始order为null）';
select skipCount as '跳过条数（已执行过）';
end;

