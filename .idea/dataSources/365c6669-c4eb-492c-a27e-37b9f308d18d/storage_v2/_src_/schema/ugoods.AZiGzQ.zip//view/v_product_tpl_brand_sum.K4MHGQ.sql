create definer = root@localhost view v_product_tpl_brand_sum as
select `ugoods`.`producttpl_brand`.`type_id`                      AS `type_id`,
       group_concat(`ugoods`.`brand`.`brand_name` separator '; ') AS `brand_name`
from (`ugoods`.`producttpl_brand`
         left join `ugoods`.`brand` on ((`ugoods`.`producttpl_brand`.`brand_id` = `ugoods`.`brand`.`id`)))
group by `ugoods`.`producttpl_brand`.`type_id`;

