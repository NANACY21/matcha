create definer = root@`%` view v_departmentlevel as
select `a`.`id`                                                           AS `id`,
       `a`.`cCode`                                                        AS `cCode`,
       `a`.`cName`                                                        AS `cName`,
       `a`.`iGrade`                                                       AS `iGrade`,
       max((case when (`b`.`iGrade` = 1) then `b`.`cName` else NULL end)) AS `levelName1`,
       max((case when (`b`.`iGrade` = 2) then `b`.`cName` else NULL end)) AS `levelName2`,
       max((case when (`b`.`iGrade` = 3) then `b`.`cName` else NULL end)) AS `levelName3`,
       max((case when (`b`.`iGrade` = 4) then `b`.`cName` else NULL end)) AS `levelName4`,
       max((case when (`b`.`iGrade` = 5) then `b`.`cName` else NULL end)) AS `levelName5`,
       max((case when (`b`.`iGrade` = 6) then `b`.`cName` else NULL end)) AS `levelName6`,
       max((case when (`b`.`iGrade` = 1) then `b`.`cCode` else NULL end)) AS `levelCode1`,
       max((case when (`b`.`iGrade` = 2) then `b`.`cCode` else NULL end)) AS `levelCode2`,
       max((case when (`b`.`iGrade` = 3) then `b`.`cCode` else NULL end)) AS `levelCode3`,
       max((case when (`b`.`iGrade` = 4) then `b`.`cCode` else NULL end)) AS `levelCode4`,
       max((case when (`b`.`iGrade` = 5) then `b`.`cCode` else NULL end)) AS `levelCode5`,
       max((case when (`b`.`iGrade` = 6) then `b`.`cCode` else NULL end)) AS `levelCode6`
from (`ugoods`.`v_department` `a`
         left join `ugoods`.`v_department` `b` on ((`a`.`iSupparentID` like concat(`b`.`iSupparentID`, '%'))))
where ((`a`.`iOrgID` = `b`.`iOrgID`) and (`a`.`tenant_id` = `b`.`tenant_id`))
group by `a`.`id`, `a`.`cCode`, `a`.`cName`;

