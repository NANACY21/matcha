create definer = root@localhost view v_product_tpl_extendprop_valsum as
select `p`.`id` AS `id`, group_concat(`v`.`value` separator ';') AS `values`
from (`ugoods`.`product_tpl_extendprop` `p`
         left join `ugoods`.`product_tpl_extendprop_value` `v` on ((`p`.`id` = `v`.`property_id`)))
group by `p`.`id`;

