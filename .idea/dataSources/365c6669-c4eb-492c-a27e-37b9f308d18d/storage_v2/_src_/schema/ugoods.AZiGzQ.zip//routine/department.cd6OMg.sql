create
    definer = root@`%` procedure department()
begin 
	declare i int;
	set i = 2;
	while i < 5 do
		update mp_department a left join mp_department b on a.iParentID = b.id 
        set a.iSupparentID = concat(b.iSupparentID,b.id,',')
        where a.iGrade = i and a.tenant_id = b.tenant_id and a.iOrgID = b.iOrgID;   
		set i = i +1;
	end while;
end;

