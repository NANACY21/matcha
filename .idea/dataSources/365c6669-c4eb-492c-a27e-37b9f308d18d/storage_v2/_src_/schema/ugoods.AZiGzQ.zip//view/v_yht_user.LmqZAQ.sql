create definer = username2021@`%` view v_yht_user as
select 1 AS `id`,
       1 AS `user_name`,
       1 AS `user_code`,
       1 AS `user_email`,
       1 AS `user_mobile`,
       1 AS `activate`,
       1 AS `user_avator`,
       1 AS `user_avator_new`,
       1 AS `user_avator_new_big`,
       1 AS `user_avator_new_small`,
       1 AS `ts`,
       1 AS `weixin`,
       1 AS `qq`,
       1 AS `sex`;

