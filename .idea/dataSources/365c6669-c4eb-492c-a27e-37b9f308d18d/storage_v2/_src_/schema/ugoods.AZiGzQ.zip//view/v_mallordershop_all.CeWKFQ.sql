create definer = root@`%` view v_mallordershop_all as
select `upmalls`.`shop`.`id`        AS `id`,
       `upmalls`.`shop`.`cCorpName` AS `code`,
       `upmalls`.`shop`.`cShopname` AS `name`,
       `upmalls`.`shop`.`iCustId`   AS `customerId`,
       `upmalls`.`shop`.`pubuts`    AS `pubts`,
       `upmalls`.`shop`.`iCorpId`   AS `iCorpId`,
       `corp`.`yxytenantid`         AS `yxyTenantId`
from (`upmalls`.`shop`
         left join `upmalls`.`corpration` `corp` on ((`upmalls`.`shop`.`iCorpId` = `corp`.`id`)))
union
select `shop`.`id`        AS `id`,
       `shop`.`cName`     AS `code`,
       `shop`.`cFullName` AS `name`,
       `shop`.`iAgentId`  AS `customerId`,
       `shop`.`pubuts`    AS `pubts`,
       `shop`.`iCorpId`   AS `iCorpId`,
       `corp`.`cTenantId` AS `yxyTenantId`
from (`uorders_dev`.`merchant` `shop`
         left join `uorders_dev`.`yxycorp` `corp` on ((`shop`.`iCorpId` = `corp`.`iCorpId`)))
where ((`shop`.`iDeleted` = 0) and (`shop`.`id` <> 4))
union
select `uorders_dev`.`agent`.`id`      AS `id`,
       `uorders_dev`.`agent`.`cName`   AS `code`,
       `uorders_dev`.`agent`.`cName`   AS `name`,
       `uorders_dev`.`agent`.`id`      AS `customerId`,
       `uorders_dev`.`agent`.`pubuts`  AS `pubts`,
       `uorders_dev`.`agent`.`iCorpId` AS `iCorpId`,
       `corp`.`cTenantId`              AS `yxyTenantId`
from (`uorders_dev`.`agent`
         left join `uorders_dev`.`yxycorp` `corp` on ((`uorders_dev`.`agent`.`iCorpId` = `corp`.`iCorpId`)))
where ((`uorders_dev`.`agent`.`bURetailJoin` = 1) and (`uorders_dev`.`agent`.`bMerchant` = 0));

