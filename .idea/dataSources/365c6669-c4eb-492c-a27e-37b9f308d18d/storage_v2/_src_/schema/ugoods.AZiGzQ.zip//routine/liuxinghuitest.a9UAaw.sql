create
    definer = root@`%` procedure liuxinghuitest()
BEGIN
    DECLARE  tenant_id1 bigint(200);   -- id
    -- 遍历数据结束标志
    DECLARE done INT DEFAULT FALSE;
    -- 游标
    DECLARE cur_account CURSOR FOR  select  id from tenant;
    -- 将结束标志绑定到游标
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    -- 打开游标
    OPEN  cur_account;     
    -- 遍历
    read_loop: LOOP
            -- 取值 取租户id
            FETCH  NEXT from cur_account INTO tenant_id1;
            IF done THEN
                LEAVE read_loop;
             END IF;
 
        -- 你自己想做的操作
        select common.* from pb_filter_solution_common common 
        inner join tenant tenant on tenant.id = common.tenant_id 
        where common.itemName ='productId.creator' and 
        common.solutionId in
        (
        select solution.id from pb_filter_solution solution inner join bill_base bill on bill.cFilterId = solution.filtersId and bill.tenant_id = solution.tenant_id
        where bill.cBillNo = 'pc_goodsproductskuprolist' and  bill.tenant_id = tenant_id1
        )
        and common.tenant_id != tenant_id1;      
    END LOOP;
 
 
    CLOSE cur_account;
END;

