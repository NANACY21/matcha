create
    definer = username2021@`%` function f_getorglevel(orgId varchar(50)) returns int
BEGIN

    DECLARE sTemp INT;
    DECLARE sTempChd VARCHAR(255);
		DECLARE sPath INT;

    SET sTemp = 0;
    SET sTempChd =orgId;

    WHILE LENGTH(ifnull(sTempChd,'')) > 0 ||sTempChd is not null DO
      SET sTemp = sTemp+1;
      SELECT parentid INTO sTempChd FROM  iuap_cloud_basedoc.org_admin where id = sTempChd;
    END WHILE;
    set sPath =sTemp;
	RETURN sPath;
END;

