create definer = username2021@`%` view productcheckfreeview as
select `a`.`productId`           AS `productId`,
       `a`.`productApplyRangeId` AS `productApplyRangeId`,
       `a`.`freeId`              AS `freeId`,
       `a`.`id`                  AS `id`,
       `a`.`pubts`               AS `pubts`,
       `a`.`tenant_id`           AS `tenant_id`,
       `b`.`iRangeType`          AS `iRangeType`,
       `b`.`orgId`               AS `orgId`,
       `b`.`customerId`          AS `customerId`,
       `b`.`isCreator`           AS `isCreator`
from (`ugoods`.`productapplyrange` `b`
         left join `ugoods`.`productcheckfree` `a` on ((`a`.`productApplyRangeId` = `b`.`id`)));

