create definer = root@`%` view v_mallordershop as
select `v_mallordershop_all`.`id`              AS `id`,
       max(`v_mallordershop_all`.`code`)       AS `code`,
       max(`v_mallordershop_all`.`name`)       AS `name`,
       max(`v_mallordershop_all`.`customerId`) AS `customerId`,
       max(`v_mallordershop_all`.`pubts`)      AS `pubts`,
       max(`v_mallordershop_all`.`iCorpId`)    AS `iCorpId`,
       `v_mallordershop_all`.`yxyTenantId`     AS `yxyTenantId`
from `ugoods`.`v_mallordershop_all`
where ((`v_mallordershop_all`.`yxyTenantId` is not null) and (`v_mallordershop_all`.`id` <> 23708241499774))
group by `v_mallordershop_all`.`id`, `v_mallordershop_all`.`yxyTenantId`;

