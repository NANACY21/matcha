create definer = username2021@`%` view v_product_tpl_orderprop_sum as
select `prop`.`tpl_id`        AS `tpl_id`,
       `prop`.`propertyType`  AS `propertyType`,
       `prop`.`propertyAlias` AS `propertyAlias`,
       `prop`.`isShow`        AS `isShow`,
       `prop`.`isWebRequired` AS `isWebRequired`,
       `prop`.`id`            AS `id`,
       `prop`.`pubts`         AS `pubts`,
       `prop`.`iDeleted`      AS `isDeleted`,
       `prop`.`ordernumber`   AS `ordernumber`,
       `prop`.`iLimitNum`     AS `iLimitNum`,
       `vals`.`values`        AS `values`
from (`ugoods`.`product_tpl_orderprop` `prop`
         left join `ugoods`.`v_product_tpl_orderprop_valsum` `vals` on ((`prop`.`id` = `vals`.`id`)));

