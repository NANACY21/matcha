create definer = root@localhost view v_productalbum_min as
select `ugoods`.`productalbum`.`productId` AS `productid`, min(`ugoods`.`productalbum`.`id`) AS `firstrecord`
from `ugoods`.`productalbum`
group by `ugoods`.`productalbum`.`productId`;

