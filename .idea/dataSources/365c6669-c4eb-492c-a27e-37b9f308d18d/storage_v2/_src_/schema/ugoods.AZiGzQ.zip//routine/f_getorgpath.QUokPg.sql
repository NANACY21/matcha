create
    definer = username2021@`%` function f_getorgpath(orgId varchar(80)) returns varchar(8000)
BEGIN

    DECLARE sTemp VARCHAR(8000);
    DECLARE sTempChd VARCHAR(8000);
		DECLARE sPath VARCHAR(8000);

    SET sTemp = '';
    SET sTempChd =orgId;

    WHILE LENGTH(ifnull(sTempChd,'')) > 0 || sTempChd is not null DO
      SET sTemp = concat(sTempChd,"|",sTemp);
      SELECT parentid INTO sTempChd FROM  iuap_cloud_basedoc.org_admin where id = sTempChd;
    END WHILE;
    set sPath =sTemp;
	RETURN sPath;
END;

