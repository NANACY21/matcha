create definer = root@localhost view v_brandclssum as
select `cls`.`id`              AS `id`,
       `cls`.`brandclass_name` AS `brandclass_name`,
       `cls`.`brandclass_abbr` AS `brandclass_abbr`,
       `cls`.`brandclass_code` AS `brandclass_code`,
       `cls`.`pubts`           AS `pubts`,
       `cls`.`tenant_id`       AS `tenant_id`,
       `cls`.`iDeleted`        AS `isDeleted`,
       `v_brand`.`nameList`    AS `nameList`,
       `v_brand`.`brandCount`  AS `brandCount`
from (`ugoods`.`brandclass` `cls`
         left join `ugoods`.`v_brandsum` `v_brand` on ((`cls`.`id` = `v_brand`.`brandClass`)));

-- comment on column v_brandclssum.id not supported: ID

-- comment on column v_brandclssum.brandclass_name not supported: 品牌分类名称

-- comment on column v_brandclssum.brandclass_abbr not supported: 品牌分类备注

-- comment on column v_brandclssum.brandclass_code not supported: 品牌分类编码

-- comment on column v_brandclssum.pubts not supported: 时间戳

-- comment on column v_brandclssum.tenant_id not supported: 租户

-- comment on column v_brandclssum.isDeleted not supported: 逻辑删除标记

