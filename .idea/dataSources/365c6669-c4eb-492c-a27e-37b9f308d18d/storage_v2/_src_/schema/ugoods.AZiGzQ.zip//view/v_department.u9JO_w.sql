create definer = root@`%` view v_department as
select `ugoods`.`mp_department`.`id`        AS `id`,
       `ugoods`.`mp_department`.`cCode`     AS `cCode`,
       `ugoods`.`mp_department`.`cName`     AS `cName`,
       `ugoods`.`mp_department`.`iOrgID`    AS `iOrgID`,
       `ugoods`.`mp_department`.`tenant_id` AS `tenant_id`,
       `ugoods`.`mp_department`.`iGrade`    AS `iGrade`,
       `ugoods`.`mp_department`.`iParentID` AS `iParentID`,
       (case
            when (`ugoods`.`mp_department`.`iParentID` = 0) then `ugoods`.`mp_department`.`id`
            else substr(concat(`ugoods`.`mp_department`.`iSupparentID`, `ugoods`.`mp_department`.`id`), 3,
                        (length(concat(`ugoods`.`mp_department`.`iSupparentID`, `ugoods`.`mp_department`.`id`)) -
                         2)) end)           AS `iSupparentID`
from `ugoods`.`mp_department`;

