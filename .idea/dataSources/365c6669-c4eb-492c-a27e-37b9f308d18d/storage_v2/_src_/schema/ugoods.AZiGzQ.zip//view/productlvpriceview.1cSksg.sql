create definer = root@localhost view productlvpriceview as
select `a`.`productId`           AS `productId`,
       `a`.`productApplyRangeId` AS `productApplyRangeId`,
       `a`.`levelId`             AS `levelId`,
       `a`.`fLevelPrice`         AS `fLevelPrice`,
       `a`.`id`                  AS `id`,
       `a`.`pubts`               AS `pubts`,
       `a`.`tenant_id`           AS `tenant_id`,
       `b`.`iRangeType`          AS `iRangeType`,
       `b`.`orgId`               AS `orgId`,
       `b`.`customerId`          AS `customerId`
from (`ugoods`.`productlvprice` `a`
         left join `ugoods`.`productapplyrange` `b` on ((`a`.`productApplyRangeId` = `b`.`id`)));

-- comment on column productlvpriceview.productApplyRangeId not supported: 商品分配范围ID

-- comment on column productlvpriceview.levelId not supported: null

-- comment on column productlvpriceview.fLevelPrice not supported: 会员价

-- comment on column productlvpriceview.id not supported: ID

-- comment on column productlvpriceview.pubts not supported: 时间戳

-- comment on column productlvpriceview.tenant_id not supported: 租户

-- comment on column productlvpriceview.iRangeType not supported: 商品适用范围类型

-- comment on column productlvpriceview.orgId not supported: 组织ID

-- comment on column productlvpriceview.customerId not supported: 客户ID

