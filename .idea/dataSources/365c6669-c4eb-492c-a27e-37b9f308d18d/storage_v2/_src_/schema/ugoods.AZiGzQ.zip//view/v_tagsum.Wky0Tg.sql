create definer = root@localhost view v_tagsum as
select `ugoods`.`tag`.`tagClass`                              AS `tagClass`,
       group_concat(`ugoods`.`tag`.`tag_Name` separator '; ') AS `nameList`,
       count(`ugoods`.`tag`.`id`)                             AS `tagCount`
from `ugoods`.`tag`
group by `ugoods`.`tag`.`tagClass`;

-- comment on column v_tagsum.tagClass not supported: 标签分类

