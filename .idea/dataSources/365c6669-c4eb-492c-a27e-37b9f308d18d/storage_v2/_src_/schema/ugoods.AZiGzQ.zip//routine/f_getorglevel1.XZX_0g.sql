create
    definer = username2021@`%` function f_getorglevel1(orgId varchar(50), table_name varchar(50)) returns int
BEGIN

    DECLARE sTemp INT;
    DECLARE sTempChd VARCHAR(255);
		DECLARE sPath INT;
		DECLARE sTableName VARCHAR(50);

    SET sTemp = 0;
    SET sTempChd =orgId;
		SET sTableName=table_name;


    WHILE LENGTH(sTempChd) > 0 DO
      SET sTemp = sTemp+1;
		  if sTableName = 'org_admin' then
        SELECT parentid INTO sTempChd FROM  iuap_cloud_basedoc.org_admin where id = sTempChd;
			ELSEIF sTableName ='org_fin' then
			  SELECT parentid INTO sTempChd FROM  iuap_cloud_basedoc.org_fin where id = sTempChd;
				ELSEIF sTableName ='org_purchase' then
			  SELECT parentid INTO sTempChd FROM  iuap_cloud_basedoc.org_purchase where id = sTempChd;
				ELSEIF sTableName ='org_factory' then
			  SELECT parentid INTO sTempChd FROM  iuap_cloud_basedoc.org_factory where id = sTempChd;
				ELSEIF sTableName ='org_sales' then
			  SELECT parentid INTO sTempChd FROM  iuap_cloud_basedoc.org_sales where id = sTempChd;
				ELSEIF sTableName ='org_inventory' then
			  SELECT parentid INTO sTempChd FROM  iuap_cloud_basedoc.org_inventory where id = sTempChd;
			end if;
    END WHILE;
    set sPath =sTemp;
	RETURN sPath;
END;

