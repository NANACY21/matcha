create definer = root@`%` view shopproductskuview_v as
select `b`.`iRangeType`          AS `iRangeType`,
       `b`.`orgId`               AS `orgId`,
       `b`.`customerId`          AS `customerId`,
       `b`.`id`                  AS `iShopProductId`,
       `b`.`isCreator`           AS `isCreator`,
       `a`.`productId`           AS `productId`,
       `a`.`skuId`               AS `skuId`,
       `a`.`productApplyRangeId` AS `productApplyRangeId`,
       `a`.`iStatus`             AS `iStatus`,
       `a`.`iUStatus`            AS `iUStatus`,
       `a`.`batchPrice`          AS `batchPrice`,
       `a`.`fMarkPrice`          AS `fMarkPrice`,
       `a`.`fSalePrice`          AS `fSalePrice`,
       `a`.`fMarketPrice`        AS `fMarketPrice`,
       `a`.`fPrimeCosts`         AS `fPrimeCosts`,
       `a`.`fSettleAccountsRate` AS `fSettleAccountsRate`,
       `a`.`cBarCode`            AS `cBarCode`,
       `a`.`lInventoryCount`     AS `lInventoryCount`,
       `a`.`weight`              AS `weight`,
       `a`.`salePoints`          AS `salePoints`,
       `a`.`iSaled`              AS `iSaled`,
       `a`.`batchUnitId`         AS `batchUnitId`,
       `a`.`batchRate`           AS `batchRate`,
       `a`.`iMinOrderQuantity`   AS `iMinOrderQuantity`,
       `a`.`batchDeliveryDays`   AS `batchDeliveryDays`,
       `b`.`id`                  AS `id`,
       `a`.`pubts`               AS `pubts`,
       `b`.`tenant_id`           AS `tenant_id`,
       `a`.`shortName`           AS `shortName`,
       `a`.`iStatus_b`           AS `iStatus_b`,
       `a`.`iUStatus_b`          AS `iUStatus_b`,
       `a`.`fNoTaxCostPrice`     AS `fNoTaxCostPrice`,
       `a`.`stopstatus`          AS `stopstatus`
from (`ugoods`.`productapplyrange` `b`
         left join `ugoods`.`productskudetail` `a`
                   on (((`a`.`productApplyRangeId` = `b`.`id`) and (`a`.`productId` = `b`.`productId`))));

-- comment on column shopproductskuview_v.iRangeType not supported: 商品适用范围类型

-- comment on column shopproductskuview_v.orgId not supported: 组织ID

-- comment on column shopproductskuview_v.customerId not supported: 客户ID

-- comment on column shopproductskuview_v.iShopProductId not supported: ID

-- comment on column shopproductskuview_v.isCreator not supported: 是否创建者

-- comment on column shopproductskuview_v.productId not supported: 所属商品

-- comment on column shopproductskuview_v.skuId not supported: SKUID

-- comment on column shopproductskuview_v.productApplyRangeId not supported: 商品适用范围ID

-- comment on column shopproductskuview_v.iStatus not supported: 商城上下架状态

-- comment on column shopproductskuview_v.iUStatus not supported: U订货上下架状态

-- comment on column shopproductskuview_v.fSettleAccountsRate not supported: 结算费率

-- comment on column shopproductskuview_v.cBarCode not supported: SKU条形码

-- comment on column shopproductskuview_v.lInventoryCount not supported: 库存

-- comment on column shopproductskuview_v.weight not supported: 重量

-- comment on column shopproductskuview_v.salePoints not supported: 积分数量

-- comment on column shopproductskuview_v.batchUnitId not supported: 批发单位

-- comment on column shopproductskuview_v.batchRate not supported: 批发单位换算率

-- comment on column shopproductskuview_v.iMinOrderQuantity not supported: 批发-起订量

-- comment on column shopproductskuview_v.batchDeliveryDays not supported: 批发-交货周期（天）

-- comment on column shopproductskuview_v.id not supported: ID

-- comment on column shopproductskuview_v.pubts not supported: 时间戳

-- comment on column shopproductskuview_v.tenant_id not supported: 租户

-- comment on column shopproductskuview_v.shortName not supported: SKU简称

-- comment on column shopproductskuview_v.iStatus_b not supported: 商城上下架状态_备用

-- comment on column shopproductskuview_v.iUStatus_b not supported: U订货上下架状态_备用

-- comment on column shopproductskuview_v.stopstatus not supported: 停用状态

