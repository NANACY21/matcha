create view productskuview_v as
select `a`.`productId`           AS `productId`,
       `a`.`code`                AS `code`,
       `a`.`name`                AS `name`,
       `a`.`isSKU`               AS `isSKU`,
       `a`.`free1`               AS `free1`,
       `a`.`free2`               AS `free2`,
       `a`.`free3`               AS `free3`,
       `a`.`free4`               AS `free4`,
       `a`.`free5`               AS `free5`,
       `a`.`free6`               AS `free6`,
       `a`.`free7`               AS `free7`,
       `a`.`free8`               AS `free8`,
       `a`.`free9`               AS `free9`,
       `a`.`free10`              AS `free10`,
       `a`.`cSpecIds`            AS `cSpecIds`,
       `a`.`cSpecs`              AS `cSpecs`,
       `a`.`nameList`            AS `nameList`,
       `a`.`specNames`           AS `specNames`,
       `a`.`id`                  AS `id`,
       `a`.`pubts`               AS `pubts`,
       `a`.`erpCode`             AS `erpCode`,
       `a`.`tenant_id`           AS `tenant_id`,
       `a`.`iDeleted`            AS `iDeleted`,
       `a`.`cModelDescription`   AS `cModelDescription`,
       `b`.`fSalePrice`          AS `fSalePrice`,
       `b`.`batchPrice`          AS `batchPrice`,
       `b`.`fMarkPrice`          AS `fMarkPrice`,
       `b`.`fMarketPrice`        AS `fMarketPrice`,
       `b`.`fPrimeCosts`         AS `fPrimeCosts`,
       `b`.`iStatus`             AS `iStatus`,
       `b`.`fSettleAccountsRate` AS `fSettleAccountsRate`,
       `b`.`cBarCode`            AS `cBarCode`,
       `b`.`lInventoryCount`     AS `lInventoryCount`,
       `b`.`weight`              AS `weight`,
       `b`.`salePoints`          AS `salePoints`,
       `b`.`iSaled`              AS `iSaled`,
       `b`.`batchUnitId`         AS `batchUnitId`,
       `b`.`batchRate`           AS `batchRate`,
       `b`.`iMinOrderQuantity`   AS `iMinOrderQuantity`,
       `b`.`batchDeliveryDays`   AS `batchDeliveryDays`,
       `b`.`fNoTaxCostPrice`     AS `fNoTaxCostPrice`,
       `b`.`shortName`           AS `shortName`,
       `b`.`stopstatus`          AS `stopstatus`
from (`ugoods`.`productsku` `a`
         join `ugoods`.`productskuextend` `b` on ((`a`.`id` = `b`.`skuId`)));

-- comment on column productskuview_v.productId not supported: 所属商品

-- comment on column productskuview_v.code not supported: SKU编码

-- comment on column productskuview_v.name not supported: SKU名称

-- comment on column productskuview_v.isSKU not supported: 是否SKU

-- comment on column productskuview_v.free1 not supported: 商品规格1

-- comment on column productskuview_v.free2 not supported: 商品规格2

-- comment on column productskuview_v.free3 not supported: 商品规格3

-- comment on column productskuview_v.free4 not supported: 商品规格4

-- comment on column productskuview_v.free5 not supported: 商品规格5

-- comment on column productskuview_v.free6 not supported: 商品规格6

-- comment on column productskuview_v.free7 not supported: 商品规格7

-- comment on column productskuview_v.free8 not supported: 商品规格8

-- comment on column productskuview_v.free9 not supported: 商品规格9

-- comment on column productskuview_v.free10 not supported: 商品规格10

-- comment on column productskuview_v.cSpecIds not supported: 规格ID

-- comment on column productskuview_v.cSpecs not supported: 规格值

-- comment on column productskuview_v.nameList not supported: 商品SKU多个标签组成的字符串

-- comment on column productskuview_v.specNames not supported: 五个动态规格与值

-- comment on column productskuview_v.id not supported: ID

-- comment on column productskuview_v.pubts not supported: 时间戳

-- comment on column productskuview_v.erpCode not supported: 商家编码

-- comment on column productskuview_v.tenant_id not supported: 租户

-- comment on column productskuview_v.iDeleted not supported: 逻辑删除标记

-- comment on column productskuview_v.cModelDescription not supported: 规格型号

-- comment on column productskuview_v.iStatus not supported: 商城上下架状态

-- comment on column productskuview_v.fSettleAccountsRate not supported: 结算费率

-- comment on column productskuview_v.cBarCode not supported: SKU条形码

-- comment on column productskuview_v.lInventoryCount not supported: 库存

-- comment on column productskuview_v.weight not supported: 重量

-- comment on column productskuview_v.salePoints not supported: 积分数量

-- comment on column productskuview_v.batchUnitId not supported: 批发单位

-- comment on column productskuview_v.batchRate not supported: 批发单位换算率

-- comment on column productskuview_v.iMinOrderQuantity not supported: 批发-起订量

-- comment on column productskuview_v.batchDeliveryDays not supported: 批发-交货周期（天）

-- comment on column productskuview_v.shortName not supported: SKU简称

-- comment on column productskuview_v.stopstatus not supported: 停用状态

