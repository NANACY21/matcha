create view user_org as
select `ugoods`.`user`.`id` AS `user_id`, `v_orgs`.`id` AS `org_id`, NULL AS `id`, NULL AS `pubts`, 0 AS `isdefault`
from (`ugoods`.`user`
         join `ugoods`.`v_orgs` on ((`ugoods`.`user`.`tenant_id` = `v_orgs`.`tenant_id`)))
where (`ugoods`.`user`.`user_type` in (0, 1));

-- comment on column user_org.org_id not supported: 主键

