create
    definer = chenhy@`%` procedure p_aa_updateIndex(IN tablename varchar(50), IN indexname varchar(50),
                                                    IN executeStr varchar(1000), IN executeType varchar(50))
BEGIN
		DECLARE  CurrentDatabase VARCHAR(100);
		SELECT DATABASE() INTO CurrentDatabase;
		SET @tablename = tablename;
		SET @indexname = indexname;
		SET @executeType = executeType;
		SET @executeStr = executeStr;
		SET @count = (SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=CurrentDatabase AND TABLE_NAME=@tablename AND index_name=@indexname);
		IF @executeType	= 'add' AND @count = 0 THEN
			PREPARE stmt1 FROM @executeStr;
			EXECUTE stmt1;
		ELSEIF @executeType	= 'alter' AND @count >0 THEN
			PREPARE stmt1 FROM @executeStr;
			EXECUTE stmt1;
		END IF;
	END;

