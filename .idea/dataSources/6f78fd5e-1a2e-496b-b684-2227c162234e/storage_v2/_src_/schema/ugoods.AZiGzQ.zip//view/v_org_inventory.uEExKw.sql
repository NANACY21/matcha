create view v_org_inventory as
select `iuap_cloud_basedoc`.`org_inventory`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`org_inventory`.`name`                                   AS `cName`,
       `iuap_cloud_basedoc`.`org_inventory`.`name`                                   AS `cFullName`,
       `iuap_cloud_basedoc`.`org_inventory`.`displayorder`                           AS `iSortNum`,
       0                                                                             AS `bIsEnd`,
       NULL                                                                          AS `cOrgFuncId`,
       0                                                                             AS `bIsGlobal`,
       NULL                                                                          AS `cErpCode`,
       NULL                                                                          AS `cEaiCode`,
       `iuap_cloud_basedoc`.`org_inventory`.`parentid`                               AS `iparentId`,
       (case `iuap_cloud_basedoc`.`org_inventory`.`enable` when 1 then 0 else 1 end) AS `bStopStatus`,
       NULL                                                                          AS `dStopTime`,
       `iuap_cloud_basedoc`.`org_inventory`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_inventory`.`creationtime`                           AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_inventory`.`modifiedtime`                           AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_inventory`.`modifiedtime`                           AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_inventory`.`creator`                                AS `cCreator`,
       `iuap_cloud_basedoc`.`org_inventory`.`modifier`                               AS `cModifier`,
       `iuap_cloud_basedoc`.`org_inventory`.`creator`                                AS `creatorId`,
       `iuap_cloud_basedoc`.`org_inventory`.`modifier`                               AS `modifierId`,
       `iuap_cloud_basedoc`.`org_inventory`.`orgid`                                  AS `orgid`,
       `iuap_cloud_basedoc`.`org_inventory`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_inventory`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                        AS `tenant_id`,
       NULL                                                                          AS `customerId`,
       `iuap_cloud_basedoc`.`org_inventory`.`finorgid`                               AS `finorgid`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_inventory`
                   on ((`iuap_cloud_basedoc`.`org_inventory`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_inventory`.`dr` = 0);

-- comment on column v_org_inventory.cCode not supported: 编码

-- comment on column v_org_inventory.cName not supported: 名称

-- comment on column v_org_inventory.cFullName not supported: 名称

-- comment on column v_org_inventory.iSortNum not supported: 显示顺序

-- comment on column v_org_inventory.iparentId not supported: 上级节点

-- comment on column v_org_inventory.dCreateTime not supported: 创建时间

-- comment on column v_org_inventory.dCreateDate not supported: 创建时间

-- comment on column v_org_inventory.dModifyTime not supported: 修改时间

-- comment on column v_org_inventory.dModifyDate not supported: 修改时间

-- comment on column v_org_inventory.cCreator not supported: 创建人

-- comment on column v_org_inventory.cModifier not supported: 修改人

-- comment on column v_org_inventory.creatorId not supported: 创建人

-- comment on column v_org_inventory.modifierId not supported: 修改人

-- comment on column v_org_inventory.orgid not supported: 组织单元主键

-- comment on column v_org_inventory.id not supported: 主键

-- comment on column v_org_inventory.pubts not supported: 公共时间戳

-- comment on column v_org_inventory.tenant_id not supported: ID

-- comment on column v_org_inventory.finorgid not supported: 关联财务组织主键

