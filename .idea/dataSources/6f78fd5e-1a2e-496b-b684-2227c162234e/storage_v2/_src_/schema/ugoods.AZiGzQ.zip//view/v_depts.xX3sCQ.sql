create view v_depts as
select `iuap_cloud_basedoc`.`org_admin`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_admin`.`ts`                                     AS `ts`,
       `iuap_cloud_basedoc`.`org_admin`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`org_admin`.`name`                                   AS `cFullName`,
       `iuap_cloud_basedoc`.`org_admin`.`name`                                   AS `cName`,
       (case
            when (`iuap_cloud_basedoc`.`org_admin`.`parentid` = '') then NULL
            else `iuap_cloud_basedoc`.`org_admin`.`parentid` end)                AS `iparentId`,
       `iuap_cloud_basedoc`.`org_admin`.`level`                                  AS `iGrade`,
       `iuap_cloud_basedoc`.`org_admin`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_admin`.`creationtime`                           AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_admin`.`modifiedtime`                           AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_admin`.`modifiedtime`                           AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_admin`.`creator`                                AS `cCreator`,
       `iuap_cloud_basedoc`.`org_admin`.`modifier`                               AS `cModifier`,
       `iuap_cloud_basedoc`.`org_admin`.`creator`                                AS `creatorId`,
       `iuap_cloud_basedoc`.`org_admin`.`modifier`                               AS `modifierId`,
       `iuap_cloud_basedoc`.`org_admin`.`isEnd`                                  AS `bIsEnd`,
       `iuap_cloud_basedoc`.`org_admin`.`displayorder`                           AS `iSortNum`,
       `iuap_cloud_basedoc`.`org_admin`.`depttype`                               AS `depttype`,
       `iuap_cloud_basedoc`.`org_admin`.`principal`                              AS `principal`,
       NULL                                                                      AS `iSupparentID`,
       NULL                                                                      AS `cErpCode`,
       `iuap_cloud_basedoc`.`org_admin`.`parentorgid`                            AS `iOrgID`,
       (case `iuap_cloud_basedoc`.`org_admin`.`enable` when 1 then 0 else 1 end) AS `bStopStatus`,
       NULL                                                                      AS `dStopTime`,
       NULL                                                                      AS `cMemo`,
       NULL                                                                      AS `iCorpId`,
       NULL                                                                      AS `cAppID`,
       `ugoods`.`tenant`.`id`                                                    AS `tenant_id`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`org_admin`
              on ((`iuap_cloud_basedoc`.`org_admin`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where ((`iuap_cloud_basedoc`.`org_admin`.`orgtype` = 2) and (`iuap_cloud_basedoc`.`org_admin`.`dr` = 0) and
       (`iuap_cloud_basedoc`.`org_admin`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`));

-- comment on column v_depts.id not supported: 主键

-- comment on column v_depts.ts not supported: 公共时间戳

-- comment on column v_depts.iGrade not supported: 层级

-- comment on column v_depts.dCreateTime not supported: 创建时间

-- comment on column v_depts.dCreateDate not supported: 创建时间

-- comment on column v_depts.dModifyTime not supported: 修改时间

-- comment on column v_depts.dModifyDate not supported: 修改时间

-- comment on column v_depts.cCreator not supported: 创建者

-- comment on column v_depts.cModifier not supported: 修改人

-- comment on column v_depts.creatorId not supported: 创建者

-- comment on column v_depts.modifierId not supported: 修改人

-- comment on column v_depts.iSortNum not supported: 显示顺序

-- comment on column v_depts.depttype not supported: 部门性质

-- comment on column v_depts.principal not supported: 负责人

-- comment on column v_depts.iOrgID not supported: 上级主键ID

-- comment on column v_depts.tenant_id not supported: ID

