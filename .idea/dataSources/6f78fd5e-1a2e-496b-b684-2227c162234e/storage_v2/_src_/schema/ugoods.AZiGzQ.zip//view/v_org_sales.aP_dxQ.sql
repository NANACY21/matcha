create view v_org_sales as
select `iuap_cloud_basedoc`.`org_sales`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`org_sales`.`name`                                   AS `cName`,
       `iuap_cloud_basedoc`.`org_sales`.`name`                                   AS `cFullName`,
       `iuap_cloud_basedoc`.`org_sales`.`displayorder`                           AS `iSortNum`,
       0                                                                         AS `bIsEnd`,
       NULL                                                                      AS `cOrgFuncId`,
       0                                                                         AS `bIsGlobal`,
       NULL                                                                      AS `cErpCode`,
       NULL                                                                      AS `cEaiCode`,
       `iuap_cloud_basedoc`.`org_sales`.`parentid`                               AS `iparentId`,
       (case `iuap_cloud_basedoc`.`org_sales`.`enable` when 1 then 0 else 1 end) AS `bStopStatus`,
       NULL                                                                      AS `dStopTime`,
       `iuap_cloud_basedoc`.`org_sales`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_sales`.`creationtime`                           AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_sales`.`modifiedtime`                           AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_sales`.`modifiedtime`                           AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_sales`.`creator`                                AS `cCreator`,
       `iuap_cloud_basedoc`.`org_sales`.`modifier`                               AS `cModifier`,
       `iuap_cloud_basedoc`.`org_sales`.`creator`                                AS `creatorId`,
       `iuap_cloud_basedoc`.`org_sales`.`modifier`                               AS `modifierId`,
       `iuap_cloud_basedoc`.`org_sales`.`orgid`                                  AS `orgid`,
       `iuap_cloud_basedoc`.`org_sales`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_sales`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                    AS `tenant_id`,
       NULL                                                                      AS `customerId`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_sales`
                   on ((`iuap_cloud_basedoc`.`org_sales`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_sales`.`dr` = 0);

-- comment on column v_org_sales.cCode not supported: 编码

-- comment on column v_org_sales.cName not supported: 名称

-- comment on column v_org_sales.cFullName not supported: 名称

-- comment on column v_org_sales.iSortNum not supported: 显示顺序

-- comment on column v_org_sales.iparentId not supported: 上级节点

-- comment on column v_org_sales.dCreateTime not supported: 创建时间

-- comment on column v_org_sales.dCreateDate not supported: 创建时间

-- comment on column v_org_sales.dModifyTime not supported: 修改时间

-- comment on column v_org_sales.dModifyDate not supported: 修改时间

-- comment on column v_org_sales.cCreator not supported: 创建人

-- comment on column v_org_sales.cModifier not supported: 修改人

-- comment on column v_org_sales.creatorId not supported: 创建人

-- comment on column v_org_sales.modifierId not supported: 修改人

-- comment on column v_org_sales.orgid not supported: 组织单元主键

-- comment on column v_org_sales.id not supported: 主键

-- comment on column v_org_sales.pubts not supported: 公共时间戳

-- comment on column v_org_sales.tenant_id not supported: ID

