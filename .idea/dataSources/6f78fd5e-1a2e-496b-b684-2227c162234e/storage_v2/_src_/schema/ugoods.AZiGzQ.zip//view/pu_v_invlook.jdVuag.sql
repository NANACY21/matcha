create view pu_v_invlook as
select distinct `ugoods`.`pu_venandinv`.`product_id` AS `id`,
                ''                                   AS `code`,
                'tempName222'                        AS `name`,
                `ugoods`.`pu_venandinv`.`product_id` AS `product_id`,
                `ugoods`.`pu_venandinv`.`lookat`     AS `lookat`,
                `ugoods`.`pu_venandinv`.`tenant_id`  AS `tenant_id`,
                ''                                   AS `parent_id`,
                1                                    AS `level`,
                ''                                   AS `path`,
                1                                    AS `sort_num`,
                1                                    AS `isEnd`,
                ''                                   AS `pubts`
from `ugoods`.`pu_venandinv`;

-- comment on column pu_v_invlook.id not supported: 物料id

-- comment on column pu_v_invlook.product_id not supported: 物料id

-- comment on column pu_v_invlook.lookat not supported: 维度

-- comment on column pu_v_invlook.tenant_id not supported: 租户

