create view v_yht_user_test as
(
select `yhtdb`.`pub_tenant_user`.`user_id`               AS `id`,
       `yhtdb`.`pub_tenant_user`.`user_name`             AS `user_name`,
       `yhtdb`.`pub_tenant_user`.`user_code`             AS `user_code`,
       `yhtdb`.`pub_tenant_user`.`user_email`            AS `user_email`,
       `yhtdb`.`pub_tenant_user`.`user_mobile`           AS `user_mobile`,
       `yhtdb`.`pub_tenant_user`.`activate`              AS `activate`,
       `yhtdb`.`pub_tenant_user`.`user_avator`           AS `user_avator`,
       `yhtdb`.`pub_tenant_user`.`user_avator_new`       AS `user_avator_new`,
       `yhtdb`.`pub_tenant_user`.`user_avator_new_big`   AS `user_avator_new_big`,
       `yhtdb`.`pub_tenant_user`.`user_avator_new_small` AS `user_avator_new_small`,
       `yhtdb`.`pub_tenant_user`.`ts`                    AS `ts`,
       `yhtdb`.`pub_tenant_user`.`weixin`                AS `weixin`,
       `yhtdb`.`pub_tenant_user`.`qq`                    AS `qq`,
       `yhtdb`.`pub_tenant_user`.`sex`                   AS `sex`
from `yhtdb`.`pub_tenant_user`);

