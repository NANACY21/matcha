create definer = lihk@`%` view st_v_purchaseorder_modify_version as
select `ustock`.`st_purchaseorder_modify`.`id`                         AS `id`,
       `ustock`.`st_purchaseorder_modify`.`modifyNumber`               AS `code`,
       concat('版本', `ustock`.`st_purchaseorder_modify`.`modifyNumber`) AS `name`,
       `ustock`.`st_purchaseorder_modify`.`tenant_id`                  AS `tenant_id`,
       ''                                                              AS `parent_id`,
       1                                                               AS `level`,
       `ustock`.`st_purchaseorder_modify`.`modifyMainId`               AS `path`,
       1                                                               AS `sort_num`,
       1                                                               AS `isEnd`,
       ''                                                              AS `pubts`
from `ustock`.`st_purchaseorder_modify`
where (`ustock`.`st_purchaseorder_modify`.`modifyNumber` > 0)
order by `ustock`.`st_purchaseorder_modify`.`modifyMainId`, `ustock`.`st_purchaseorder_modify`.`modifyNumber` desc;

-- comment on column st_v_purchaseorder_modify_version.id not supported: ID

-- comment on column st_v_purchaseorder_modify_version.code not supported: 变更单版本号

-- comment on column st_v_purchaseorder_modify_version.tenant_id not supported: 租户

-- comment on column st_v_purchaseorder_modify_version.path not supported: 采购订单主表id

