create definer = yonyou@`%` view v_st_storein_report as
select `a`.`id`              AS `id`,
       `a`.`iinorgid`        AS `iOrgid`,
       `a`.`ioutorgid`       AS `ioutorgid`,
       `a`.`ioutstoreid`     AS `ioutstoreid`,
       `a`.`ioutwarehouseid` AS `ioutwarehouseid`,
       `a`.`iinstoreid`      AS `iinstoreid`,
       `a`.`iinwarehouseid`  AS `iinwarehouseid`,
       `a`.`ibustypeid`      AS `ibustypeid`,
       `a`.`ioperatorid`     AS `ioperatorid`,
       `a`.`csrcbillid`      AS `csrcbillid`,
       `a`.`csrcbillno`      AS `csrcbillno`,
       `a`.`csrcbilltype`    AS `csrcbilltype`,
       `a`.`vouchdate`       AS `vouchdate`,
       `a`.`status`          AS `status`,
       `a`.`code`            AS `code`,
       `a`.`tenant_id`       AS `tenant_id`,
       `a`.`iStoreID`        AS `iStoreID`,
       `a`.`instorekeeperid` AS `stock_mgr`,
       `a`.`iShopID`         AS `iShopID`
from `ustock`.`st_storein` `a`;

-- comment on column v_st_storein_report.id not supported: ID

-- comment on column v_st_storein_report.iOrgid not supported: 调入组织

-- comment on column v_st_storein_report.ioutorgid not supported: 调出组织

-- comment on column v_st_storein_report.ioutstoreid not supported: 调出门店

-- comment on column v_st_storein_report.ioutwarehouseid not supported: 调出仓库

-- comment on column v_st_storein_report.iinstoreid not supported: 调入门店

-- comment on column v_st_storein_report.iinwarehouseid not supported: 调入仓库

-- comment on column v_st_storein_report.csrcbillid not supported: 来源单据

-- comment on column v_st_storein_report.csrcbillno not supported: 来源单据号

-- comment on column v_st_storein_report.vouchdate not supported: 单据日期

-- comment on column v_st_storein_report.status not supported: 单据状态

-- comment on column v_st_storein_report.tenant_id not supported: 租户

-- comment on column v_st_storein_report.iStoreID not supported: 门店ID

-- comment on column v_st_storein_report.stock_mgr not supported: 调入库管员

-- comment on column v_st_storein_report.iShopID not supported: 商家

