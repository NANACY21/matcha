create definer = yonyou@`%` view productcheckfreeview as
select `a`.`productId`           AS `productId`,
       `a`.`productApplyRangeId` AS `productApplyRangeId`,
       `a`.`freeId`              AS `freeId`,
       `a`.`id`                  AS `id`,
       `a`.`pubts`               AS `pubts`,
       `a`.`tenant_id`           AS `tenant_id`,
       `b`.`iRangeType`          AS `iRangeType`,
       `b`.`orgId`               AS `orgId`,
       `b`.`customerId`          AS `customerId`,
       `b`.`isCreator`           AS `isCreator`
from (`ugoods`.`productapplyrange` `b`
         left join `ugoods`.`productcheckfree` `a` on ((`a`.`productApplyRangeId` = `b`.`id`)));

-- comment on column productcheckfreeview.productId not supported: 所属商品

-- comment on column productcheckfreeview.productApplyRangeId not supported: 商品分配范围ID

-- comment on column productcheckfreeview.freeId not supported: 核算规格ID

-- comment on column productcheckfreeview.id not supported: ID

-- comment on column productcheckfreeview.pubts not supported: 时间戳

-- comment on column productcheckfreeview.tenant_id not supported: 租户

-- comment on column productcheckfreeview.iRangeType not supported: 商品适用范围类型

-- comment on column productcheckfreeview.customerId not supported: 客户ID

-- comment on column productcheckfreeview.isCreator not supported: 是否创建者

