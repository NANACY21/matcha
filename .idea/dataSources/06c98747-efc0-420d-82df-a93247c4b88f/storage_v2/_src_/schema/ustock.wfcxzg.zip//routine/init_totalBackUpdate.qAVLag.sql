create
    definer = yonyou@`%` procedure init_totalBackUpdate(IN oriTableName varchar(80), IN targetTableName varchar(80),
                                                        IN updateColum varchar(80), IN targetColum varchar(80))
BEGIN
		
		DECLARE s int DEFAULT 0;
		DECLARE oriId bigint(20);
		
		DECLARE report CURSOR FOR SELECT id FROM v_view;
		
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET s=1;
		DROP VIEW IF EXISTS v_view;
    SET @sqlstr = 'CREATE VIEW v_view as ';
    SET @sqlstr = CONCAT(@sqlstr , 'SELECT id FROM ',oriTableName);
		PREPARE stmt FROM @sqlstr;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
		
		open report;
		
		fetch report into oriId;
		
		while s<>1 do
		
		SET @sqlstr1 = 'UPDATE';
		SET @sqlstr1 = CONCAT(@sqlstr1, ' ',oriTableName,' set ',updateColum,' = (SELECT sum(',targetColum,') as total FROM ',targetTableName,' WHERE iMainid = ',oriId,') WHERE id = ',oriId,'');
		PREPARE stmt1 FROM @sqlstr1;
    EXECUTE stmt1;
		
		fetch report into oriId;
		
		end while;
		
		close report;
	END;

