create definer = lihk@`%` view pu_paymentexedetail_view as
(
select `p`.`firstsourceid` AS `iMainId`,
       `p`.`vouchtype`     AS `vouchtype`,
       `p`.`vouchid`       AS `vouchid`,
       `p`.`vouchsubid`    AS `vouchsubid`,
       `p`.`vouchcode`     AS `vouchcode`,
       `p`.`iorder`        AS `iNumber`,
       `p`.`startBase`     AS `period`,
       `p`.`paySum`        AS `paySum`,
       `p`.`payRatio`      AS `payRatio`,
       `p`.`payMoney`      AS `payMoney`,
       `p`.`paidMoney`     AS `paidMoney`,
       `p`.`writeBackSum`  AS `writeBackSum`,
       `p`.`startBaseDate` AS `startDateTime`,
       `p`.`expireDate`    AS `expiringDateTime`,
       `p`.`preReceive`    AS `isAdvancePay`,
       `p`.`id`            AS `id`,
       `p`.`pubts`         AS `pubts`,
       NULL                AS `rowno`
from `ustock`.`pu_paymentexedetail` `p`
where (`p`.`firstsource` = 'st_purchaseorder'));

-- comment on column pu_paymentexedetail_view.iMainId not supported: 源头单据主表id

-- comment on column pu_paymentexedetail_view.vouchtype not supported: 单据类型

-- comment on column pu_paymentexedetail_view.vouchid not supported: 单据主表id

-- comment on column pu_paymentexedetail_view.vouchsubid not supported: 单据子表id

-- comment on column pu_paymentexedetail_view.vouchcode not supported: 单据编号

-- comment on column pu_paymentexedetail_view.iNumber not supported: 顺序

-- comment on column pu_paymentexedetail_view.period not supported: 起算阶段

-- comment on column pu_paymentexedetail_view.paySum not supported: 付款总金额

-- comment on column pu_paymentexedetail_view.payRatio not supported: 付款比例

-- comment on column pu_paymentexedetail_view.payMoney not supported: 付款金额

-- comment on column pu_paymentexedetail_view.paidMoney not supported: 冲销金额

-- comment on column pu_paymentexedetail_view.writeBackSum not supported: 回写金额

-- comment on column pu_paymentexedetail_view.startDateTime not supported: 起算日

-- comment on column pu_paymentexedetail_view.expiringDateTime not supported: 到期日

-- comment on column pu_paymentexedetail_view.isAdvancePay not supported: 有无预收

-- comment on column pu_paymentexedetail_view.id not supported: ID

-- comment on column pu_paymentexedetail_view.pubts not supported: 时间戳

