create definer = yonyou@`%` view pu_v_invlook as
select distinct `ustock`.`pu_venandinv`.`product_id`      AS `id`,
                ''                                        AS `code`,
                'tempName222'                             AS `name`,
                `ustock`.`pu_venandinv`.`product_id`      AS `product_id`,
                `ustock`.`pu_venandinv`.`lookat`          AS `lookat`,
                `ustock`.`pu_venandinv`.`tenant_id`       AS `tenant_id`,
                ''                                        AS `parent_id`,
                1                                         AS `level`,
                ''                                        AS `path`,
                1                                         AS `sort_num`,
                1                                         AS `isEnd`,
                `ustock`.`pu_venandinv`.`organization_id` AS `org`,
                ''                                        AS `pubts`
from `ustock`.`pu_venandinv`;

-- comment on column pu_v_invlook.id not supported: 物料id

-- comment on column pu_v_invlook.product_id not supported: 物料id

-- comment on column pu_v_invlook.lookat not supported: 维度

-- comment on column pu_v_invlook.tenant_id not supported: 租户

-- comment on column pu_v_invlook.org not supported: 组织id

