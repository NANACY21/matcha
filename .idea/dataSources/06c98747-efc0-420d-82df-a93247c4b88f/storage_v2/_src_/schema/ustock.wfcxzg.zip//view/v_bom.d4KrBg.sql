create definer = yonyou@`%` view v_bom as
select `ustock`.`st_salesout`.`ibustypeid`          AS `ibustypeid`,
       `ustock`.`st_salesout`.`istockdirection`     AS `istockdirection`,
       `ustock`.`st_salesout`.`iOrgid`              AS `iOrgid`,
       `ustock`.`st_salesout`.`imerchant`           AS `imerchant`,
       `ustock`.`st_salesout`.`department`          AS `department`,
       `ustock`.`st_salesout`.`stock_mgr`           AS `stock_mgr`,
       `ustock`.`st_salesout`.`iwarehouse`          AS `iwarehouse`,
       `ustock`.`st_salesout`.`ioperatorid`         AS `ioperatorid`,
       `ustock`.`st_salesout`.`cmemo`               AS `cmemo`,
       `ustock`.`st_salesout`.`csrcbillid`          AS `csrcbillid`,
       `ustock`.`st_salesout`.`csrcbillno`          AS `csrcbillno`,
       `ustock`.`st_salesout`.`csrcbilltype`        AS `csrcbilltype`,
       `ustock`.`st_salesout`.`vouchdate`           AS `vouchdate`,
       `ustock`.`st_salesout`.`tplid`               AS `tplid`,
       `ustock`.`st_salesout`.`status`              AS `status`,
       `ustock`.`st_salesout`.`id`                  AS `id`,
       `ustock`.`st_salesout`.`pubts`               AS `pubts`,
       `ustock`.`st_salesout`.`code`                AS `code`,
       `ustock`.`st_salesout`.`create_time`         AS `create_time`,
       `ustock`.`st_salesout`.`create_date`         AS `create_date`,
       `ustock`.`st_salesout`.`modify_time`         AS `modify_time`,
       `ustock`.`st_salesout`.`modify_date`         AS `modify_date`,
       `ustock`.`st_salesout`.`creator`             AS `creator`,
       `ustock`.`st_salesout`.`modifier`            AS `modifier`,
       `ustock`.`st_salesout`.`tenant_id`           AS `tenant_id`,
       `ustock`.`st_salesout`.`auditor`             AS `auditor`,
       `ustock`.`st_salesout`.`audit_time`          AS `audit_time`,
       `ustock`.`st_salesout`.`audit_date`          AS `audit_date`,
       `ustock`.`st_salesout`.`iCustID`             AS `iCustID`,
       `ustock`.`st_salesout`.`fTotalQuantity`      AS `fTotalQuantity`,
       `ustock`.`st_salesout`.`iprewarehouse`       AS `iprewarehouse`,
       `ustock`.`st_salesout`.`iShopID`             AS `iShopID`,
       `ustock`.`st_salesout`.`account_org`         AS `account_org`,
       `ustock`.`st_salesout`.`total_pieces`        AS `total_pieces`,
       `ustock`.`st_salesout`.`creatorId`           AS `creatorId`,
       `ustock`.`st_salesout`.`modifierId`          AS `modifierId`,
       `ustock`.`st_salesout`.`auditorId`           AS `auditorId`,
       `ustock`.`st_salesout`.`invoice_org`         AS `invoice_org`,
       `ustock`.`st_salesout`.`invoice_cust`        AS `invoice_cust`,
       `ustock`.`st_salesout`.`printCount`          AS `printCount`,
       `ustock`.`st_salesout`.`cReceiver`           AS `cReceiver`,
       `ustock`.`st_salesout`.`cReceiveMobile`      AS `cReceiveMobile`,
       `ustock`.`st_salesout`.`cReceiveAddress`     AS `cReceiveAddress`,
       `ustock`.`st_salesout`.`cReceiveZipCode`     AS `cReceiveZipCode`,
       `ustock`.`st_salesout`.`cReceiveTelePhone`   AS `cReceiveTelePhone`,
       `ustock`.`st_salesout`.`iLogisticId`         AS `iLogisticId`,
       `ustock`.`st_salesout`.`cLogisticsBillNo`    AS `cLogisticsBillNo`,
       `ustock`.`st_salesout`.`cLogisticsCarNum`    AS `cLogisticsCarNum`,
       `ustock`.`st_salesout`.`cLogisticsUserName`  AS `cLogisticsUserName`,
       `ustock`.`st_salesout`.`cLogisticsUserPhone` AS `cLogisticsUserPhone`,
       `ustock`.`st_salesout`.`iStoreID`            AS `iStoreID`,
       `ustock`.`st_salesout`.`isalesorg`           AS `isalesorg`,
       `ustock`.`st_salesout`.`contact_id`          AS `contact_id`,
       1                                            AS `main_id`
from `ustock`.`st_salesout`;

-- comment on column v_bom.istockdirection not supported: 库存方向

-- comment on column v_bom.iOrgid not supported: 库存组织

-- comment on column v_bom.imerchant not supported: 商家

-- comment on column v_bom.stock_mgr not supported: 库管员

-- comment on column v_bom.iwarehouse not supported: 仓库

-- comment on column v_bom.cmemo not supported: 备注

-- comment on column v_bom.csrcbillid not supported: 来源单据

-- comment on column v_bom.csrcbillno not supported: 来源单据号

-- comment on column v_bom.csrcbilltype not supported: 来源类型

-- comment on column v_bom.vouchdate not supported: 单据日期

-- comment on column v_bom.tplid not supported: 模板id

-- comment on column v_bom.status not supported: 单据状态

-- comment on column v_bom.id not supported: ID

-- comment on column v_bom.pubts not supported: 时间戳

-- comment on column v_bom.create_time not supported: 创建时间

-- comment on column v_bom.create_date not supported: 创建日期

-- comment on column v_bom.modify_time not supported: 修改时间

-- comment on column v_bom.modify_date not supported: 修改日期

-- comment on column v_bom.creator not supported: 创建人

-- comment on column v_bom.modifier not supported: 修改人

-- comment on column v_bom.tenant_id not supported: 租户

-- comment on column v_bom.auditor not supported: 审批人

-- comment on column v_bom.audit_time not supported: 审批时间

-- comment on column v_bom.audit_date not supported: 审批日期

-- comment on column v_bom.iCustID not supported: 客户ID

-- comment on column v_bom.fTotalQuantity not supported: 整单数量

-- comment on column v_bom.iprewarehouse not supported: 订单预占仓库

-- comment on column v_bom.iShopID not supported: 商家

-- comment on column v_bom.account_org not supported: 会计主体

-- comment on column v_bom.total_pieces not supported: 整单件数

-- comment on column v_bom.creatorId not supported: 创建人

-- comment on column v_bom.modifierId not supported: 修改人

-- comment on column v_bom.auditorId not supported: 审批人

-- comment on column v_bom.invoice_org not supported: 开票组织

-- comment on column v_bom.invoice_cust not supported: 收票客户

-- comment on column v_bom.printCount not supported: 打印次数

-- comment on column v_bom.cReceiveZipCode not supported: 收货人邮编

-- comment on column v_bom.iLogisticId not supported: 物流公司

-- comment on column v_bom.cLogisticsBillNo not supported: 物流单号

-- comment on column v_bom.cLogisticsCarNum not supported: 物流车辆牌照

-- comment on column v_bom.cLogisticsUserName not supported: 物流送货人姓名

-- comment on column v_bom.cLogisticsUserPhone not supported: 物流送货人电话

-- comment on column v_bom.iStoreID not supported: 门店

-- comment on column v_bom.isalesorg not supported: 销售组织

-- comment on column v_bom.contact_id not supported: 销售组织

