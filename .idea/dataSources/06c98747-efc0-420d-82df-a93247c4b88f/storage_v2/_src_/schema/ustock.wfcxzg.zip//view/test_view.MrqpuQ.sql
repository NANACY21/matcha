create definer = yonyou@`%` view test_view as
(
select `a`.`id`                                                          AS `id`,
       `a`.`billtype_id`                                                 AS `receipttype_id`,
       `a`.`default`                                                     AS `isDefault`,
       abs((`a`.`enable` - 1))                                           AS `stopstatus`,
       `a`.`memo`                                                        AS `memo`,
       `b`.`id`                                                          AS `tenant_id`,
       `a`.`pubts`                                                       AS `pubts`,
       `a`.`code`                                                        AS `code`,
       `a`.`name`                                                        AS `name`,
       (case when (`c`.`name` = 'otherInType') then `c`.`value` end)     AS `otherInType`,
       (case when (`c`.`name` = 'otherOutType') then `c`.`value` end)    AS `otherOutType`,
       NULL                                                              AS `erpcode`,
       NULL                                                              AS `saletype`,
       NULL                                                              AS `isPreCalcBalance`,
       NULL                                                              AS `isDistribCenter`,
       NULL                                                              AS `isUpdItemBySend`,
       NULL                                                              AS `MinPercentGiveMoneyPre`,
       NULL                                                              AS `isSaveAndAudit`,
       0                                                                 AS `isSystem`,
       NULL                                                              AS `create_time`,
       NULL                                                              AS `create_date`,
       NULL                                                              AS `modify_time`,
       NULL                                                              AS `modify_date`,
       NULL                                                              AS `creator`,
       NULL                                                              AS `modifier`,
       NULL                                                              AS `stop_time`,
       (case when (`c`.`name` = 'checkType') then `c`.`value` end)       AS `checkType`,
       NULL                                                              AS `bPurchaseAmountSend`,
       NULL                                                              AS `storeType`,
       NULL                                                              AS `allocateModel`,
       (case when (`c`.`name` = 'storeOutType') then `c`.`value` end)    AS `storeOutType`,
       (case when (`c`.`name` = 'storeInType') then `c`.`value` end)     AS `storeInType`,
       NULL                                                              AS `gatheringType`,
       NULL                                                              AS `noticemodel`,
       NULL                                                              AS `requireItemModel`,
       (case when (`c`.`name` = 'materialOutType') then `c`.`value` end) AS `materialOutType`,
       (case when (`c`.`name` = 'stockCType') then `c`.`value` end)      AS `stockCType`,
       NULL                                                              AS `procurement_id`,
       NULL                                                              AS `salesOutType`,
       NULL                                                              AS `madeType`,
       NULL                                                              AS `controlType`,
       (case when (`c`.`name` = 'mcType') then `c`.`value` end)          AS `mcType`
from ((`iuap_cloud_basedoc`.`bd_transtype` `a` join `ustock`.`tenant` `b` on ((`a`.`tenantid` = `b`.`tenantcenter_id`)))
         left join (select `iuap_cloud_basedoc`.`bd_transtype_extend_attrs`.`bd_transtype_id` AS `bd_transtype_id`,
                           `iuap_cloud_basedoc`.`bd_transtype_extend_attrs`.`name`            AS `name`,
                           `iuap_cloud_basedoc`.`bd_transtype_extend_attrs`.`value`           AS `value`,
                           `iuap_cloud_basedoc`.`bd_transtype_extend_attrs`.`tenantid`        AS `tenantid`
                    from `iuap_cloud_basedoc`.`bd_transtype_extend_attrs`
                    where (`iuap_cloud_basedoc`.`bd_transtype_extend_attrs`.`name` in
                           ('otherOutType', 'otherInType', 'checkType', 'storeOutType', 'storeInType',
                            'materialOutType', 'stockCType', 'mcType'))) `c`
                   on (((convert(`a`.`id` using utf8mb4) = convert(`c`.`bd_transtype_id` using utf8mb4)) and
                        (convert(`a`.`tenantid` using utf8mb4) = convert(`c`.`tenantid` using utf8mb4)))))
where ((`a`.`sysid` in ('SCMST', 'SCMPU')) and (`a`.`tenantid` <> 'global')));

-- comment on column test_view.id not supported: ID

-- comment on column test_view.isDefault not supported: 是否默认交易类型

-- comment on column test_view.memo not supported: 备注

-- comment on column test_view.tenant_id not supported: ID

-- comment on column test_view.pubts not supported: 旧时间戳

-- comment on column test_view.code not supported: 编码

-- comment on column test_view.name not supported: 名称

