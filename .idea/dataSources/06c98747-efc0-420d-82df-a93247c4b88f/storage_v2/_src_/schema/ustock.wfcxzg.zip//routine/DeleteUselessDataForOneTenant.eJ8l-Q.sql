create
    definer = lihk@`%` procedure DeleteUselessDataForOneTenant(IN cBillNo varchar(50))
BEGIN
	set @cBillNo = cBillNo;
	set @tenant_id= 1452977542353152; -- test环境
	-- set @tenant_id= 1527990873936128; -- daily环境

-- 基础配置 4
delete billentity_base from billentity_base inner join bill_base on billentity_base.iBillId=bill_base.id 
where bill_base.cBillNo=@cBillNo  and bill_base.tenant_id=@tenant_id  ;

delete billtemplate_base from billtemplate_base inner join bill_base on billtemplate_base.iBillId=bill_base.id 
where bill_base.cBillNo=@cBillNo  and bill_base.tenant_id=@tenant_id ;

delete billtplgroup_base from billtplgroup_base inner join bill_base on billtplgroup_base.iBillId=bill_base.id 
where bill_base.cBillNo=@cBillNo  and bill_base.tenant_id=@tenant_id ;

delete billitem_base from billitem_base inner JOIN bill_base on billitem_base.iBillId=bill_base.id 
where bill_base.cBillNo=@cBillNo and bill_base.tenant_id=@tenant_id;

-- 过滤项  2
delete pb_filter_solution_common from pb_filter_solution_common  inner join pb_filter_solution on pb_filter_solution_common.solutionId = pb_filter_solution.id  inner join bill_base on pb_filter_solution.filtersId=bill_base.cFilterId  
where bill_base.cBillNo=@cBillNo  and bill_base.tenant_id=@tenant_id ;
delete pb_filter_solution from pb_filter_solution  inner join bill_base on pb_filter_solution.filtersId=bill_base.cFilterId 
where bill_base.cBillNo=@cBillNo  and bill_base.tenant_id=@tenant_id;

--  按钮与命令 3
delete from bill_toolbar where billnumber=@cBillNo and tenant_id=@tenant_id ;
delete from bill_toolbaritem where billnumber=@cBillNo and tenant_id=@tenant_id ;
delete from bill_command where billnumber=@cBillNo and tenant_id=@tenant_id ;

-- 按钮配置 3 
delete from bill_status where billnumber=@cBillNo and tenant_id=@tenant_id ;
delete from bill_status_config where billnumber=@cBillNo and tenant_id=@tenant_id ;
delete from bill_status_profile where billnumber=@cBillNo and tenant_id=@tenant_id ;

-- 自定义字段公式 3
delete from bill_itemrule where billnumber=@cBillNo and tenant_id=@tenant_id ;
delete from bill_itemrule where billnumber=@cBillNo and tenant_id=@tenant_id ;
delete from bill_itemrule_script where billnumber=@cBillNo and tenant_id=@tenant_id ;

-- 最后清楚 bill_base 1
delete from bill_base where cBillNo=@cBillNo and tenant_id=@tenant_id and @tenant_id!=0;

END;

