create definer = yonyou@`%` view v_main_bom as
select 1 AS `id`;

