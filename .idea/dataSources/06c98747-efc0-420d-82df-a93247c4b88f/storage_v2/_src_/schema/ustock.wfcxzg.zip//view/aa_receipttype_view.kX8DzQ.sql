create definer = root@`%` view aa_receipttype_view as
(select NULL            AS `memo`,
        `a`.`parent_id` AS `parent_id`,
        `a`.`level`     AS `level`,
        `a`.`path`      AS `path`,
        `a`.`sort_num`  AS `sort_num`,
        `a`.`isEnd`     AS `isEnd`,
        `a`.`code`      AS `code`,
        `a`.`name`      AS `name`,
        `b`.`id`        AS `tenant_id`,
        `a`.`id`        AS `id`,
        `a`.`ts`        AS `pubts`,
        '0'             AS `isu8c`
 from (`iuap_cloud_basedoc`.`bd_billtype` `a`
          left join `ustock`.`tenant` `b` on ((`a`.`tenantid` = `b`.`tenantcenter_id`)))
 where ((`a`.`sysid` in ('ST', 'PU')) and (`a`.`tenantid` <> 'global')))
union
(select `ustock`.`aa_receipttype`.`memo`      AS `memo`,
        `ustock`.`aa_receipttype`.`parent_id` AS `parent_id`,
        `ustock`.`aa_receipttype`.`level`     AS `level`,
        `ustock`.`aa_receipttype`.`path`      AS `path`,
        `ustock`.`aa_receipttype`.`sort_num`  AS `sort_num`,
        `ustock`.`aa_receipttype`.`isEnd`     AS `isEnd`,
        `ustock`.`aa_receipttype`.`code`      AS `code`,
        `ustock`.`aa_receipttype`.`name`      AS `name`,
        `ustock`.`aa_receipttype`.`tenant_id` AS `tenant_id`,
        `ustock`.`aa_receipttype`.`id`        AS `id`,
        `ustock`.`aa_receipttype`.`pubts`     AS `pubts`,
        '1'                                   AS `isu8c`
 from `ustock`.`aa_receipttype`);

