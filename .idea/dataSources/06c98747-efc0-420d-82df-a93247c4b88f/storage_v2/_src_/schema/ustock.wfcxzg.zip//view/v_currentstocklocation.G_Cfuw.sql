create definer = yonyou@`%` view v_currentstocklocation as
select `a`.`iWarehouseId`  AS `iWarehouseId`,
       `a`.`ilocationid`   AS `ilocationid`,
       `a`.`fCurrentQty`   AS `fCurrentQty`,
       `a`.`fAvailableQty` AS `fAvailableQty`,
       `a`.`fInnoticeQty`  AS `fInnoticeQty`,
       `a`.`fOutnoticeQty` AS `fOutnoticeQty`,
       `a`.`fPreretailQty` AS `fPreretailQty`,
       `a`.`iUnitId`       AS `iUnitId`,
       `a`.`tenant_id`     AS `tenant_id`,
       `a`.`free1`         AS `free1`,
       `a`.`free2`         AS `free2`,
       `a`.`free3`         AS `free3`,
       `a`.`free4`         AS `free4`,
       `a`.`free5`         AS `free5`,
       `a`.`free6`         AS `free6`,
       `a`.`free7`         AS `free7`,
       `a`.`free8`         AS `free8`,
       `a`.`free9`         AS `free9`,
       `a`.`free10`        AS `free10`,
       `a`.`iStoreID`      AS `iStoreID`,
       `a`.`iProductid`    AS `iProductid`,
       `a`.`iProductSkuid` AS `iProductSkuid`,
       `a`.`sBatchNo`      AS `sBatchNo`,
       `a`.`dProduceDate`  AS `dProduceDate`,
       `a`.`dInvalidDate`  AS `dInvalidDate`,
       `a`.`id`            AS `id`,
       `a`.`pubts`         AS `pubts`,
       `b`.`id`            AS `batchnoid`
from (`ustock`.`currentstocklocation` `a`
         left join `ustock`.`batchno` `b`
                   on (((`a`.`iProductSkuid` = `b`.`iProductSkuid`) and (`a`.`sBatchNo` = `b`.`sBatchNo`))));

-- comment on column v_currentstocklocation.iWarehouseId not supported: 仓库

-- comment on column v_currentstocklocation.ilocationid not supported: 货位

-- comment on column v_currentstocklocation.fCurrentQty not supported: 现存数量

-- comment on column v_currentstocklocation.fAvailableQty not supported: 可用数量

-- comment on column v_currentstocklocation.fInnoticeQty not supported: 入库通知数量

-- comment on column v_currentstocklocation.fOutnoticeQty not supported: 出库通知数量

-- comment on column v_currentstocklocation.fPreretailQty not supported: 预订零售数量

-- comment on column v_currentstocklocation.iUnitId not supported: 销售单位id

-- comment on column v_currentstocklocation.tenant_id not supported: 租户

-- comment on column v_currentstocklocation.free1 not supported: 自由项1

-- comment on column v_currentstocklocation.free2 not supported: 自由项2

-- comment on column v_currentstocklocation.free3 not supported: 自由项3

-- comment on column v_currentstocklocation.free4 not supported: 自由项4

-- comment on column v_currentstocklocation.free5 not supported: 自由项5

-- comment on column v_currentstocklocation.free6 not supported: 自由项6

-- comment on column v_currentstocklocation.free7 not supported: 自由项7

-- comment on column v_currentstocklocation.free8 not supported: 自由项8

-- comment on column v_currentstocklocation.free9 not supported: 自由项9

-- comment on column v_currentstocklocation.free10 not supported: 自由项10

-- comment on column v_currentstocklocation.iStoreID not supported: 门店ID

-- comment on column v_currentstocklocation.iProductid not supported: 商品

-- comment on column v_currentstocklocation.iProductSkuid not supported: 商品skuid

-- comment on column v_currentstocklocation.sBatchNo not supported: 批次号

-- comment on column v_currentstocklocation.dProduceDate not supported: 生产日期

-- comment on column v_currentstocklocation.dInvalidDate not supported: 失效日期

-- comment on column v_currentstocklocation.id not supported: ID

-- comment on column v_currentstocklocation.pubts not supported: 时间戳

-- comment on column v_currentstocklocation.batchnoid not supported: ID

