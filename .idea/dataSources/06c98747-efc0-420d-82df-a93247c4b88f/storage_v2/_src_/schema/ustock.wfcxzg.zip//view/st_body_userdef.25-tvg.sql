create definer = yonyou@`%` view st_body_userdef as
select `t`.`id`       AS `id`,
       `t`.`define1`  AS `define1`,
       `t`.`define2`  AS `define2`,
       `t`.`define3`  AS `define3`,
       `t`.`define4`  AS `define4`,
       `t`.`define5`  AS `define5`,
       `t`.`define6`  AS `define6`,
       `t`.`define7`  AS `define7`,
       `t`.`define8`  AS `define8`,
       `t`.`define9`  AS `define9`,
       `t`.`define10` AS `define10`,
       `t`.`define11` AS `define11`,
       `t`.`define12` AS `define12`,
       `t`.`define13` AS `define13`,
       `t`.`define14` AS `define14`,
       `t`.`define15` AS `define15`,
       `t`.`define16` AS `define16`,
       `t`.`define17` AS `define17`,
       `t`.`define18` AS `define18`,
       `t`.`define19` AS `define19`,
       `t`.`define20` AS `define20`,
       `t`.`define21` AS `define21`,
       `t`.`define22` AS `define22`,
       `t`.`define23` AS `define23`,
       `t`.`define24` AS `define24`,
       `t`.`define25` AS `define25`,
       `t`.`define26` AS `define26`,
       `t`.`define27` AS `define27`,
       `t`.`define28` AS `define28`,
       `t`.`define29` AS `define29`,
       `t`.`define30` AS `define30`,
       `t`.`define31` AS `define31`,
       `t`.`define32` AS `define32`,
       `t`.`define33` AS `define33`,
       `t`.`define34` AS `define34`,
       `t`.`define35` AS `define35`,
       `t`.`define36` AS `define36`,
       `t`.`define37` AS `define37`,
       `t`.`define38` AS `define38`,
       `t`.`define39` AS `define39`,
       `t`.`define40` AS `define40`,
       `t`.`define41` AS `define41`,
       `t`.`define42` AS `define42`,
       `t`.`define43` AS `define43`,
       `t`.`define44` AS `define44`,
       `t`.`define45` AS `define45`,
       `t`.`define46` AS `define46`,
       `t`.`define47` AS `define47`,
       `t`.`define48` AS `define48`,
       `t`.`define49` AS `define49`,
       `t`.`define50` AS `define50`,
       `t`.`define51` AS `define51`,
       `t`.`define52` AS `define52`,
       `t`.`define53` AS `define53`,
       `t`.`define54` AS `define54`,
       `t`.`define55` AS `define55`,
       `t`.`define56` AS `define56`,
       `t`.`define57` AS `define57`,
       `t`.`define58` AS `define58`,
       `t`.`define59` AS `define59`,
       `t`.`define60` AS `define60`,
       NULL           AS `cBillNo`
from `ustock`.`st_othinrecords_customitem` `t`
where (1 = 2);

-- comment on column st_body_userdef.id not supported: 其他入库单子表id

-- comment on column st_body_userdef.define1 not supported: 自定义项1

-- comment on column st_body_userdef.define2 not supported: 自定义项2

-- comment on column st_body_userdef.define3 not supported: 自定义项3

-- comment on column st_body_userdef.define4 not supported: 自定义项4

-- comment on column st_body_userdef.define5 not supported: 自定义项5

-- comment on column st_body_userdef.define6 not supported: 自定义项6

-- comment on column st_body_userdef.define7 not supported: 自定义项7

-- comment on column st_body_userdef.define8 not supported: 自定义项8

-- comment on column st_body_userdef.define9 not supported: 自定义项9

-- comment on column st_body_userdef.define10 not supported: 自定义项10

-- comment on column st_body_userdef.define11 not supported: 自定义项11

-- comment on column st_body_userdef.define12 not supported: 自定义项12

-- comment on column st_body_userdef.define13 not supported: 自定义项13

-- comment on column st_body_userdef.define14 not supported: 自定义项14

-- comment on column st_body_userdef.define15 not supported: 自定义项15

-- comment on column st_body_userdef.define16 not supported: 自定义项16

-- comment on column st_body_userdef.define17 not supported: 自定义项17

-- comment on column st_body_userdef.define18 not supported: 自定义项18

-- comment on column st_body_userdef.define19 not supported: 自定义项19

-- comment on column st_body_userdef.define20 not supported: 自定义项20

-- comment on column st_body_userdef.define21 not supported: 自定义项21

-- comment on column st_body_userdef.define22 not supported: 自定义项22

-- comment on column st_body_userdef.define23 not supported: 自定义项23

-- comment on column st_body_userdef.define24 not supported: 自定义项24

-- comment on column st_body_userdef.define25 not supported: 自定义项25

-- comment on column st_body_userdef.define26 not supported: 自定义项26

-- comment on column st_body_userdef.define27 not supported: 自定义项27

-- comment on column st_body_userdef.define28 not supported: 自定义项28

-- comment on column st_body_userdef.define29 not supported: 自定义项29

-- comment on column st_body_userdef.define30 not supported: 自定义项30

-- comment on column st_body_userdef.define31 not supported: 自定义项31

-- comment on column st_body_userdef.define32 not supported: 自定义项32

-- comment on column st_body_userdef.define33 not supported: 自定义项33

-- comment on column st_body_userdef.define34 not supported: 自定义项34

-- comment on column st_body_userdef.define35 not supported: 自定义项35

-- comment on column st_body_userdef.define36 not supported: 自定义项36

-- comment on column st_body_userdef.define37 not supported: 自定义项37

-- comment on column st_body_userdef.define38 not supported: 自定义项38

-- comment on column st_body_userdef.define39 not supported: 自定义项39

-- comment on column st_body_userdef.define40 not supported: 自定义项40

-- comment on column st_body_userdef.define41 not supported: 自定义项41

-- comment on column st_body_userdef.define42 not supported: 自定义项42

-- comment on column st_body_userdef.define43 not supported: 自定义项43

-- comment on column st_body_userdef.define44 not supported: 自定义项44

-- comment on column st_body_userdef.define45 not supported: 自定义项45

-- comment on column st_body_userdef.define46 not supported: 自定义项46

-- comment on column st_body_userdef.define47 not supported: 自定义项47

-- comment on column st_body_userdef.define48 not supported: 自定义项48

-- comment on column st_body_userdef.define49 not supported: 自定义项49

-- comment on column st_body_userdef.define50 not supported: 自定义项50

-- comment on column st_body_userdef.define51 not supported: 自定义项51

-- comment on column st_body_userdef.define52 not supported: 自定义项52

-- comment on column st_body_userdef.define53 not supported: 自定义项53

-- comment on column st_body_userdef.define54 not supported: 自定义项54

-- comment on column st_body_userdef.define55 not supported: 自定义项55

-- comment on column st_body_userdef.define56 not supported: 自定义项56

-- comment on column st_body_userdef.define57 not supported: 自定义项57

-- comment on column st_body_userdef.define58 not supported: 自定义项58

-- comment on column st_body_userdef.define59 not supported: 自定义项59

-- comment on column st_body_userdef.define60 not supported: 自定义项60

