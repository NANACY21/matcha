create
    definer = dtssyncwriter@`%` procedure p_aa_updatecolumn(IN tablename varchar(50), IN columnname varchar(50),
                                                            IN executeStr varchar(1000), IN executeType varchar(50))
BEGIN
	DECLARE  CurrentDatabase VARCHAR(100);
	SELECT DATABASE() INTO CurrentDatabase;
	SET @tablename = tablename;
	SET @columnname = columnname;
	SET @executeType = executeType;
	SET @executeStr = executeStr;
	SET @count = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE table_schema=CurrentDatabase AND TABLE_NAME=@tablename AND COLUMN_NAME=@columnname);
	IF @executeType	= 'add' AND @count = 0 THEN 
		PREPARE stmt1 FROM @executeStr;
		EXECUTE stmt1;
	ELSEIF @executeType	= 'alter' AND @count >0 THEN  
		PREPARE stmt1 FROM @executeStr;
		EXECUTE stmt1;
	END IF;
END;

