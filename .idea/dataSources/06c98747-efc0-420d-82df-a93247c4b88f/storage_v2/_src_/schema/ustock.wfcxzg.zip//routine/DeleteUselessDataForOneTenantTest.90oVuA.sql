create
    definer = lihk@`%` procedure DeleteUselessDataForOneTenantTest()
BEGIN
	DECLARE cbillno varchar(50);
  DECLARE done INT DEFAULT FALSE;

  DECLARE cur CURSOR FOR select cbillno from billnotemp1;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

  -- 打开游标
  OPEN cur;
  -- 开始循环
  read_loop: LOOP
        -- 提取游标里的数据
        FETCH cur INTO cbillno;
        -- 声明结束的时候

				-- 如果select为空，跳出循环
--         IF done THEN
--             LEAVE read_loop;
--         END IF;
        call DeleteUselessDataForOneTenant(cbillno);
 END LOOP;
CLOSE cur;

END;

