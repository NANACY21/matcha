create definer = yonyou@`%` view v_aa_optionalattr_item as
select `t1`.`parent_id` AS `parent_id`, group_concat(`t1`.`attrValueName` separator ',') AS `attrValueName`
from `ustock`.`aa_optionalattr_item` `t1`
group by `t1`.`parent_id`;

-- comment on column v_aa_optionalattr_item.parent_id not supported: 主表主键

