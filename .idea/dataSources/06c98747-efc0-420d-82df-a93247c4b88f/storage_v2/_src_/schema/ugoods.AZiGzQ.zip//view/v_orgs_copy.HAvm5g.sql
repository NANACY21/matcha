create definer = yonyou@`%` view v_orgs_copy as
select `iuap_cloud_basedoc`.`org_orgs`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`org_orgs`.`name`                                   AS `cName`,
       `iuap_cloud_basedoc`.`org_orgs`.`name`                                   AS `cFullName`,
       1                                                                        AS `iLevel`,
       concat(`iuap_cloud_basedoc`.`org_orgs`.`id`, '|')                        AS `cPath`,
       `iuap_cloud_basedoc`.`org_orgs`.`displayorder`                           AS `iSortNum`,
       0                                                                        AS `bIsEnd`,
       NULL                                                                     AS `cOrgFuncId`,
       0                                                                        AS `bIsGlobal`,
       NULL                                                                     AS `cErpCode`,
       NULL                                                                     AS `cEaiCode`,
       (case
            when ((('' = `iuap_cloud_basedoc`.`org_orgs`.`parentid`) or
                   isnull(`iuap_cloud_basedoc`.`org_orgs`.`parentid`)) and
                  (`iuap_cloud_basedoc`.`org_orgs`.`id` <> '666666')) then '666666'
            when ('' = `iuap_cloud_basedoc`.`org_orgs`.`parentid`) then NULL
            else `iuap_cloud_basedoc`.`org_orgs`.`parentid` end)                AS `iparentId`,
       (case `iuap_cloud_basedoc`.`org_orgs`.`enable` when 1 then 0 else 1 end) AS `bStopStatus`,
       NULL                                                                     AS `dStopTime`,
       `iuap_cloud_basedoc`.`org_orgs`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_orgs`.`creationtime`                           AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifiedtime`                           AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifiedtime`                           AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_orgs`.`creator`                                AS `cCreator`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifier`                               AS `cModifier`,
       NULL                                                                     AS `creatorId`,
       NULL                                                                     AS `modifierId`,
       `iuap_cloud_basedoc`.`org_orgs`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_orgs`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                   AS `tenant_id`,
       NULL                                                                     AS `customerId`,
       NULL                                                                     AS `orgtypeid`,
       `iuap_cloud_basedoc`.`org_orgs`.`principal`                              AS `principal`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`org_orgs`
              on ((`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where ((`iuap_cloud_basedoc`.`org_orgs`.`dr` = 0) and (`iuap_cloud_basedoc`.`org_orgs`.`is_biz_unit` = 1) and
       (`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`));

