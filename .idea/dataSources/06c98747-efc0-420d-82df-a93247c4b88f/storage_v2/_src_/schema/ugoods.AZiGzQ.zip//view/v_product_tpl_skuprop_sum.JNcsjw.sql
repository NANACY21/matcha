create definer = yonyou@`%` view v_product_tpl_skuprop_sum as
select `prop`.`tpl_id`            AS `tpl_id`,
       `prop`.`propertyType`      AS `propertyType`,
       `prop`.`propertyAlias`     AS `propertyAlias`,
       `prop`.`isArchiveRequired` AS `isArchiveRequired`,
       `prop`.`id`                AS `id`,
       `prop`.`pubts`             AS `pubts`,
       `prop`.`iDeleted`          AS `isDeleted`,
       `prop`.`ordernumber`       AS `ordernumber`,
       `vals`.`values`            AS `values`
from (`ugoods`.`product_tpl_skuprop` `prop`
         left join `ugoods`.`v_product_tpl_skuprop_valsum` `vals` on ((`prop`.`id` = `vals`.`id`)));

-- comment on column v_product_tpl_skuprop_sum.tpl_id not supported: 商品模板

-- comment on column v_product_tpl_skuprop_sum.propertyType not supported: 属性名称

-- comment on column v_product_tpl_skuprop_sum.id not supported: ID

-- comment on column v_product_tpl_skuprop_sum.pubts not supported: 时间戳

-- comment on column v_product_tpl_skuprop_sum.isDeleted not supported: 逻辑删除标记

