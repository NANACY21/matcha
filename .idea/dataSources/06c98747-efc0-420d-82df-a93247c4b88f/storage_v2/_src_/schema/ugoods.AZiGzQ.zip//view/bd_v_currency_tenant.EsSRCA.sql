create definer = yonyou@`%` view bd_v_currency_tenant as
select `ugoods`.`bd_currency_tenant`.`id`           AS `id`,
       `ugoods`.`bd_currency_tenant`.`pricedigit`   AS `pricedigit`,
       `ugoods`.`bd_currency_tenant`.`moneydigit`   AS `moneydigit`,
       `ugoods`.`bd_currency_tenant`.`pricerount`   AS `pricerount`,
       `ugoods`.`bd_currency_tenant`.`moneyrount`   AS `moneyrount`,
       `ugoods`.`bd_currency_tenant`.`description`  AS `description`,
       `ugoods`.`bd_currency_tenant`.`isdefault`    AS `isdefault`,
       `ugoods`.`bd_currency_tenant`.`tenantid`     AS `tenantid`,
       `ugoods`.`bd_currency_tenant`.`sysid`        AS `sysid`,
       `ugoods`.`bd_currency_tenant`.`currtypesign` AS `currtypesign`,
       `ugoods`.`bd_currency_tenant`.`name`         AS `name`,
       `ugoods`.`bd_currency_tenant`.`code`         AS `code`,
       `ugoods`.`bd_currency_tenant`.`pubts`        AS `pubts`
from `ugoods`.`bd_currency_tenant`
where (`ugoods`.`bd_currency_tenant`.`tenantid` = 'a65xtqwz')
order by `ugoods`.`bd_currency_tenant`.`id`;

