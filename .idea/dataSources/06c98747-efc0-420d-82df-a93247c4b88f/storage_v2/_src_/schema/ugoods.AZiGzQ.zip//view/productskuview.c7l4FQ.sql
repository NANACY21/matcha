create definer = yonyou@`%` view productskuview as
select `a`.`productId`           AS `productId`,
       `a`.`code`                AS `code`,
       `a`.`name`                AS `name`,
       `a`.`name2`               AS `name2`,
       `a`.`name3`               AS `name3`,
       `a`.`name4`               AS `name4`,
       `a`.`name5`               AS `name5`,
       `a`.`name6`               AS `name6`,
       `a`.`isSKU`               AS `isSKU`,
       `a`.`free1`               AS `free1`,
       `a`.`free2`               AS `free2`,
       `a`.`free3`               AS `free3`,
       `a`.`free4`               AS `free4`,
       `a`.`free5`               AS `free5`,
       `a`.`free6`               AS `free6`,
       `a`.`free7`               AS `free7`,
       `a`.`free8`               AS `free8`,
       `a`.`free9`               AS `free9`,
       `a`.`free10`              AS `free10`,
       `a`.`cSpecIds`            AS `cSpecIds`,
       `a`.`cSpecs`              AS `cSpecs`,
       `a`.`nameList`            AS `nameList`,
       `a`.`specNames`           AS `specNames`,
       `a`.`id`                  AS `id`,
       `a`.`pubts`               AS `pubts`,
       `a`.`erpCode`             AS `erpCode`,
       `a`.`tenant_id`           AS `tenant_id`,
       `a`.`iDeleted`            AS `iDeleted`,
       `a`.`cModelDescription`   AS `cModelDescription`,
       `a`.`batchUnitId`         AS `batchUnitId`,
       `b`.`fSalePrice`          AS `fSalePrice`,
       `b`.`batchPrice`          AS `batchPrice`,
       `b`.`fMarkPrice`          AS `fMarkPrice`,
       `b`.`fMarketPrice`        AS `fMarketPrice`,
       `b`.`fPrimeCosts`         AS `fPrimeCosts`,
       `b`.`iStatus`             AS `iStatus`,
       `b`.`fSettleAccountsRate` AS `fSettleAccountsRate`,
       `b`.`cBarCode`            AS `cBarCode`,
       `b`.`lInventoryCount`     AS `lInventoryCount`,
       `b`.`weight`              AS `weight`,
       `b`.`salePoints`          AS `salePoints`,
       `b`.`iSaled`              AS `iSaled`,
       `b`.`batchRate`           AS `batchRate`,
       `b`.`iMinOrderQuantity`   AS `iMinOrderQuantity`,
       `b`.`batchDeliveryDays`   AS `batchDeliveryDays`,
       `b`.`fNoTaxCostPrice`     AS `fNoTaxCostPrice`,
       `b`.`shortName`           AS `shortName`,
       `b`.`stopstatus`          AS `stopstatus`,
       `b`.`stop_time`           AS `stop_time`
from (`ugoods`.`productsku` `a`
         join `ugoods`.`productskuextend` `b` on ((`a`.`id` = `b`.`skuId`)));

-- comment on column productskuview.productId not supported: 所属商品

-- comment on column productskuview.code not supported: SKU编码

-- comment on column productskuview.name not supported: SKU名称

-- comment on column productskuview.name2 not supported: 自定义SKU名称

-- comment on column productskuview.name3 not supported: 自定义SKU名称

-- comment on column productskuview.name4 not supported: 自定义SKU名称

-- comment on column productskuview.name5 not supported: 自定义SKU名称

-- comment on column productskuview.name6 not supported: 自定义SKU名称

-- comment on column productskuview.isSKU not supported: 是否SKU

-- comment on column productskuview.free1 not supported: 商品规格1

-- comment on column productskuview.free2 not supported: 商品规格2

-- comment on column productskuview.free3 not supported: 商品规格3

-- comment on column productskuview.free4 not supported: 商品规格4

-- comment on column productskuview.free5 not supported: 商品规格5

-- comment on column productskuview.free6 not supported: 商品规格6

-- comment on column productskuview.free7 not supported: 商品规格7

-- comment on column productskuview.free8 not supported: 商品规格8

-- comment on column productskuview.free9 not supported: 商品规格9

-- comment on column productskuview.free10 not supported: 商品规格10

-- comment on column productskuview.cSpecIds not supported: 规格ID

-- comment on column productskuview.cSpecs not supported: 规格值

-- comment on column productskuview.nameList not supported: 商品SKU多个标签组成的字符串

-- comment on column productskuview.specNames not supported: 五个动态规格与值

-- comment on column productskuview.id not supported: ID

-- comment on column productskuview.pubts not supported: 时间戳

-- comment on column productskuview.erpCode not supported: 商家编码

-- comment on column productskuview.tenant_id not supported: 租户

-- comment on column productskuview.iDeleted not supported: 逻辑删除标记

-- comment on column productskuview.cModelDescription not supported: 规格型号

-- comment on column productskuview.batchUnitId not supported: 包装单位

-- comment on column productskuview.iStatus not supported: 商城上下架状态

-- comment on column productskuview.fSettleAccountsRate not supported: 结算费率

-- comment on column productskuview.cBarCode not supported: SKU条形码

-- comment on column productskuview.lInventoryCount not supported: 库存

-- comment on column productskuview.weight not supported: 重量

-- comment on column productskuview.salePoints not supported: 积分数量

-- comment on column productskuview.batchRate not supported: 批发单位换算率

-- comment on column productskuview.iMinOrderQuantity not supported: 批发-起订量

-- comment on column productskuview.batchDeliveryDays not supported: 批发-交货周期（天）

-- comment on column productskuview.stopstatus not supported: 停用状态

-- comment on column productskuview.stop_time not supported: 停用时间

