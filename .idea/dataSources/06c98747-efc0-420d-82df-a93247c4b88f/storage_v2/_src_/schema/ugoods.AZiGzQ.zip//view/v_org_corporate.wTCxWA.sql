create definer = yonyou@`%` view v_org_corporate as
select `iuap_cloud_basedoc`.`org_corporate`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_corporate`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`org_corporate`.`name`                                   AS `cName`,
       `iuap_cloud_basedoc`.`org_corporate`.`name`                                   AS `cFullName`,
       `iuap_cloud_basedoc`.`org_corporate`.`displayorder`                           AS `iSortNum`,
       0                                                                             AS `bIsEnd`,
       NULL                                                                          AS `cOrgFuncId`,
       0                                                                             AS `bIsGlobal`,
       NULL                                                                          AS `cErpCode`,
       NULL                                                                          AS `cEaiCode`,
       (case `iuap_cloud_basedoc`.`org_corporate`.`enable` when 1 then 0 else 1 end) AS `bStopStatus`,
       NULL                                                                          AS `dStopTime`,
       `iuap_cloud_basedoc`.`org_corporate`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_corporate`.`creationtime`                           AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_corporate`.`modifiedtime`                           AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_corporate`.`modifiedtime`                           AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_corporate`.`creator`                                AS `cCreator`,
       `iuap_cloud_basedoc`.`org_corporate`.`modifier`                               AS `cModifier`,
       `iuap_cloud_basedoc`.`org_corporate`.`creator`                                AS `creatorId`,
       `iuap_cloud_basedoc`.`org_corporate`.`modifier`                               AS `modifierId`,
       `iuap_cloud_basedoc`.`org_corporate`.`orgid`                                  AS `orgid`,
       `iuap_cloud_basedoc`.`org_corporate`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                        AS `tenant_id`,
       NULL                                                                          AS `customerId`,
       `iuap_cloud_basedoc`.`org_corporate`.`parentid`                               AS `iparentId`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_corporate`
                   on ((`iuap_cloud_basedoc`.`org_corporate`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_corporate`.`dr` = 0);

