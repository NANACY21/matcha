create definer = yonyou@`%` view v_depttypes as
select `iuap_cloud_basedoc`.`org_dept_type`.`id`           AS `id`,
       `iuap_cloud_basedoc`.`org_dept_type`.`CODE`         AS `cCode`,
       `iuap_cloud_basedoc`.`org_dept_type`.`NAME`         AS `cName`,
       `ugoods`.`tenant`.`id`                              AS `tenant_id`,
       `iuap_cloud_basedoc`.`org_dept_type`.`sysid`        AS `sysid`,
       `iuap_cloud_basedoc`.`org_dept_type`.`ts`           AS `ts`,
       `iuap_cloud_basedoc`.`org_dept_type`.`pubts`        AS `pubts`,
       `iuap_cloud_basedoc`.`org_dept_type`.`dr`           AS `dr`,
       `iuap_cloud_basedoc`.`org_dept_type`.`enable`       AS `enable`,
       `iuap_cloud_basedoc`.`org_dept_type`.`creator`      AS `cCreator`,
       `iuap_cloud_basedoc`.`org_dept_type`.`creationtime` AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_dept_type`.`name2`        AS `name2`,
       `iuap_cloud_basedoc`.`org_dept_type`.`name3`        AS `name3`,
       `iuap_cloud_basedoc`.`org_dept_type`.`name4`        AS `name4`,
       `iuap_cloud_basedoc`.`org_dept_type`.`name5`        AS `name5`,
       `iuap_cloud_basedoc`.`org_dept_type`.`name6`        AS `name6`,
       `iuap_cloud_basedoc`.`org_dept_type`.`displayorder` AS `displayorder`,
       `iuap_cloud_basedoc`.`org_dept_type`.`memo`         AS `memo`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_dept_type`
                   on ((`iuap_cloud_basedoc`.`org_dept_type`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_dept_type`.`dr` = 0);

