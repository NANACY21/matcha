create definer = yonyou@`%` view v_org_purchase as
select `iuap_cloud_basedoc`.`org_purchase`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`org_purchase`.`name`                                   AS `cName`,
       `iuap_cloud_basedoc`.`org_purchase`.`name`                                   AS `cFullName`,
       `iuap_cloud_basedoc`.`org_purchase`.`displayorder`                           AS `iSortNum`,
       0                                                                            AS `bIsEnd`,
       NULL                                                                         AS `cOrgFuncId`,
       0                                                                            AS `bIsGlobal`,
       NULL                                                                         AS `cErpCode`,
       NULL                                                                         AS `cEaiCode`,
       `iuap_cloud_basedoc`.`org_purchase`.`parentid`                               AS `iparentId`,
       (case `iuap_cloud_basedoc`.`org_purchase`.`enable` when 1 then 0 else 1 end) AS `bStopStatus`,
       NULL                                                                         AS `dStopTime`,
       `iuap_cloud_basedoc`.`org_purchase`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_purchase`.`creationtime`                           AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_purchase`.`modifiedtime`                           AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_purchase`.`modifiedtime`                           AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_purchase`.`creator`                                AS `cCreator`,
       `iuap_cloud_basedoc`.`org_purchase`.`modifier`                               AS `cModifier`,
       `iuap_cloud_basedoc`.`org_purchase`.`creator`                                AS `creatorId`,
       `iuap_cloud_basedoc`.`org_purchase`.`modifier`                               AS `modifierId`,
       `iuap_cloud_basedoc`.`org_purchase`.`orgid`                                  AS `orgid`,
       `iuap_cloud_basedoc`.`org_purchase`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_purchase`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                       AS `tenant_id`,
       NULL                                                                         AS `customerId`,
       `iuap_cloud_basedoc`.`org_purchase`.`name2`                                  AS `cName2`,
       `iuap_cloud_basedoc`.`org_purchase`.`name3`                                  AS `cName3`,
       `iuap_cloud_basedoc`.`org_purchase`.`name4`                                  AS `cName4`,
       `iuap_cloud_basedoc`.`org_purchase`.`name5`                                  AS `cName5`,
       `iuap_cloud_basedoc`.`org_purchase`.`name6`                                  AS `cName6`,
       `iuap_cloud_basedoc`.`org_purchase`.`name2`                                  AS `cFullName2`,
       `iuap_cloud_basedoc`.`org_purchase`.`name3`                                  AS `cFullName3`,
       `iuap_cloud_basedoc`.`org_purchase`.`name4`                                  AS `cFullName4`,
       `iuap_cloud_basedoc`.`org_purchase`.`name5`                                  AS `cFullName5`,
       `iuap_cloud_basedoc`.`org_purchase`.`name6`                                  AS `cFullName6`,
       `iuap_cloud_basedoc`.`org_purchase`.`external_org`                           AS `external_org`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_purchase`
                   on ((`iuap_cloud_basedoc`.`org_purchase`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_purchase`.`dr` = 0);

-- comment on column v_org_purchase.iSortNum not supported: 显示顺序

-- comment on column v_org_purchase.iparentId not supported: 上级节点

-- comment on column v_org_purchase.dCreateTime not supported: 创建时间

-- comment on column v_org_purchase.dCreateDate not supported: 创建时间

-- comment on column v_org_purchase.dModifyTime not supported: 修改时间

-- comment on column v_org_purchase.dModifyDate not supported: 修改时间

-- comment on column v_org_purchase.cCreator not supported: 创建人

-- comment on column v_org_purchase.cModifier not supported: 修改人

-- comment on column v_org_purchase.creatorId not supported: 创建人

-- comment on column v_org_purchase.modifierId not supported: 修改人

-- comment on column v_org_purchase.orgid not supported: 组织单元主键

-- comment on column v_org_purchase.id not supported: 主键

-- comment on column v_org_purchase.pubts not supported: 公共时间戳

-- comment on column v_org_purchase.tenant_id not supported: ID

-- comment on column v_org_purchase.external_org not supported: 外部组织标识

