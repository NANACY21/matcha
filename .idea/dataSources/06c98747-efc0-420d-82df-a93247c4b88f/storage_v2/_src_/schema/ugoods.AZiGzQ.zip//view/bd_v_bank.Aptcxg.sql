create definer = yonyou@`%` view bd_v_bank as
select `ugoods`.`bd_bank`.`bank`         AS `bank`,
       `ugoods`.`bd_bank`.`creator`      AS `creator`,
       `ugoods`.`bd_bank`.`creationtime` AS `creationtime`,
       `ugoods`.`bd_bank`.`modifier`     AS `modifier`,
       `ugoods`.`bd_bank`.`modifiedtime` AS `modifiedtime`,
       `ugoods`.`bd_bank`.`id`           AS `id`,
       `ugoods`.`bd_bank`.`pubts`        AS `pubts`,
       `ugoods`.`bd_bank`.`code`         AS `code`,
       `ugoods`.`bd_bank`.`name`         AS `name`,
       `ugoods`.`bd_bank`.`sysid`        AS `sysid`,
       `ugoods`.`bd_bank`.`dr`           AS `dr`,
       `ugoods`.`bd_bank`.`tenantid`     AS `tenantid`
from `ugoods`.`bd_bank`
where (`ugoods`.`bd_bank`.`tenantid` = 'a65xtqwz')
order by `ugoods`.`bd_bank`.`code`;

-- comment on column bd_v_bank.bank not supported: 社会级银行类别

-- comment on column bd_v_bank.creator not supported: 创建人

-- comment on column bd_v_bank.creationtime not supported: 创建时间

-- comment on column bd_v_bank.modifier not supported: 修改人

-- comment on column bd_v_bank.modifiedtime not supported: 修改时间

-- comment on column bd_v_bank.id not supported: ID

-- comment on column bd_v_bank.pubts not supported: 时间戳

-- comment on column bd_v_bank.code not supported: 编码

-- comment on column bd_v_bank.name not supported: 名称

-- comment on column bd_v_bank.sysid not supported: 应用标识

-- comment on column bd_v_bank.dr not supported: 版本号

-- comment on column bd_v_bank.tenantid not supported: 租户

