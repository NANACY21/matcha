create definer = yonyou@`%` view v_product_tpl_spec_sum as
select max(`ugoods`.`product_tpl_spec`.`id`)               AS `id`,
       max(`ugoods`.`product_tpl_spec`.`pubts`)            AS `pubts`,
       min(`ugoods`.`product_tpl_spec`.`iOrder`)           AS `iOrder`,
       `ugoods`.`product_tpl_spec`.`tpl_id`                AS `tpl_id`,
       `ugoods`.`product_tpl_spec`.`spec_id`               AS `spec_id`,
       `ugoods`.`product_tpl_spec`.`spec_business_dynamic` AS `spec_business_dynamic`,
       `ugoods`.`product_tpl_spec`.`two_dimensional_input` AS `two_dimensional_input`,
       group_concat(`ugoods`.`product_tpl_spec`.`specitem_id` order by `ugoods`.`product_tpl_spec`.`iOrder` ASC
                    separator '; ')                        AS `specitem_id`,
       group_concat(if(isnull(`def`.`erp_name`), '', `def`.`erp_name`) order by `ugoods`.`product_tpl_spec`.`iOrder` ASC
                    separator '; ')                        AS `erp_name`
from (`ugoods`.`product_tpl_spec`
         left join `ugoods`.`userdefine` `def` on (((`ugoods`.`product_tpl_spec`.`spec_id` = `def`.`userdefid`) and
                                                    (`ugoods`.`product_tpl_spec`.`specitem_id` = `def`.`name`))))
group by `ugoods`.`product_tpl_spec`.`tpl_id`, `ugoods`.`product_tpl_spec`.`spec_id`;

