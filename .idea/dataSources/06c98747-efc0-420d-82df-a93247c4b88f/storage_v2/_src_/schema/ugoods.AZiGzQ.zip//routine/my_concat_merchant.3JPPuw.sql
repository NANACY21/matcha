create
    definer = chenhy@`%` function my_concat_merchant(c1 varchar(50), c2 varchar(50), c3 varchar(50), c4 varchar(50),
                                                     c5 varchar(50), c6 varchar(50),
                                                     c7 varchar(50)) returns varchar(5000)
begin
 declare result varchar(5000);
 set result='';
 if(c1 != '') then
  set result = concat(result , ' || ' , c1);
 end if;
 if(c2 != '')
 then
  set result = concat(result , ' || ' , c2);
 end if;
 if(c3 != '')
 then
  set result = concat(result , ' || ' , c3);
 end if;
  if(c4 != '')
 then
  set result = concat(result , ' || ' , c4);
 end if;
  if(c5 != '')
 then
  set result = concat(result , ' || ' , c5);
 end if;
  if(c6 != '')
 then
  set result = concat(result , ' || ' , c6);
 end if;
   if(c7 != '')
 then
  set result = concat(result , ' || ' , c7);
 end if;
return substring(result, 5);
end;

