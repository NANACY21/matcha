create definer = chenhy@`%` view productskulvpriceview as
select `a`.`productId`           AS `productId`,
       `a`.`productApplyRangeId` AS `productApplyRangeId`,
       `a`.`skuId`               AS `skuId`,
       `a`.`levelId`             AS `levelId`,
       `a`.`fLevelPrice`         AS `fLevelPrice`,
       `a`.`id`                  AS `id`,
       `a`.`pubts`               AS `pubts`,
       `a`.`tenant_id`           AS `tenant_id`,
       `b`.`iRangeType`          AS `iRangeType`,
       `b`.`orgId`               AS `orgId`,
       `b`.`customerId`          AS `customerId`,
       `b`.`shopId`              AS `shopId`
from (`ugoods`.`productapplyrange` `b`
         left join `ugoods`.`productskulvprice` `a` on ((`a`.`productApplyRangeId` = `b`.`id`)));

-- comment on column productskulvpriceview.skuId not supported: 商品SKUID

-- comment on column productskulvpriceview.levelId not supported: null

-- comment on column productskulvpriceview.fLevelPrice not supported: 会员价

-- comment on column productskulvpriceview.id not supported: ID

-- comment on column productskulvpriceview.pubts not supported: 时间戳

-- comment on column productskulvpriceview.tenant_id not supported: 租户

-- comment on column productskulvpriceview.iRangeType not supported: 商品适用范围类型

-- comment on column productskulvpriceview.customerId not supported: 客户ID

-- comment on column productskulvpriceview.shopId not supported: 商家ID

