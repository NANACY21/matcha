create definer = chenhy@`%` view productskulvpriceview as
select `a`.`productId`           AS `productId`,
       `a`.`productApplyRangeId` AS `productApplyRangeId`,
       `a`.`skuId`               AS `skuId`,
       `a`.`levelId`             AS `levelId`,
       `a`.`fLevelPrice`         AS `fLevelPrice`,
       `a`.`id`                  AS `id`,
       `a`.`pubts`               AS `pubts`,
       `a`.`tenant_id`           AS `tenant_id`,
       `b`.`iRangeType`          AS `iRangeType`,
       `b`.`orgId`               AS `orgId`,
       `b`.`customerId`          AS `customerId`,
       `b`.`shopId`              AS `shopId`
from (`ugoods`.`productapplyrange` `b`
         left join `ugoods`.`productskulvprice` `a` on ((`a`.`productApplyRangeId` = `b`.`id`)));

