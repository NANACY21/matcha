create definer = yonyou@`%` view v_org_fin as
select `iuap_cloud_basedoc`.`org_fin`.`code`                                                AS `cCode`,
       `iuap_cloud_basedoc`.`org_fin`.`name`                                                AS `cName`,
       `iuap_cloud_basedoc`.`org_fin`.`name`                                                AS `cFullName`,
       `iuap_cloud_basedoc`.`org_fin`.`displayorder`                                        AS `iSortNum`,
       0                                                                                    AS `bIsEnd`,
       NULL                                                                                 AS `cOrgFuncId`,
       0                                                                                    AS `bIsGlobal`,
       NULL                                                                                 AS `cErpCode`,
       NULL                                                                                 AS `cEaiCode`,
       (case `iuap_cloud_basedoc`.`org_fin`.`enable` when 1 then 0 else 1 end)              AS `bStopStatus`,
       NULL                                                                                 AS `dStopTime`,
       `iuap_cloud_basedoc`.`org_fin`.`creationtime`                                        AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_fin`.`creationtime`                                        AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_fin`.`modifiedtime`                                        AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_fin`.`modifiedtime`                                        AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_fin`.`creator`                                             AS `cCreator`,
       `iuap_cloud_basedoc`.`org_fin`.`modifier`                                            AS `cModifier`,
       `iuap_cloud_basedoc`.`org_fin`.`creator`                                             AS `creatorId`,
       `iuap_cloud_basedoc`.`org_fin`.`modifier`                                            AS `modifierId`,
       `iuap_cloud_basedoc`.`org_fin`.`id`                                                  AS `id`,
       `iuap_cloud_basedoc`.`org_fin`.`ts`                                                  AS `pubts`,
       `ugoods`.`tenant`.`id`                                                               AS `tenant_id`,
       NULL                                                                                 AS `customerId`,
       `iuap_cloud_basedoc`.`org_fin`.`taxpayerid`                                          AS `taxpayerid`,
       `iuap_cloud_basedoc`.`org_fin`.`currency`                                            AS `currency`,
       `iuap_cloud_basedoc`.`org_fin`.`statetaxregnum`                                      AS `statetaxregnum`,
       `iuap_cloud_basedoc`.`org_fin`.`localtaxregnum`                                      AS `localtaxregnum`,
       `iuap_cloud_basedoc`.`org_fin`.`accountingcalendar`                                  AS `accountingcalendar`,
       `iuap_cloud_basedoc`.`org_fin`.`region`                                              AS `region`,
       `iuap_cloud_basedoc`.`org_fin`.`orglevel`                                            AS `orglevel`,
       `iuap_cloud_basedoc`.`org_fin`.`orgid`                                               AS `orgid`,
       (case
            when (`iuap_cloud_basedoc`.`org_fin`.`parentid` = '') then NULL
            else `iuap_cloud_basedoc`.`org_fin`.`parentid` end)                             AS `iparentId`,
       NULL                                                                                 AS `parentorgid`,
       1                                                                                    AS `iLevel`,
       concat(`iuap_cloud_basedoc`.`org_fin`.`id`, '|')                                     AS `cPath`,
       NULL                                                                                 AS `orgTypeId`,
       `iuap_cloud_basedoc`.`bd_currency_tenant`.`code`                                     AS `currencyCode`,
       `iuap_cloud_basedoc`.`bd_currency_tenant`.`name`                                     AS `currencyName`,
       `iuap_cloud_basedoc`.`org_fin`.`principal`                                           AS `principal`,
       `iuap_cloud_basedoc`.`org_fin`.`periodschema`                                        AS `periodschema`,
       (case `iuap_cloud_basedoc`.`org_fin`.`taxpayertype` when 1 then 0 when 2 then 1 end) AS `iTaxPayingCate`,
       `iuap_cloud_basedoc`.`org_fin`.`exchangerate`                                        AS `exchangerate`,
       `iuap_cloud_basedoc`.`org_fin`.`name2`                                               AS `cName2`,
       `iuap_cloud_basedoc`.`org_fin`.`name3`                                               AS `cName3`,
       `iuap_cloud_basedoc`.`org_fin`.`name4`                                               AS `cName4`,
       `iuap_cloud_basedoc`.`org_fin`.`name5`                                               AS `cName5`,
       `iuap_cloud_basedoc`.`org_fin`.`name6`                                               AS `cName6`,
       `iuap_cloud_basedoc`.`org_fin`.`name2`                                               AS `cFullName2`,
       `iuap_cloud_basedoc`.`org_fin`.`name3`                                               AS `cFullName3`,
       `iuap_cloud_basedoc`.`org_fin`.`name4`                                               AS `cFullName4`,
       `iuap_cloud_basedoc`.`org_fin`.`name5`                                               AS `cFullName5`,
       `iuap_cloud_basedoc`.`org_fin`.`name6`                                               AS `cFullName6`,
       `iuap_cloud_basedoc`.`org_fin`.`external_org`                                        AS `external_org`
from ((`ugoods`.`tenant` left join `iuap_cloud_basedoc`.`org_fin` on ((`iuap_cloud_basedoc`.`org_fin`.`tenantid` =
                                                                       `ugoods`.`tenant`.`tenantcenter_id`)))
         left join `iuap_cloud_basedoc`.`bd_currency_tenant`
                   on (((convert(`iuap_cloud_basedoc`.`org_fin`.`currency` using utf8mb4) =
                         `iuap_cloud_basedoc`.`bd_currency_tenant`.`id`) and
                        (`iuap_cloud_basedoc`.`org_fin`.`tenantid` =
                         `iuap_cloud_basedoc`.`bd_currency_tenant`.`tenantid`))))
where (`iuap_cloud_basedoc`.`org_fin`.`dr` = 0);

