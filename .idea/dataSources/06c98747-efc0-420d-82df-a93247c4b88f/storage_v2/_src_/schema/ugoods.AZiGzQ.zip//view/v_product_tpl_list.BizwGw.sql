create definer = yonyou@`%` view v_product_tpl_list as
select `tpl`.`type_id`                                            AS `id`,
       group_concat(`ugoods`.`brand`.`brand_name` separator '; ') AS `brand_name`,
       `tpl`.`tenant_id`                                          AS `tenant_id`
from (`ugoods`.`producttpl_brand` `tpl`
         join `ugoods`.`brand`
              on (((`tpl`.`brand_id` = `ugoods`.`brand`.`id`) and (`tpl`.`tenant_id` = `ugoods`.`brand`.`tenant_id`))))
group by `tpl`.`tenant_id`, `tpl`.`type_id`;

