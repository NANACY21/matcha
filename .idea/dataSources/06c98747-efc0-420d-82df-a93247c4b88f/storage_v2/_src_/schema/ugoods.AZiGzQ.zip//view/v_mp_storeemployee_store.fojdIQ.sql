create definer = yonyou@`%` view v_mp_storeemployee_store as
select `a`.`operatorId` AS `operatorId`, group_concat(`b`.`cName` separator ',') AS `storeName`, `b`.`id` AS `iStoreId`
from (`ugoods`.`mp_storeemployee_store` `a`
         left join `ugoods`.`mp_store` `b` on ((`a`.`iStoreId` = `b`.`id`)))
group by `a`.`operatorId`;

