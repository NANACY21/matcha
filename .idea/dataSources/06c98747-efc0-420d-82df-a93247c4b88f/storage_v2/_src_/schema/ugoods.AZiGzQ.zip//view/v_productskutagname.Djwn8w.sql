create definer = yonyou@`%` view v_productskutagname as
select group_concat(`t`.`tag_Name` separator ' ') AS `nameList`, `st`.`skuId` AS `id`
from (`ugoods`.`skutag` `st`
         left join `ugoods`.`tag` `t` on ((`st`.`tagId` = `t`.`id`)))
group by `st`.`skuId`;

