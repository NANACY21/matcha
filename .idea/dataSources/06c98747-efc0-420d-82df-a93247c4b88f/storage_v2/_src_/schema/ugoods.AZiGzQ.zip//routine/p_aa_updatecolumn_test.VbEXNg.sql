create
    definer = yonyou@`%` procedure p_aa_updatecolumn_test(IN tablename varchar(50), IN columnname varchar(50),
                                                          IN executeStr varchar(1000), IN executeType varchar(50))
BEGIN
		DECLARE CurrentDatabase VARCHAR(100);
		SELECT DATABASE() INTO CurrentDatabase;
		SET @tablename = tablename;
		SET @columnname = columnname;
		SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE table_schema=CurrentDatabase AND TABLE_NAME=@tablename AND COLUMN_NAME=@columnname;
		SELECT CONCAT('SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE table_schema=''',CurrentDatabase,''' AND TABLE_NAME=''',@tablename,''' AND COLUMN_NAME=''',@columnname,''';') schema_sql;
	END;

