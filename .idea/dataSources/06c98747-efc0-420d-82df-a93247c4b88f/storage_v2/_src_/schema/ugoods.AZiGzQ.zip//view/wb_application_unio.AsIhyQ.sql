create definer = yonyou@`%` view wb_application_unio as
select `workbench`.`wb_application`.`application_id`   AS `id`,
       `ugoods`.`tenant`.`id`                          AS `tenant_id`,
       `workbench`.`wb_application`.`ts`               AS `pubts`,
       `workbench`.`wb_application`.`application_code` AS `systemCode`,
       `workbench`.`wb_application`.`application_icon` AS `systemLOGO`,
       `workbench`.`wb_application`.`application_name` AS `systemName`,
       (not (`workbench`.`wb_application`.`enable`))   AS `iDeleted`,
       `workbench`.`wb_application`.`orders`           AS `orderNumber`
from (`workbench`.`wb_application`
         left join `ugoods`.`tenant`
                   on ((`workbench`.`wb_application`.`tenant_id` = `ugoods`.`tenant`.`tenantcenter_id`)))
union all
select `ugoods`.`aa_regist_info`.`id`          AS `id`,
       `ugoods`.`aa_regist_info`.`tenant_id`   AS `tenant_id`,
       `ugoods`.`aa_regist_info`.`pubts`       AS `pubts`,
       `ugoods`.`aa_regist_info`.`systemCode`  AS `systemCode`,
       `ugoods`.`aa_regist_info`.`systemLOGO`  AS `systemLOGO`,
       `ugoods`.`aa_regist_info`.`systemName`  AS `systemName`,
       `ugoods`.`aa_regist_info`.`iDeleted`    AS `iDeleted`,
       `ugoods`.`aa_regist_info`.`orderNumber` AS `orderNumber`
from `ugoods`.`aa_regist_info`;

