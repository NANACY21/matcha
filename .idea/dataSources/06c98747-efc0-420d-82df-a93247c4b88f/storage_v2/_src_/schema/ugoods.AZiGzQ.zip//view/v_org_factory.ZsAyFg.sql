create definer = yonyou@`%` view v_org_factory as
select `iuap_cloud_basedoc`.`org_factory`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`org_factory`.`name`                                   AS `cName`,
       `iuap_cloud_basedoc`.`org_factory`.`name`                                   AS `cFullName`,
       `iuap_cloud_basedoc`.`org_factory`.`displayorder`                           AS `iSortNum`,
       0                                                                           AS `bIsEnd`,
       NULL                                                                        AS `cOrgFuncId`,
       0                                                                           AS `bIsGlobal`,
       NULL                                                                        AS `cErpCode`,
       NULL                                                                        AS `cEaiCode`,
       `iuap_cloud_basedoc`.`org_factory`.`parentid`                               AS `iparentId`,
       (case `iuap_cloud_basedoc`.`org_factory`.`enable` when 1 then 0 else 1 end) AS `bStopStatus`,
       NULL                                                                        AS `dStopTime`,
       `iuap_cloud_basedoc`.`org_factory`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_factory`.`creationtime`                           AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_factory`.`modifiedtime`                           AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_factory`.`modifiedtime`                           AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_factory`.`creator`                                AS `cCreator`,
       `iuap_cloud_basedoc`.`org_factory`.`modifier`                               AS `cModifier`,
       `iuap_cloud_basedoc`.`org_factory`.`creator`                                AS `creatorId`,
       `iuap_cloud_basedoc`.`org_factory`.`modifier`                               AS `modifierId`,
       `iuap_cloud_basedoc`.`org_factory`.`orgid`                                  AS `id`,
       `iuap_cloud_basedoc`.`org_factory`.`orgid`                                  AS `orgid`,
       `iuap_cloud_basedoc`.`org_factory`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                      AS `tenant_id`,
       NULL                                                                        AS `customerId`,
       `iuap_cloud_basedoc`.`org_factory`.`name2`                                  AS `cName2`,
       `iuap_cloud_basedoc`.`org_factory`.`name3`                                  AS `cName3`,
       `iuap_cloud_basedoc`.`org_factory`.`name4`                                  AS `cName4`,
       `iuap_cloud_basedoc`.`org_factory`.`name5`                                  AS `cName5`,
       `iuap_cloud_basedoc`.`org_factory`.`name6`                                  AS `cName6`,
       `iuap_cloud_basedoc`.`org_factory`.`name2`                                  AS `cFullName2`,
       `iuap_cloud_basedoc`.`org_factory`.`name3`                                  AS `cFullName3`,
       `iuap_cloud_basedoc`.`org_factory`.`name4`                                  AS `cFullName4`,
       `iuap_cloud_basedoc`.`org_factory`.`name5`                                  AS `cFullName5`,
       `iuap_cloud_basedoc`.`org_factory`.`name6`                                  AS `cFullName6`,
       `iuap_cloud_basedoc`.`org_factory`.`external_org`                           AS `external_org`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_factory`
                   on ((`iuap_cloud_basedoc`.`org_factory`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_factory`.`dr` = 0);

-- comment on column v_org_factory.cCode not supported: 编码

-- comment on column v_org_factory.cName not supported: 名称

-- comment on column v_org_factory.cFullName not supported: 名称

-- comment on column v_org_factory.iSortNum not supported: 显示顺序

-- comment on column v_org_factory.iparentId not supported: 上级节点

-- comment on column v_org_factory.dCreateTime not supported: 创建时间

-- comment on column v_org_factory.dCreateDate not supported: 创建时间

-- comment on column v_org_factory.dModifyTime not supported: 修改时间

-- comment on column v_org_factory.dModifyDate not supported: 修改时间

-- comment on column v_org_factory.cCreator not supported: 创建人

-- comment on column v_org_factory.cModifier not supported: 修改人

-- comment on column v_org_factory.creatorId not supported: 创建人

-- comment on column v_org_factory.modifierId not supported: 修改人

-- comment on column v_org_factory.id not supported: 组织单元主键

-- comment on column v_org_factory.orgid not supported: 组织单元主键

-- comment on column v_org_factory.pubts not supported: 公共时间戳

-- comment on column v_org_factory.tenant_id not supported: ID

-- comment on column v_org_factory.cName2 not supported: 英文

-- comment on column v_org_factory.cName3 not supported: 中文繁体

-- comment on column v_org_factory.cName4 not supported: 法语

-- comment on column v_org_factory.cName5 not supported: 备用

-- comment on column v_org_factory.cName6 not supported: 备用

-- comment on column v_org_factory.cFullName2 not supported: 英文

-- comment on column v_org_factory.cFullName3 not supported: 中文繁体

-- comment on column v_org_factory.cFullName4 not supported: 法语

-- comment on column v_org_factory.cFullName5 not supported: 备用

-- comment on column v_org_factory.cFullName6 not supported: 备用

-- comment on column v_org_factory.external_org not supported: 外部组织标识

