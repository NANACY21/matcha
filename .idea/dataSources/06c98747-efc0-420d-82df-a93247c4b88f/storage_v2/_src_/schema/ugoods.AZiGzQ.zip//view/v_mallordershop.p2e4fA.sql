create definer = yonyou@`%` view v_mallordershop as
select `ugoods`.`merchant`.`id`        AS `id`,
       `ugoods`.`merchant`.`cCode`     AS `code`,
       `ugoods`.`merchant`.`cName`     AS `name`,
       `ugoods`.`merchant`.`id`        AS `customerId`,
       `ugoods`.`merchant`.`pubts`     AS `pubts`,
       `ugoods`.`merchant`.`tenant_id` AS `iCorpId`,
       `ugoods`.`tenant`.`yxytenantid` AS `yxyTenantId`
from ((`ugoods`.`merchant` left join `ugoods`.`tenant` on ((`ugoods`.`tenant`.`id` = `ugoods`.`merchant`.`tenant_id`)))
         left join `ugoods`.`merchantroleinfo` `info` on (((`info`.`imerchantId` = `ugoods`.`merchant`.`id`) and
                                                           (`info`.`tenant_id` = `ugoods`.`merchant`.`tenant_id`) and
                                                           (`info`.`cMerchantOptions` = 1))));

