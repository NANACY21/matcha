create definer = yonyou@`%` view v_mallordershop as
select `v_mallordershop_all`.`id`          AS `id`,
       `v_mallordershop_all`.`code`        AS `code`,
       `v_mallordershop_all`.`name`        AS `name`,
       `v_mallordershop_all`.`customerId`  AS `customerId`,
       `v_mallordershop_all`.`pubts`       AS `pubts`,
       `v_mallordershop_all`.`iCorpId`     AS `iCorpId`,
       `v_mallordershop_all`.`yxyTenantId` AS `yxyTenantId`
from `ugoods`.`v_mallordershop_all`
where (`v_mallordershop_all`.`yxyTenantId` is not null)
group by `v_mallordershop_all`.`id`, `v_mallordershop_all`.`yxyTenantId`;

