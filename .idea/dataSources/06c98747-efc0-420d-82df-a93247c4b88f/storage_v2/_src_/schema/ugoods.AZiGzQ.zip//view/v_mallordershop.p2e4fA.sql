create definer = yonyou@`%` view v_mallordershop as
select `ugoods`.`merchant`.`id`        AS `id`,
       `ugoods`.`merchant`.`cCode`     AS `code`,
       `ugoods`.`merchant`.`cName`     AS `name`,
       `ugoods`.`merchant`.`id`        AS `customerId`,
       `ugoods`.`merchant`.`pubts`     AS `pubts`,
       `ugoods`.`merchant`.`tenant_id` AS `iCorpId`,
       `ugoods`.`tenant`.`yxytenantid` AS `yxyTenantId`
from ((`ugoods`.`merchant` left join `ugoods`.`tenant` on ((`ugoods`.`tenant`.`id` = `ugoods`.`merchant`.`tenant_id`)))
         left join `ugoods`.`merchantroleinfo` `info` on (((`info`.`imerchantId` = `ugoods`.`merchant`.`id`) and
                                                           (`info`.`tenant_id` = `ugoods`.`merchant`.`tenant_id`) and
                                                           (`info`.`cMerchantOptions` = 1))));

-- comment on column v_mallordershop.id not supported: ID

-- comment on column v_mallordershop.code not supported: 客户编码

-- comment on column v_mallordershop.name not supported: 客户名称

-- comment on column v_mallordershop.customerId not supported: ID

-- comment on column v_mallordershop.pubts not supported: 时间戳

-- comment on column v_mallordershop.iCorpId not supported: 租户

-- comment on column v_mallordershop.yxyTenantId not supported: 营销云调用的租户ID

