create definer = yonyou@`%` view pu_v_venlook as
select distinct `ugoods`.`pu_venandinv`.`vendor_id` AS `id`,
                ''                                  AS `code`,
                'tempName111'                       AS `name`,
                `ugoods`.`pu_venandinv`.`vendor_id` AS `vendor_id`,
                `ugoods`.`pu_venandinv`.`lookat`    AS `lookat`,
                `ugoods`.`pu_venandinv`.`tenant_id` AS `tenant_id`,
                ''                                  AS `parent_id`,
                1                                   AS `level`,
                ''                                  AS `path`,
                1                                   AS `sort_num`,
                1                                   AS `isEnd`,
                ''                                  AS `pubts`
from `ugoods`.`pu_venandinv`;

