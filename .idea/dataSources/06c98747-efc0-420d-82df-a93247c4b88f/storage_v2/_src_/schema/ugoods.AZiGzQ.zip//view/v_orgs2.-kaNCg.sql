create definer = yonyou@`%` view v_orgs2 as
select `iuap_cloud_basedoc`.`org_orgs`.`code` AS `cCode`,
       `iuap_cloud_basedoc`.`org_orgs`.`name` AS `cName`,
       `iuap_cloud_basedoc`.`org_orgs`.`name` AS `cFullName`,
       `iuap_cloud_basedoc`.`org_orgs`.`id`   AS `id`,
       `iuap_cloud_basedoc`.`org_orgs`.`ts`   AS `pubts`,
       `ugoods`.`tenant`.`id`                 AS `tenant_id`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`org_orgs`
              on ((`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where ((`iuap_cloud_basedoc`.`org_orgs`.`dr` = 0) and (`iuap_cloud_basedoc`.`org_orgs`.`is_biz_unit` = 1) and
       (`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`));

-- comment on column v_orgs2.id not supported: 主键

-- comment on column v_orgs2.pubts not supported: 公共时间戳

-- comment on column v_orgs2.tenant_id not supported: ID

