create definer = yonyou@`%` view v_product_firstpic as
select `a`.`productId` AS `productid`, `a`.`cFolder` AS `url`
from (`ugoods`.`productalbum` `a`
         join `ugoods`.`v_productalbum_min` `f`
              on (((`a`.`productId` = `f`.`productid`) and (`a`.`id` = `f`.`firstrecord`))));

