create definer = yonyou@`%` view v_organdfuncs as
select `iuap_cloud_basedoc`.`org_typ_lnk`.`id`        AS `id`,
       `iuap_cloud_basedoc`.`org_typ_lnk`.`orgid`     AS `IOrgId`,
       `iuap_cloud_basedoc`.`org_typ_lnk`.`orgtypeid` AS `iOrgfuncId`,
       `ugoods`.`tenant`.`id`                         AS `tenant_id`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`org_typ_lnk`
              on ((`iuap_cloud_basedoc`.`org_typ_lnk`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)));

-- comment on column v_organdfuncs.id not supported: 主键

-- comment on column v_organdfuncs.IOrgId not supported: 组织主键

-- comment on column v_organdfuncs.iOrgfuncId not supported: 组织类型主键

-- comment on column v_organdfuncs.tenant_id not supported: ID

