create definer = yonyou@`%` view v_organdfuncs as
select `iuap_cloud_basedoc`.`org_typ_lnk`.`id`        AS `id`,
       `iuap_cloud_basedoc`.`org_typ_lnk`.`orgid`     AS `IOrgId`,
       `iuap_cloud_basedoc`.`org_typ_lnk`.`orgtypeid` AS `iOrgfuncId`,
       `ugoods`.`tenant`.`id`                         AS `tenant_id`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`org_typ_lnk`
              on ((`iuap_cloud_basedoc`.`org_typ_lnk`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)));

