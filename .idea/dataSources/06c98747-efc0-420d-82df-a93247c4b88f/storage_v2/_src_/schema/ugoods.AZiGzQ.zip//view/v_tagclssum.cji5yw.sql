create definer = yonyou@`%` view v_tagclssum as
select `cls`.`tagclass_abbr`  AS `tagclass_abbr`,
       `cls`.`tagclass_scope` AS `tagclass_scope`,
       `cls`.`code`           AS `code`,
       `cls`.`name`           AS `name`,
       `cls`.`id`             AS `id`,
       `cls`.`pubts`          AS `pubts`,
       `cls`.`tenant_id`      AS `tenant_id`,
       `cls`.`iDeleted`       AS `iDeleted`,
       `v_tag`.`nameList`     AS `nameList`,
       `v_tag`.`tagCount`     AS `tagCount`
from (`ugoods`.`tagclass` `cls`
         left join `ugoods`.`v_tagsum` `v_tag` on ((`cls`.`id` = `v_tag`.`tagClass`)));

