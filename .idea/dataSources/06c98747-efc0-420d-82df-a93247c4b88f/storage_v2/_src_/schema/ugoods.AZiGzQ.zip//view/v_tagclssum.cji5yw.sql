create definer = yonyou@`%` view v_tagclssum as
select `cls`.`tagclass_abbr`  AS `tagclass_abbr`,
       `cls`.`tagclass_scope` AS `tagclass_scope`,
       `cls`.`code`           AS `code`,
       `cls`.`name`           AS `name`,
       `cls`.`id`             AS `id`,
       `cls`.`pubts`          AS `pubts`,
       `cls`.`tenant_id`      AS `tenant_id`,
       `cls`.`iDeleted`       AS `iDeleted`,
       `v_tag`.`nameList`     AS `nameList`,
       `v_tag`.`tagCount`     AS `tagCount`
from (`ugoods`.`tagclass` `cls`
         left join `ugoods`.`v_tagsum` `v_tag` on ((`cls`.`id` = `v_tag`.`tagClass`)));

-- comment on column v_tagclssum.tagclass_abbr not supported: 标签分类备注

-- comment on column v_tagclssum.tagclass_scope not supported: 标签分类范围

-- comment on column v_tagclssum.code not supported: 标签分组编码

-- comment on column v_tagclssum.name not supported: 标签分组名称

-- comment on column v_tagclssum.id not supported: ID

-- comment on column v_tagclssum.pubts not supported: 时间戳

-- comment on column v_tagclssum.tenant_id not supported: 租户

-- comment on column v_tagclssum.iDeleted not supported: 逻辑删除标记

