create definer = yonyou@`%` view userdefine_view as
select `ugoods`.`userdefine`.`userdefid`                                                                           AS `userdefid`,
       group_concat(`ugoods`.`userdefine`.`erp_name` order by `ugoods`.`userdefine`.`ordernum` ASC separator
                    '; ')                                                                                          AS `erpNameList`,
       group_concat(`ugoods`.`userdefine`.`name` order by `ugoods`.`userdefine`.`ordernum` ASC separator
                    '; ')                                                                                          AS `nameList`
from `ugoods`.`userdefine`
group by `ugoods`.`userdefine`.`userdefid`;

