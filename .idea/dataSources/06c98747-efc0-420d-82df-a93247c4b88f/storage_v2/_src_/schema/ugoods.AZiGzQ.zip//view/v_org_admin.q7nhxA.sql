create definer = chenhy@`%` view v_org_admin as
select `iuap_cloud_basedoc`.`org_orgs`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`org_orgs`.`name`                                   AS `cName`,
       `iuap_cloud_basedoc`.`org_orgs`.`name`                                   AS `cFullName`,
       `iuap_cloud_basedoc`.`org_orgs`.`displayorder`                           AS `iSortNum`,
       0                                                                        AS `bIsEnd`,
       NULL                                                                     AS `cOrgFuncId`,
       0                                                                        AS `bIsGlobal`,
       NULL                                                                     AS `cErpCode`,
       NULL                                                                     AS `cEaiCode`,
       (case `iuap_cloud_basedoc`.`org_orgs`.`enable` when 1 then 0 else 1 end) AS `bStopStatus`,
       NULL                                                                     AS `dStopTime`,
       `iuap_cloud_basedoc`.`org_orgs`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_orgs`.`creationtime`                           AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifiedtime`                           AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifiedtime`                           AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_orgs`.`creator`                                AS `cCreator`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifier`                               AS `cModifier`,
       `iuap_cloud_basedoc`.`org_orgs`.`creator`                                AS `creatorId`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifier`                               AS `modifierId`,
       `iuap_cloud_basedoc`.`org_orgs`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_orgs`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                   AS `tenant_id`,
       `iuap_cloud_basedoc`.`org_orgs`.`region`                                 AS `region`,
       `iuap_cloud_basedoc`.`org_orgs`.`orgform`                                AS `orgform`,
       `iuap_cloud_basedoc`.`org_orgs`.`corpid`                                 AS `corpid`,
       `iuap_cloud_basedoc`.`org_orgs`.`taxpayerid`                             AS `taxpayerid`,
       `iuap_cloud_basedoc`.`org_orgs`.`locationid`                             AS `locationid`,
       `iuap_cloud_basedoc`.`org_orgs`.`orglevel`                               AS `orglevel`,
       `iuap_cloud_basedoc`.`org_orgs`.`depttype`                               AS `depttype`,
       `iuap_cloud_basedoc`.`org_orgs`.`orgid`                                  AS `orgid`,
       `iuap_cloud_basedoc`.`org_orgs`.`parentid`                               AS `iparentId`,
       `iuap_cloud_basedoc`.`org_orgs`.`parentorgid`                            AS `parentorgid`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_orgs`
                   on ((`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_orgs`.`dr` = 0);

-- comment on column v_org_admin.iSortNum not supported: 显示顺序

-- comment on column v_org_admin.dCreateTime not supported: 创建时间

-- comment on column v_org_admin.dCreateDate not supported: 创建时间

-- comment on column v_org_admin.dModifyTime not supported: 修改时间

-- comment on column v_org_admin.dModifyDate not supported: 修改时间

-- comment on column v_org_admin.cCreator not supported: 创建者

-- comment on column v_org_admin.cModifier not supported: 修改人

-- comment on column v_org_admin.creatorId not supported: 创建者

-- comment on column v_org_admin.modifierId not supported: 修改人

-- comment on column v_org_admin.id not supported: 主键

-- comment on column v_org_admin.pubts not supported: 公共时间戳

-- comment on column v_org_admin.tenant_id not supported: ID

-- comment on column v_org_admin.region not supported: 国家地区

-- comment on column v_org_admin.orgform not supported: 组织形态冗余

-- comment on column v_org_admin.corpid not supported: 对应合同主体

-- comment on column v_org_admin.taxpayerid not supported: 纳税人识别号

-- comment on column v_org_admin.locationid not supported: 地点

-- comment on column v_org_admin.orglevel not supported: 组织级别

-- comment on column v_org_admin.depttype not supported: 部门性质

-- comment on column v_org_admin.orgid not supported: 组织单元主键

-- comment on column v_org_admin.iparentId not supported: 上级节点

-- comment on column v_org_admin.parentorgid not supported: 所属组织主键

