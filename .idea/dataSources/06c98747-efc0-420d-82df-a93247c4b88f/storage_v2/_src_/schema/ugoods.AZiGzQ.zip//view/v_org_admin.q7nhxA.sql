create definer = yonyou@`%` view v_org_admin as
select `iuap_cloud_basedoc`.`org_orgs`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`org_orgs`.`name`                                   AS `cName`,
       `iuap_cloud_basedoc`.`org_orgs`.`name`                                   AS `cFullName`,
       `iuap_cloud_basedoc`.`org_orgs`.`displayorder`                           AS `iSortNum`,
       0                                                                        AS `bIsEnd`,
       NULL                                                                     AS `cOrgFuncId`,
       0                                                                        AS `bIsGlobal`,
       NULL                                                                     AS `cErpCode`,
       NULL                                                                     AS `cEaiCode`,
       (case `iuap_cloud_basedoc`.`org_orgs`.`enable` when 1 then 0 else 1 end) AS `bStopStatus`,
       NULL                                                                     AS `dStopTime`,
       `iuap_cloud_basedoc`.`org_orgs`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_orgs`.`creationtime`                           AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifiedtime`                           AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifiedtime`                           AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_orgs`.`creator`                                AS `cCreator`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifier`                               AS `cModifier`,
       `iuap_cloud_basedoc`.`org_orgs`.`creator`                                AS `creatorId`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifier`                               AS `modifierId`,
       `iuap_cloud_basedoc`.`org_orgs`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_orgs`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                   AS `tenant_id`,
       `iuap_cloud_basedoc`.`org_orgs`.`region`                                 AS `region`,
       `iuap_cloud_basedoc`.`org_orgs`.`orgform`                                AS `orgform`,
       `iuap_cloud_basedoc`.`org_orgs`.`corpid`                                 AS `corpid`,
       `iuap_cloud_basedoc`.`org_orgs`.`taxpayerid`                             AS `taxpayerid`,
       `iuap_cloud_basedoc`.`org_orgs`.`locationid`                             AS `locationid`,
       `iuap_cloud_basedoc`.`org_orgs`.`orglevel`                               AS `orglevel`,
       `iuap_cloud_basedoc`.`org_orgs`.`depttype`                               AS `depttype`,
       `iuap_cloud_basedoc`.`org_orgs`.`orgid`                                  AS `orgid`,
       `iuap_cloud_basedoc`.`org_orgs`.`parentid`                               AS `iparentId`,
       `iuap_cloud_basedoc`.`org_orgs`.`parentorgid`                            AS `parentorgid`,
       `iuap_cloud_basedoc`.`org_orgs`.`external_org`                           AS `external_org`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_orgs`
                   on ((`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_orgs`.`dr` = 0);

