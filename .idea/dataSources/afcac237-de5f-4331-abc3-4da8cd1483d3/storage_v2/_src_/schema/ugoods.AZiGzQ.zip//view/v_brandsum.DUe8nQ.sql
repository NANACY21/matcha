create definer = root@`%` view v_brandsum as
select `ugoods`.`brand`.`brandClass`                              AS `brandClass`,
       group_concat(`ugoods`.`brand`.`brand_name` separator '; ') AS `nameList`,
       count(`ugoods`.`brand`.`id`)                               AS `brandCount`
from `ugoods`.`brand`
group by `ugoods`.`brand`.`brandClass`;

