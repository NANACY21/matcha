create definer = root@`%` view v_brandclssum as
select `cls`.`id`              AS `id`,
       `cls`.`brandclass_name` AS `brandclass_name`,
       `cls`.`brandclass_abbr` AS `brandclass_abbr`,
       `cls`.`brandclass_code` AS `brandclass_code`,
       `cls`.`pubts`           AS `pubts`,
       `cls`.`tenant_id`       AS `tenant_id`,
       `cls`.`iDeleted`        AS `isDeleted`,
       `v_brand`.`nameList`    AS `nameList`,
       `v_brand`.`brandCount`  AS `brandCount`
from (`ugoods`.`brandclass` `cls`
         left join `ugoods`.`v_brandsum` `v_brand` on ((`cls`.`id` = `v_brand`.`brandClass`)));

