create definer = root@`%` view v_orgs11 as
select `iuap_cloud_basedoc`.`org_orgs`.`code` AS `cCode`,
       `iuap_cloud_basedoc`.`org_orgs`.`name` AS `cName`,
       `iuap_cloud_basedoc`.`org_orgs`.`name` AS `cFullName`,
       `iuap_cloud_basedoc`.`org_orgs`.`id`   AS `id`,
       `iuap_cloud_basedoc`.`org_orgs`.`ts`   AS `pubts`,
       `ugoods`.`tenant`.`id`                 AS `tenant_id`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_orgs`
                   on ((`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)));

