create view v_depttypes as
select `iuap_cloud_basedoc`.`org_dept_type`.`id`           AS `id`,
       `iuap_cloud_basedoc`.`org_dept_type`.`CODE`         AS `cCode`,
       `iuap_cloud_basedoc`.`org_dept_type`.`NAME`         AS `cName`,
       `ugoods`.`tenant`.`id`                              AS `tenant_id`,
       `iuap_cloud_basedoc`.`org_dept_type`.`sysid`        AS `sysid`,
       `iuap_cloud_basedoc`.`org_dept_type`.`ts`           AS `ts`,
       `iuap_cloud_basedoc`.`org_dept_type`.`pubts`        AS `pubts`,
       `iuap_cloud_basedoc`.`org_dept_type`.`dr`           AS `dr`,
       `iuap_cloud_basedoc`.`org_dept_type`.`enable`       AS `enable`,
       `iuap_cloud_basedoc`.`org_dept_type`.`creator`      AS `cCreator`,
       `iuap_cloud_basedoc`.`org_dept_type`.`creationtime` AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_dept_type`.`name2`        AS `name2`,
       `iuap_cloud_basedoc`.`org_dept_type`.`name3`        AS `name3`,
       `iuap_cloud_basedoc`.`org_dept_type`.`name4`        AS `name4`,
       `iuap_cloud_basedoc`.`org_dept_type`.`name5`        AS `name5`,
       `iuap_cloud_basedoc`.`org_dept_type`.`name6`        AS `name6`,
       `iuap_cloud_basedoc`.`org_dept_type`.`displayorder` AS `displayorder`,
       `iuap_cloud_basedoc`.`org_dept_type`.`memo`         AS `memo`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_dept_type`
                   on ((`iuap_cloud_basedoc`.`org_dept_type`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_dept_type`.`dr` = 0);

-- comment on column v_depttypes.id not supported: 主键

-- comment on column v_depttypes.cCode not supported: 编码

-- comment on column v_depttypes.cName not supported: 名称

-- comment on column v_depttypes.tenant_id not supported: ID

-- comment on column v_depttypes.sysid not supported: 系统标识

-- comment on column v_depttypes.pubts not supported: 时间戳

-- comment on column v_depttypes.dr not supported: 逻辑删除标识

-- comment on column v_depttypes.enable not supported: 启用状态 0 未启用 1 已启用 2 已停用

-- comment on column v_depttypes.cCreator not supported: 创建人

-- comment on column v_depttypes.dCreateTime not supported: 创建时间

-- comment on column v_depttypes.name2 not supported: 英文

-- comment on column v_depttypes.name3 not supported: 中文简体

-- comment on column v_depttypes.name4 not supported: 法语

-- comment on column v_depttypes.name5 not supported: 备用

-- comment on column v_depttypes.name6 not supported: 备用

-- comment on column v_depttypes.displayorder not supported: 排序字段

-- comment on column v_depttypes.memo not supported: 描述

