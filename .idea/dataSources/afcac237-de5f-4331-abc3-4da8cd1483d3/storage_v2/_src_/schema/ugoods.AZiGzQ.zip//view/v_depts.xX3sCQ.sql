create definer = root@`%` view v_depts as
select `iuap_cloud_basedoc`.`org_admin`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_admin`.`ts`                                     AS `ts`,
       `iuap_cloud_basedoc`.`org_admin`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`org_admin`.`name`                                   AS `cFullName`,
       `iuap_cloud_basedoc`.`org_admin`.`name2`                                  AS `cFullName2`,
       `iuap_cloud_basedoc`.`org_admin`.`name3`                                  AS `cFullName3`,
       `iuap_cloud_basedoc`.`org_admin`.`name4`                                  AS `cFullName4`,
       `iuap_cloud_basedoc`.`org_admin`.`name5`                                  AS `cFullName5`,
       `iuap_cloud_basedoc`.`org_admin`.`name6`                                  AS `cFullName6`,
       `iuap_cloud_basedoc`.`org_admin`.`name`                                   AS `cName`,
       `iuap_cloud_basedoc`.`org_admin`.`name2`                                  AS `cName2`,
       `iuap_cloud_basedoc`.`org_admin`.`name3`                                  AS `cName3`,
       `iuap_cloud_basedoc`.`org_admin`.`name4`                                  AS `cName4`,
       `iuap_cloud_basedoc`.`org_admin`.`name5`                                  AS `cName5`,
       `iuap_cloud_basedoc`.`org_admin`.`name6`                                  AS `cName6`,
       (case
            when (`iuap_cloud_basedoc`.`org_admin`.`parentid` = '') then NULL
            else `iuap_cloud_basedoc`.`org_admin`.`parentid` end)                AS `iparentId`,
       `iuap_cloud_basedoc`.`org_admin`.`level`                                  AS `iGrade`,
       `iuap_cloud_basedoc`.`org_admin`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`org_admin`.`creationtime`                           AS `dCreateDate`,
       `iuap_cloud_basedoc`.`org_admin`.`modifiedtime`                           AS `dModifyTime`,
       `iuap_cloud_basedoc`.`org_admin`.`modifiedtime`                           AS `dModifyDate`,
       `iuap_cloud_basedoc`.`org_admin`.`creator`                                AS `cCreator`,
       `iuap_cloud_basedoc`.`org_admin`.`modifier`                               AS `cModifier`,
       `iuap_cloud_basedoc`.`org_admin`.`creator`                                AS `creatorId`,
       `iuap_cloud_basedoc`.`org_admin`.`modifier`                               AS `modifierId`,
       `iuap_cloud_basedoc`.`org_admin`.`isEnd`                                  AS `bIsEnd`,
       `iuap_cloud_basedoc`.`org_admin`.`displayorder`                           AS `iSortNum`,
       `iuap_cloud_basedoc`.`org_admin`.`depttype`                               AS `depttype`,
       `iuap_cloud_basedoc`.`org_admin`.`principal`                              AS `principal`,
       NULL                                                                      AS `iSupparentID`,
       NULL                                                                      AS `cErpCode`,
       `iuap_cloud_basedoc`.`org_admin`.`parentorgid`                            AS `iOrgID`,
       (case `iuap_cloud_basedoc`.`org_admin`.`enable` when 1 then 0 else 1 end) AS `bStopStatus`,
       NULL                                                                      AS `dStopTime`,
       NULL                                                                      AS `cMemo`,
       NULL                                                                      AS `iCorpId`,
       NULL                                                                      AS `cAppID`,
       `ugoods`.`tenant`.`id`                                                    AS `tenant_id`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`org_admin`
              on ((`iuap_cloud_basedoc`.`org_admin`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where ((`iuap_cloud_basedoc`.`org_admin`.`orgtype` = 2) and (`iuap_cloud_basedoc`.`org_admin`.`dr` = 0) and
       (`iuap_cloud_basedoc`.`org_admin`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`));

