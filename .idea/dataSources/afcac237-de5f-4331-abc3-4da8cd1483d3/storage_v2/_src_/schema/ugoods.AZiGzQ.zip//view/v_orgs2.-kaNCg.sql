create definer = root@`%` view v_orgs2 as
select `iuap_cloud_basedoc`.`org_orgs`.`code` AS `cCode`,
       `iuap_cloud_basedoc`.`org_orgs`.`name` AS `cName`,
       `iuap_cloud_basedoc`.`org_orgs`.`name` AS `cFullName`,
       `iuap_cloud_basedoc`.`org_orgs`.`id`   AS `id`,
       `iuap_cloud_basedoc`.`org_orgs`.`ts`   AS `pubts`,
       `ugoods`.`tenant`.`id`                 AS `tenant_id`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`org_orgs`
              on ((`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where ((`iuap_cloud_basedoc`.`org_orgs`.`dr` = 0) and (`iuap_cloud_basedoc`.`org_orgs`.`is_biz_unit` = 1) and
       (`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`));

