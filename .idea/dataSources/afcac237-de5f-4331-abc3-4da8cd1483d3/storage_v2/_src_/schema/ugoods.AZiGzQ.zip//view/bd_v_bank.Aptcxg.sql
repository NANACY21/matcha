create definer = root@`%` view bd_v_bank as
select `ugoods`.`bd_bank`.`bank`         AS `bank`,
       `ugoods`.`bd_bank`.`creator`      AS `creator`,
       `ugoods`.`bd_bank`.`creationtime` AS `creationtime`,
       `ugoods`.`bd_bank`.`modifier`     AS `modifier`,
       `ugoods`.`bd_bank`.`modifiedtime` AS `modifiedtime`,
       `ugoods`.`bd_bank`.`id`           AS `id`,
       `ugoods`.`bd_bank`.`pubts`        AS `pubts`,
       `ugoods`.`bd_bank`.`code`         AS `code`,
       `ugoods`.`bd_bank`.`name`         AS `name`,
       `ugoods`.`bd_bank`.`sysid`        AS `sysid`,
       `ugoods`.`bd_bank`.`dr`           AS `dr`,
       `ugoods`.`bd_bank`.`tenantid`     AS `tenantid`
from `ugoods`.`bd_bank`
where (`ugoods`.`bd_bank`.`tenantid` = 'a65xtqwz')
order by `ugoods`.`bd_bank`.`code`;

