create view user as
select `u8c_yht`.`user`.`id`             AS `id`,
       `u8c_yht`.`user`.`yht_user_id`    AS `yht_user_id`,
       `u8c_yht`.`user`.`tenant_id`      AS `tenant_id`,
       `u8c_yht`.`user`.`res_code`       AS `res_code`,
       `u8c_yht`.`user`.`user_type`      AS `user_type`,
       `u8c_yht`.`user`.`shop_id`        AS `shop_id`,
       `u8c_yht`.`user`.`customer_id`    AS `customer_id`,
       `u8c_yht`.`user`.`stopstatus`     AS `stopstatus`,
       `u8c_yht`.`user`.`ts`             AS `ts`,
       `u8c_yht`.`user`.`uts`            AS `uts`,
       `u8c_yht`.`user`.`creator`        AS `creator`,
       `u8c_yht`.`user`.`shop_name`      AS `shop_name`,
       `u8c_yht`.`user`.`customer_name`  AS `customer_name`,
       `u8c_yht`.`user`.`deleted`        AS `deleted`,
       `u8c_yht`.`user`.`yht_tenant_id`  AS `yht_tenant_id`,
       `u8c_yht`.`user`.`name`           AS `name`,
       `u8c_yht`.`user`.`mobile`         AS `mobile`,
       `u8c_yht`.`user`.`email`          AS `email`,
       `u8c_yht`.`user`.`json_str`       AS `json_str`,
       `u8c_yht`.`user`.`code`           AS `code`,
       `u8c_yht`.`user`.`doc_ids`        AS `doc_ids`,
       `u8c_yht`.`user`.`department_id`  AS `department_id`,
       `u8c_yht`.`user`.`salt`           AS `salt`,
       `u8c_yht`.`user`.`password`       AS `password`,
       `u8c_yht`.`user`.`customer`       AS `customer`,
       `u8c_yht`.`user`.`gender`         AS `gender`,
       `u8c_yht`.`user`.`birthday`       AS `birthday`,
       `u8c_yht`.`user`.`create_time`    AS `create_time`,
       `u8c_yht`.`user`.`create_date`    AS `create_date`,
       `u8c_yht`.`user`.`modify_time`    AS `modify_time`,
       `u8c_yht`.`user`.`modify_date`    AS `modify_date`,
       `u8c_yht`.`user`.`modifier`       AS `modifier`,
       `u8c_yht`.`user`.`position`       AS `position`,
       `u8c_yht`.`user`.`nick_name`      AS `nick_name`,
       `u8c_yht`.`user`.`avatar`         AS `avatar`,
       `u8c_yht`.`user`.`tel`            AS `tel`,
       `u8c_yht`.`user`.`wechat`         AS `wechat`,
       `u8c_yht`.`user`.`qq`             AS `qq`,
       `u8c_yht`.`user`.`corpration_id`  AS `corpration_id`,
       `u8c_yht`.`user`.`yxyuserid`      AS `yxyuserid`,
       `u8c_yht`.`user`.`status`         AS `status`,
       `u8c_yht`.`user`.`registersource` AS `registersource`,
       `u8c_yht`.`user`.`defaultorg`     AS `defaultorg`,
       `u8c_yht`.`user`.`stop_time`      AS `stop_time`,
       `u8c_yht`.`user`.`erpcode`        AS `erpcode`,
       `u8c_yht`.`user`.`defaultstore`   AS `defaultstore`,
       `u8c_yht`.`user`.`openid`         AS `openid`,
       `u8c_yht`.`user`.`isOpenUdh`      AS `isOpenUdh`,
       `u8c_yht`.`user`.`iCustID`        AS `iCustID`,
       `u8c_yht`.`user`.`iShopID`        AS `iShopID`,
       `u8c_yht`.`user`.`mobilepreno`    AS `mobilepreno`,
       `u8c_yht`.`user`.`creatorId`      AS `creatorId`,
       `u8c_yht`.`user`.`modifierId`     AS `modifierId`,
       `u8c_yht`.`user`.`pubts`          AS `pubts`,
       `u8c_yht`.`user`.`ext1`           AS `ext1`,
       `u8c_yht`.`user`.`ext2`           AS `ext2`,
       `u8c_yht`.`user`.`ext3`           AS `ext3`,
       `u8c_yht`.`user`.`ext4`           AS `ext4`,
       `u8c_yht`.`user`.`ext5`           AS `ext5`,
       `u8c_yht`.`user`.`ext6`           AS `ext6`,
       `u8c_yht`.`user`.`ext7`           AS `ext7`,
       `u8c_yht`.`user`.`ext8`           AS `ext8`,
       `u8c_yht`.`user`.`ext9`           AS `ext9`,
       `u8c_yht`.`user`.`ext10`          AS `ext10`
from `u8c_yht`.`user`;

-- comment on column user.yht_user_id not supported: 友户通用户id

-- comment on column user.tenant_id not supported: 营销云租户

-- comment on column user.res_code not supported: 系统标识，目前都是diwork

-- comment on column user.user_type not supported: 身份类型

-- comment on column user.stopstatus not supported: 停用状态

-- comment on column user.ts not supported: 创建时间

-- comment on column user.uts not supported: 更新时间

-- comment on column user.creator not supported: 创建人

-- comment on column user.deleted not supported: 删除标识

-- comment on column user.yht_tenant_id not supported: 友户通租户id

-- comment on column user.name not supported: 用户名

-- comment on column user.mobile not supported: 手机号

-- comment on column user.email not supported: 邮箱

-- comment on column user.json_str not supported: 用户身份设置的json数据{}

-- comment on column user.code not supported: 用户编码

-- comment on column user.doc_ids not supported: 关联档案id列表

-- comment on column user.salt not supported: 盐

-- comment on column user.password not supported: 密码

-- comment on column user.customer not supported: 所属客户

-- comment on column user.gender not supported: 性别

-- comment on column user.birthday not supported: 出生日期

-- comment on column user.create_time not supported: 创建时间

-- comment on column user.create_date not supported: 创建日期

-- comment on column user.modify_time not supported: 修改时间

-- comment on column user.modify_date not supported: 修改日期

-- comment on column user.position not supported: 职位

-- comment on column user.nick_name not supported: 昵称

-- comment on column user.avatar not supported: 头像

-- comment on column user.tel not supported: 座机

-- comment on column user.wechat not supported: wechat

-- comment on column user.qq not supported: qq

-- comment on column user.yxyuserid not supported: 应用之间调用的用户关系

-- comment on column user.mobilepreno not supported: 手机号前缀

-- comment on column user.creatorId not supported: 创建人

-- comment on column user.modifierId not supported: 修改人

-- comment on column user.pubts not supported: 时间戳

