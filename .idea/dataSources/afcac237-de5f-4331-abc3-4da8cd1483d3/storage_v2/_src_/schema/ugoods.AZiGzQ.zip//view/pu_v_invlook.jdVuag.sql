create definer = root@`%` view pu_v_invlook as
select distinct `ugoods`.`pu_venandinv`.`product_id` AS `id`,
                ''                                   AS `code`,
                'tempName222'                        AS `name`,
                `ugoods`.`pu_venandinv`.`product_id` AS `product_id`,
                `ugoods`.`pu_venandinv`.`lookat`     AS `lookat`,
                `ugoods`.`pu_venandinv`.`tenant_id`  AS `tenant_id`,
                ''                                   AS `parent_id`,
                1                                    AS `level`,
                ''                                   AS `path`,
                1                                    AS `sort_num`,
                1                                    AS `isEnd`,
                ''                                   AS `pubts`
from `ugoods`.`pu_venandinv`;

