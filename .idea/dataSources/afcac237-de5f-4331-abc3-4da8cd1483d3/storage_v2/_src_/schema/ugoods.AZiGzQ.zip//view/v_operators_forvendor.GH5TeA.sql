create definer = root@`%` view v_operators_forvendor as
select `iuap_cloud_basedoc`.`bd_staff`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`bd_staff`.`name`                                   AS `cName`,
       `ugoods`.`tenant`.`id`                                                   AS `tenant_id`,
       `iuap_cloud_basedoc`.`bd_staff`.`ts`                                     AS `pubts`,
       `iuap_cloud_basedoc`.`bd_staff`.`photo`                                  AS `cHeadPicUrl`,
       `iuap_cloud_basedoc`.`bd_staff`.`mobile`                                 AS `cPhone`,
       `iuap_cloud_basedoc`.`bd_staff`.`email`                                  AS `cEmail`,
       NULL                                                                     AS `cErpCode`,
       NULL                                                                     AS `iPosition`,
       (case `iuap_cloud_basedoc`.`bd_staff`.`enable` when 1 then 1 else 0 end) AS `iStatus`,
       NULL                                                                     AS `iAuditStatus`,
       `iuap_cloud_basedoc`.`bd_staff`.`joinworkdate`                           AS `dEntryTime`,
       NULL                                                                     AS `dLeaveTime`,
       NULL                                                                     AS `cIntro`,
       NULL                                                                     AS `cYxyUserId`,
       `iuap_cloud_basedoc`.`bd_staff`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`bd_staff`.`modifiedtime`                           AS `dUpdateTime`,
       `iuap_cloud_basedoc`.`bd_staff`.`sex`                                    AS `iGender`,
       `iuap_cloud_basedoc`.`bd_staff`.`id`                                     AS `id`,
       NULL                                                                     AS `create_date`,
       NULL                                                                     AS `modify_date`,
       `iuap_cloud_basedoc`.`bd_staff`.`creator`                                AS `creator`,
       `iuap_cloud_basedoc`.`bd_staff`.`modifier`                               AS `modifier`,
       NULL                                                                     AS `cAppID`,
       `iuap_cloud_basedoc`.`bd_staff`.`user_id`                                AS `userId`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`bd_staff`
              on ((`iuap_cloud_basedoc`.`bd_staff`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where ((`iuap_cloud_basedoc`.`bd_staff`.`dr` = 0) and
       (`iuap_cloud_basedoc`.`bd_staff`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`));

