create definer = root@`%` view v_depts1 as
select `iuap_cloud_basedoc`.`org_admin`.`id` AS `id`, `ugoods`.`tenant`.`id` AS `tenant_id`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`org_admin`
              on ((`iuap_cloud_basedoc`.`org_admin`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where ((`iuap_cloud_basedoc`.`org_admin`.`orgtype` = 2) and (`iuap_cloud_basedoc`.`org_admin`.`dr` = 0) and
       (`iuap_cloud_basedoc`.`org_admin`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`));

