create view v_emp_dept as
select `drpx`.`emp`.`empno`  AS `empno`,
       `drpx`.`emp`.`ename`  AS `ename`,
       `drpx`.`emp`.`job`    AS `job`,
       `drpx`.`dept`.`loc`   AS `loc`,
       `drpx`.`dept`.`dname` AS `dname`
from (`drpx`.`emp`
         join `drpx`.`dept` on ((`drpx`.`emp`.`deptno` = `drpx`.`dept`.`deptno`)));

