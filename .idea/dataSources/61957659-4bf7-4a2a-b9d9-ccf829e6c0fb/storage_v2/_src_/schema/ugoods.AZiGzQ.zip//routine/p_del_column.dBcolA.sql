create
    definer = root@`%` procedure p_del_column(IN ctablename varchar(255), IN ccolumnname varchar(255))
begin 
declare existsCount integer default 0;
declare strsql varchar(512);

set @strsql = concat('alter table ', ctablename, ' drop column ', ccolumnname , ';'); 

SELECT count(1) into existsCount FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name = ctablename AND column_name = ccolumnname;
select existsCount;

if existsCount > 0 then 
prepare strsql from @strsql;
execute strsql;
end if;

end;

