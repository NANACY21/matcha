create view v_aa_regist_info as
select `workbench`.`wb_application`.`application_id`   AS `id`,
       `ugoods`.`tenant`.`id`                          AS `tenant_id`,
       `workbench`.`wb_application`.`ts`               AS `pubts`,
       `workbench`.`wb_application`.`application_code` AS `systemCode`,
       `workbench`.`wb_application`.`application_icon` AS `systemLOGO`,
       `workbench`.`wb_application`.`application_name` AS `systemName`,
       (not (`workbench`.`wb_application`.`enable`))   AS `iDeleted`,
       `workbench`.`wb_application`.`orders`           AS `orderNumber`
from (`workbench`.`wb_application`
         join `ugoods`.`tenant` on ((`workbench`.`wb_application`.`tenant_id` = `ugoods`.`tenant`.`tenantcenter_id`)));

-- comment on column v_aa_regist_info.tenant_id not supported: ID

