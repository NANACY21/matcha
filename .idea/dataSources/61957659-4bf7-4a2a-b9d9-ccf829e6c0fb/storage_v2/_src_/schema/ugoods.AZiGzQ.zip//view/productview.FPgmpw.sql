create view productview as
select `a`.`realProductAttribute`      AS `realProductAttribute`,
       `a`.`virtualProductAttribute`   AS `virtualProductAttribute`,
       `a`.`giftCard_id`               AS `giftCard_id`,
       `a`.`couponId`                  AS `couponId`,
       `a`.`couponType`                AS `couponType`,
       `b`.`productAttribute`          AS `productAttribute`,
       `a`.`code`                      AS `code`,
       `a`.`name`                      AS `name`,
       `a`.`name2`                     AS `name2`,
       `a`.`name3`                     AS `name3`,
       `a`.`name4`                     AS `name4`,
       `a`.`name5`                     AS `name5`,
       `a`.`name6`                     AS `name6`,
       `b`.`shortName`                 AS `shortName`,
       `a`.`cModelDescription`         AS `cModelDescription`,
       `a`.`cModel`                    AS `cModel`,
       `a`.`platformCode`              AS `platformCode`,
       `b`.`mnemonicCode`              AS `mnemonicCode`,
       `a`.`keywords`                  AS `keywords`,
       `a`.`oProductClass_id`          AS `oProductClass_id`,
       `a`.`productClassPath`          AS `productClassPath`,
       `a`.`manageClass`               AS `oManageClass_id`,
       `a`.`manageClass`               AS `manageClass`,
       `a`.`platformClass`             AS `platformClass`,
       `a`.`oSPTemplate_id`            AS `oSPTemplate_id`,
       `a`.`brand_id`                  AS `brand_id`,
       `a`.`productLineId`             AS `productLineId`,
       `b`.`isRecommend`               AS `isRecommend`,
       `a`.`shareDescription`          AS `shareDescription`,
       `a`.`iCustomerServiceDay`       AS `iCustomerServiceDay`,
       `b`.`beUpTime`                  AS `beUpTime`,
       `b`.`iOrder`                    AS `iOrder`,
       `a`.`oUnit_id`                  AS `oUnit_id`,
       `a`.`taxClass`                  AS `taxClass`,
       `b`.`inTaxrate`                 AS `inTaxrate`,
       `a`.`url`                       AS `url`,
       `a`.`iCreatorType`              AS `iCreatorType`,
       `a`.`orgId`                     AS `orgId`,
       `a`.`iCustID`                   AS `iCustID`,
       `a`.`iShopID`                   AS `iShopID`,
       `a`.`iPlatFormStaus`            AS `iPlatFormStaus`,
       `a`.`cPlatFormRemark`           AS `cPlatFormRemark`,
       `a`.`source`                    AS `source`,
       `a`.`hasSpecs`                  AS `hasSpecs`,
       `a`.`defaultSKUId`              AS `defaultSKUId`,
       `a`.`id`                        AS `id`,
       `a`.`pubts`                     AS `pubts`,
       `a`.`tenant_id`                 AS `tenant_id`,
       `a`.`erpCode`                   AS `erpCode`,
       `a`.`iDeleted`                  AS `iDeleted`,
       `a`.`create_time`               AS `create_time`,
       `a`.`create_date`               AS `create_date`,
       `a`.`modify_time`               AS `modify_time`,
       `a`.`modify_date`               AS `modify_date`,
       `a`.`creator`                   AS `creator`,
       `a`.`modifier`                  AS `modifier`,
       `b`.`receiptName`               AS `receiptName`,
       `b`.`outTaxrate`                AS `outTaxrate`,
       `a`.`realProductAttributeType`  AS `realProductAttributeType`,
       `b`.`businessAttribute`         AS `businessAttribute`,
       `b`.`fMarkPrice`                AS `fMarkPrice`,
       `b`.`fSalePrice`                AS `fSalePrice`,
       `b`.`iStatus`                   AS `iStatus`,
       `b`.`fPrimeCosts`               AS `fPrimeCosts`,
       `b`.`cBarCode`                  AS `cBarCode`,
       `c`.`iRangeType`                AS `rangeType`,
       `c`.`orgId`                     AS `range_orgId`,
       `c`.`customerId`                AS `range_customerId`,
       `b`.`productApplyRangeId`       AS `productApplyRangeId`,
       `b`.`productVendor`             AS `productVendor`,
       `b`.`productBuyer`              AS `productBuyer`,
       `b`.`fMaxPrimeCosts`            AS `fMaxPrimeCosts`,
       `b`.`fRequestOrderLimit`        AS `fRequestOrderLimit`,
       `b`.`fPlanOrderLimit`           AS `fPlanOrderLimit`,
       `b`.`produceUnitId`             AS `produceUnitId`,
       `b`.`produceRate`               AS `produceRate`,
       `b`.`iDaysBeforeValidityReject` AS `iDaysBeforeValidityReject`,
       `b`.`iValidityWarningDays`      AS `iValidityWarningDays`,
       `b`.`weight`                    AS `weight`,
       `b`.`volume`                    AS `volume`,
       `b`.`warehouseManager`          AS `warehouseManager`,
       `b`.`deliveryWarehouse`         AS `deliveryWarehouse`,
       `b`.`returnWarehouse`           AS `returnWarehouse`,
       `b`.`fInStoreExcessLimit`       AS `fInStoreExcessLimit`,
       `b`.`fOutStoreExcessLimit`      AS `fOutStoreExcessLimit`
from ((`ugoods`.`product` `a` join `ugoods`.`productextend` `b` on ((`a`.`id` = `b`.`id`)))
         left join `ugoods`.`productapplyrange` `c` on ((`c`.`productId` = `a`.`id`)))
where (`c`.`isCreator` = 1);

-- comment on column productview.realProductAttribute not supported: 商品属性

-- comment on column productview.virtualProductAttribute not supported: 虚拟商品属性

-- comment on column productview.giftCard_id not supported: 礼品卡

-- comment on column productview.couponId not supported: 卡券

-- comment on column productview.couponType not supported: 卡券类型

-- comment on column productview.productAttribute not supported: 销售方式

-- comment on column productview.code not supported: 商品编码

-- comment on column productview.name not supported: 商品名称

-- comment on column productview.name2 not supported: 自定义名称

-- comment on column productview.name3 not supported: 自定义名称

-- comment on column productview.name4 not supported: 自定义名称

-- comment on column productview.name5 not supported: 自定义名称

-- comment on column productview.name6 not supported: 自定义名称

-- comment on column productview.shortName not supported: 物料简称

-- comment on column productview.cModelDescription not supported: 规格型号

-- comment on column productview.cModel not supported: 型号

-- comment on column productview.platformCode not supported: 平台编码

-- comment on column productview.mnemonicCode not supported: 助记码

-- comment on column productview.keywords not supported: 关键字

-- comment on column productview.oProductClass_id not supported: 商品分类

-- comment on column productview.productClassPath not supported: 商品分类path

-- comment on column productview.oManageClass_id not supported: 物料分类

-- comment on column productview.manageClass not supported: 物料分类

-- comment on column productview.platformClass not supported: 平台分类

-- comment on column productview.oSPTemplate_id not supported: 商品模板

-- comment on column productview.brand_id not supported: 商品品牌

-- comment on column productview.productLineId not supported: 产品线

-- comment on column productview.isRecommend not supported: 推荐物料

-- comment on column productview.shareDescription not supported: 分享说明

-- comment on column productview.iCustomerServiceDay not supported: 售后服务期限（天）

-- comment on column productview.beUpTime not supported: 预约上架时间

-- comment on column productview.iOrder not supported: 排序号

-- comment on column productview.oUnit_id not supported: 主计量单位

-- comment on column productview.taxClass not supported: 税收分类码

-- comment on column productview.inTaxrate not supported: 进项税率

-- comment on column productview.url not supported: 商品首图片

-- comment on column productview.iCreatorType not supported: 创建者类型

-- comment on column productview.iCustID not supported: 创建者客户

-- comment on column productview.iShopID not supported: 创建者商家

-- comment on column productview.iPlatFormStaus not supported: 平台处理商家商品状态

-- comment on column productview.cPlatFormRemark not supported: 平台处理商家商品备注

-- comment on column productview.hasSpecs not supported: 是否包含属性

-- comment on column productview.defaultSKUId not supported: 默认SKUID

-- comment on column productview.id not supported: ID

-- comment on column productview.pubts not supported: 时间戳

-- comment on column productview.tenant_id not supported: 租户

-- comment on column productview.erpCode not supported: 商家编码

-- comment on column productview.iDeleted not supported: 逻辑删除标记

-- comment on column productview.create_time not supported: 创建时间

-- comment on column productview.create_date not supported: 创建日期

-- comment on column productview.modify_time not supported: 修改时间

-- comment on column productview.modify_date not supported: 修改日期

-- comment on column productview.receiptName not supported: 开票名称

-- comment on column productview.outTaxrate not supported: 销项税率

-- comment on column productview.realProductAttributeType not supported: 实物商品属性

-- comment on column productview.businessAttribute not supported: 业务属性

-- comment on column productview.fMarkPrice not supported: 建议零售价

-- comment on column productview.fSalePrice not supported: 线上零售价

-- comment on column productview.iStatus not supported: 商城上下架状态

-- comment on column productview.cBarCode not supported: 条形码

-- comment on column productview.rangeType not supported: 商品适用范围类型

-- comment on column productview.range_customerId not supported: 客户ID

-- comment on column productview.productApplyRangeId not supported: 商品分配范围ID

-- comment on column productview.productVendor not supported: 供应商

-- comment on column productview.productBuyer not supported: 采购员

-- comment on column productview.fMaxPrimeCosts not supported: 最高进价

-- comment on column productview.fRequestOrderLimit not supported: 请购订货超量上限%

-- comment on column productview.fPlanOrderLimit not supported: 计划订货超量上限%

-- comment on column productview.produceUnitId not supported: 生产单位

-- comment on column productview.produceRate not supported: 生产单位换算率

-- comment on column productview.iDaysBeforeValidityReject not supported: 库存-近有效期拒收天数

-- comment on column productview.iValidityWarningDays not supported: 库存-效期预警天数

-- comment on column productview.weight not supported: 库存-重量

-- comment on column productview.volume not supported: 库存-体积

-- comment on column productview.warehouseManager not supported: 库存-库管员

-- comment on column productview.deliveryWarehouse not supported: 库存-发货仓库

-- comment on column productview.returnWarehouse not supported: 库存-退货仓库

-- comment on column productview.fInStoreExcessLimit not supported: 库存-入库超量上限%

-- comment on column productview.fOutStoreExcessLimit not supported: 库存-出库超量上限%

