create view shopproductview as
select `b`.`productId`                  AS `productId`,
       `b`.`iRangeType`                 AS `iRangeType`,
       `b`.`orgId`                      AS `orgId`,
       `b`.`customerId`                 AS `customerId`,
       `b`.`isCreator`                  AS `isCreator`,
       `b`.`id`                         AS `id`,
       `a`.`purchaseUnitId`             AS `purchaseUnitId`,
       `a`.`purchasePriceUnitId`        AS `purchasePriceUnitId`,
       `a`.`purchaseRate`               AS `purchaseRate`,
       `a`.`stockUnitId`                AS `stockUnitId`,
       `a`.`stockRate`                  AS `stockRate`,
       `a`.`batchUnitId`                AS `batchUnitId`,
       `a`.`batchRate`                  AS `batchRate`,
       `a`.`onlineUnitId`               AS `onlineUnitId`,
       `a`.`onlineRate`                 AS `onlineRate`,
       `a`.`offlineUnitId`              AS `offlineUnitId`,
       `a`.`offlineRate`                AS `offlineRate`,
       `a`.`requireUnitId`              AS `requireUnitId`,
       `a`.`requireRate`                AS `requireRate`,
       `a`.`batchPriceUnitId`           AS `batchPriceUnitId`,
       `a`.`batchPriceRate`             AS `batchPriceRate`,
       `a`.`batchPrice`                 AS `batchPrice`,
       `a`.`fMarkPrice`                 AS `fMarkPrice`,
       `a`.`fLowestMarkPrice`           AS `fLowestMarkPrice`,
       `a`.`fSalePrice`                 AS `fSalePrice`,
       `a`.`fMarketPrice`               AS `fMarketPrice`,
       `a`.`fPrimeCosts`                AS `fPrimeCosts`,
       `a`.`fSettleAccountsRate`        AS `fSettleAccountsRate`,
       `a`.`isDisplayPrice`             AS `isDisplayPrice`,
       `a`.`priceAreaMessage`           AS `priceAreaMessage`,
       `a`.`isBatchManage`              AS `isBatchManage`,
       `a`.`isExpiryDateManage`         AS `isExpiryDateManage`,
       `a`.`expireDateNo`               AS `expireDateNo`,
       `a`.`expireDateUnit`             AS `expireDateUnit`,
       `a`.`isSerialNoManage`           AS `isSerialNoManage`,
       `a`.`weight`                     AS `weight`,
       `a`.`volume`                     AS `volume`,
       `a`.`safetyStock`                AS `safetyStock`,
       `a`.`highestStock`               AS `highestStock`,
       `a`.`lowestStock`                AS `lowestStock`,
       `a`.`ropStock`                   AS `ropStock`,
       `a`.`canSale`                    AS `canSale`,
       `a`.`iMinOrderQuantity`          AS `iMinOrderQuantity`,
       `a`.`deliveryDays`               AS `deliveryDays`,
       `a`.`uorderDlyFeeRuleId`         AS `uorderDlyFeeRuleId`,
       `a`.`iEnableCyclePurchase`       AS `iEnableCyclePurchase`,
       `a`.`enableDeposit`              AS `enableDeposit`,
       `a`.`depositDealPayType`         AS `depositDealPayType`,
       `a`.`deposits`                   AS `deposits`,
       `a`.`depositPercentage`          AS `depositPercentage`,
       `a`.`enablemodifyDeposit`        AS `enablemodifyDeposit`,
       `a`.`minimumDeposits`            AS `minimumDeposits`,
       `a`.`depositPayType`             AS `depositPayType`,
       `a`.`pageTitle`                  AS `pageTitle`,
       `a`.`metaDescription`            AS `metaDescription`,
       `a`.`salePoints`                 AS `salePoints`,
       `a`.`lInventoryCount`            AS `lInventoryCount`,
       `a`.`dlyFeeRuleId`               AS `dlyFeeRuleId`,
       `a`.`iBaseSaleCount`             AS `iBaseSaleCount`,
       `a`.`isAllArea`                  AS `isAllArea`,
       `a`.`iEnableEcontract`           AS `iEnableEcontract`,
       `a`.`allowStorePurchase`         AS `allowStorePurchase`,
       `a`.`isPriceChangeAllowed`       AS `isPriceChangeAllowed`,
       `a`.`isSaleInOfflineStore`       AS `isSaleInOfflineStore`,
       `a`.`isOfflineStoreOrder`        AS `isOfflineStoreOrder`,
       `a`.`isOfflineStoreReturn`       AS `isOfflineStoreReturn`,
       `a`.`isWeight`                   AS `isWeight`,
       `a`.`isProcess`                  AS `isProcess`,
       `a`.`iProcessType`               AS `iProcessType`,
       `a`.`isMaterial`                 AS `isMaterial`,
       `a`.`retailPriceDimension`       AS `retailPriceDimension`,
       `a`.`fNoTaxCostPrice`            AS `fNoTaxCostPrice`,
       `a`.`checkByBatch`               AS `checkByBatch`,
       `a`.`iStatus`                    AS `iStatus`,
       `a`.`iUOrderStatus`              AS `iUOrderStatus`,
       `a`.`mallUpTime`                 AS `mallUpTime`,
       `a`.`uorderUpTime`               AS `uorderUpTime`,
       `a`.`mallupcount`                AS `mallupcount`,
       `a`.`malldowncount`              AS `malldowncount`,
       `a`.`uorderupcount`              AS `uorderupcount`,
       `a`.`uorderdowncount`            AS `uorderdowncount`,
       `a`.`minBatchPrice`              AS `minBatchPrice`,
       `a`.`maxBatchPrice`              AS `maxBatchPrice`,
       `a`.`pubts`                      AS `pubts`,
       `b`.`tenant_id`                  AS `tenant_id`,
       `a`.`saleChannel`                AS `saleChannel`,
       `a`.`saleChannelOfOnlineBatch`   AS `saleChannelOfOnlineBatch`,
       `a`.`saleChannelOfOnlineRetail`  AS `saleChannelOfOnlineRetail`,
       `a`.`saleChannelOfOfflineRetail` AS `saleChannelOfOfflineRetail`,
       `a`.`saleChannelOfDistribution`  AS `saleChannelOfDistribution`,
       `a`.`cbarcode`                   AS `cbarcode`,
       `a`.`stopstatus`                 AS `stopstatus`,
       `a`.`stop_time`                  AS `stop_time`,
       `a`.`isCheckFree`                AS `isCheckFree`,
       `a`.`inTaxrate`                  AS `inTaxrate`,
       `a`.`outTaxrate`                 AS `outTaxrate`,
       `a`.`businessAttribute`          AS `businessAttribute`,
       `a`.`fInStoreExcessLimit`        AS `fInStoreExcessLimit`,
       `a`.`fOutStoreExcessLimit`       AS `fOutStoreExcessLimit`,
       NULL                             AS `deliverQuantityChange`
from (`ugoods`.`productapplyrange` `b`
         left join `ugoods`.`productapplyrangedetail` `a` on ((`a`.`id` = `b`.`id`)));

-- comment on column shopproductview.productId not supported: 所属商品

-- comment on column shopproductview.iRangeType not supported: 商品适用范围类型

-- comment on column shopproductview.customerId not supported: 客户ID

-- comment on column shopproductview.isCreator not supported: 是否创建者

-- comment on column shopproductview.id not supported: ID

-- comment on column shopproductview.purchaseUnitId not supported: 采购单位

-- comment on column shopproductview.purchasePriceUnitId not supported: 采购计价单位

-- comment on column shopproductview.purchaseRate not supported: 采购单位换算率

-- comment on column shopproductview.stockUnitId not supported: 库存单位

-- comment on column shopproductview.stockRate not supported: 库存单位换算率

-- comment on column shopproductview.batchUnitId not supported: 批发单位

-- comment on column shopproductview.batchRate not supported: 批发单位换算率

-- comment on column shopproductview.onlineUnitId not supported: 线上零售单位

-- comment on column shopproductview.onlineRate not supported: 线上零售单位换算率

-- comment on column shopproductview.offlineUnitId not supported: 线下零售单位

-- comment on column shopproductview.offlineRate not supported: 线下零售单位换算率

-- comment on column shopproductview.requireUnitId not supported: 要货单位

-- comment on column shopproductview.requireRate not supported: 要货单位换算率

-- comment on column shopproductview.batchPriceUnitId not supported: 批发报价单位

-- comment on column shopproductview.batchPriceRate not supported: 批发报价单位换算率

-- comment on column shopproductview.batchPrice not supported: 批发价

-- comment on column shopproductview.fMarkPrice not supported: 建议零售价

-- comment on column shopproductview.fLowestMarkPrice not supported: 最低零售价

-- comment on column shopproductview.fSalePrice not supported: 线上零售价

-- comment on column shopproductview.fMarketPrice not supported: 市场价

-- comment on column shopproductview.fSettleAccountsRate not supported: 结算费率

-- comment on column shopproductview.isDisplayPrice not supported: 线上商城显示价格

-- comment on column shopproductview.priceAreaMessage not supported: 线上不显示价格时，需要显示的提示信息

-- comment on column shopproductview.isBatchManage not supported: 库存-是否批次管理

-- comment on column shopproductview.isExpiryDateManage not supported: 库存-是否有效期管理

-- comment on column shopproductview.expireDateNo not supported: 库存-保质期

-- comment on column shopproductview.expireDateUnit not supported: 库存-保质期单位

-- comment on column shopproductview.isSerialNoManage not supported: 库存-是否序列号管理

-- comment on column shopproductview.weight not supported: 库存-重量

-- comment on column shopproductview.volume not supported: 库存-体积

-- comment on column shopproductview.safetyStock not supported: 库存-安全库存

-- comment on column shopproductview.highestStock not supported: 库存-最高库存

-- comment on column shopproductview.lowestStock not supported: 库存-最低库存

-- comment on column shopproductview.ropStock not supported: 库存-再订货点

-- comment on column shopproductview.canSale not supported: 批发-可售状态

-- comment on column shopproductview.iMinOrderQuantity not supported: 批发-起订量

-- comment on column shopproductview.deliveryDays not supported: 批发-交货周期（天）

-- comment on column shopproductview.uorderDlyFeeRuleId not supported: 订货-运费模板

-- comment on column shopproductview.iEnableCyclePurchase not supported: 商城-启用周期购

-- comment on column shopproductview.enableDeposit not supported: 启用定金业务

-- comment on column shopproductview.depositDealPayType not supported: 商城-定金设置类型

-- comment on column shopproductview.deposits not supported: 商城-预付定金金额

-- comment on column shopproductview.depositPercentage not supported: 商城-预付定金百分比

-- comment on column shopproductview.enablemodifyDeposit not supported: 商城-订单改价时可修改定金

-- comment on column shopproductview.minimumDeposits not supported: 商城-最低定金金额

-- comment on column shopproductview.depositPayType not supported: 商城-支付尾款方式

-- comment on column shopproductview.pageTitle not supported: 商城-SEO设置相关

-- comment on column shopproductview.metaDescription not supported: 商城-搜索简介

-- comment on column shopproductview.lInventoryCount not supported: 商城-线上库存量

-- comment on column shopproductview.dlyFeeRuleId not supported: 商城-运费模板

-- comment on column shopproductview.iBaseSaleCount not supported: 商城-初始销量

-- comment on column shopproductview.isAllArea not supported: 商城-是否适用所有区域

-- comment on column shopproductview.iEnableEcontract not supported: 商城-是否启用合同管理

-- comment on column shopproductview.allowStorePurchase not supported: 零售-允许门店自采

-- comment on column shopproductview.isPriceChangeAllowed not supported: 零售-允许开单改价

-- comment on column shopproductview.isSaleInOfflineStore not supported: 零售-允许门店销售

-- comment on column shopproductview.isOfflineStoreOrder not supported: 零售-允许门店要货

-- comment on column shopproductview.isOfflineStoreReturn not supported: 零售-允许门店退货

-- comment on column shopproductview.isWeight not supported: 零售-是否称重

-- comment on column shopproductview.isProcess not supported: 零售-加工

-- comment on column shopproductview.isMaterial not supported: 零售-材料

-- comment on column shopproductview.retailPriceDimension not supported: 零售-零售取价维度

-- comment on column shopproductview.fNoTaxCostPrice not supported: 成本-参考成本

-- comment on column shopproductview.checkByBatch not supported: 成本-按批次核算

-- comment on column shopproductview.iStatus not supported: 商城上下架状态

-- comment on column shopproductview.iUOrderStatus not supported: U订货上下架状态

-- comment on column shopproductview.mallUpTime not supported: 商城上架时间

-- comment on column shopproductview.uorderUpTime not supported: U订货上架时间

-- comment on column shopproductview.mallupcount not supported: 商城上架数量

-- comment on column shopproductview.malldowncount not supported: 商城下架数量

-- comment on column shopproductview.uorderupcount not supported: U订货上架数量

-- comment on column shopproductview.uorderdowncount not supported: U订货下架数量

-- comment on column shopproductview.minBatchPrice not supported: 最低批发价格

-- comment on column shopproductview.maxBatchPrice not supported: 最高批发价格

-- comment on column shopproductview.pubts not supported: 时间戳

-- comment on column shopproductview.tenant_id not supported: 租户

-- comment on column shopproductview.saleChannel not supported: 销售渠道

-- comment on column shopproductview.saleChannelOfOnlineBatch not supported: 销售渠道-线上批发

-- comment on column shopproductview.saleChannelOfOnlineRetail not supported: 销售渠道-线上零售

-- comment on column shopproductview.saleChannelOfOfflineRetail not supported: 销售渠道-线下零售

-- comment on column shopproductview.saleChannelOfDistribution not supported: 销售渠道-微分销

-- comment on column shopproductview.stopstatus not supported: 停用状态

-- comment on column shopproductview.stop_time not supported: 停用时间

-- comment on column shopproductview.isCheckFree not supported: 成本-按规格核算成本

-- comment on column shopproductview.inTaxrate not supported: 进项税率

-- comment on column shopproductview.outTaxrate not supported: 销项税率

-- comment on column shopproductview.businessAttribute not supported: 业务属性

-- comment on column shopproductview.fInStoreExcessLimit not supported: 库存-入库超量上限%

-- comment on column shopproductview.fOutStoreExcessLimit not supported: 库存-出库超量上限%

