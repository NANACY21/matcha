create definer = root@`%` view user_org as
select 1 AS `user_id`, 1 AS `org_id`, 1 AS `id`, 1 AS `pubts`, 1 AS `isdefault`;

