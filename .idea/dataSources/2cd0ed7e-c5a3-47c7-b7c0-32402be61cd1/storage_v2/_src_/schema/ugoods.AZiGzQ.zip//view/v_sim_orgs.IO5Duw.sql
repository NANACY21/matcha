create definer = root@`%` view v_sim_orgs as
select 1 AS `id`, 1 AS `code`, 1 AS `name`, 1 AS `tenant_id`;

