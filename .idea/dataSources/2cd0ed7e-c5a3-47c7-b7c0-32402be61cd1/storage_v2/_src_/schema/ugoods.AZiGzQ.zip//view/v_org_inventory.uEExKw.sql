create definer = root@`%` view v_org_inventory as
select `iuap_cloud_basedoc`.`org_inventory`.`code`                                   AS `ccode`,
       `iuap_cloud_basedoc`.`org_inventory`.`name`                                   AS `cname`,
       `iuap_cloud_basedoc`.`org_inventory`.`name`                                   AS `cfullname`,
       `iuap_cloud_basedoc`.`org_inventory`.`displayorder`                           AS `isortnum`,
       0                                                                             AS `bisend`,
       NULL                                                                          AS `corgfuncid`,
       0                                                                             AS `bisglobal`,
       NULL                                                                          AS `cerpcode`,
       NULL                                                                          AS `ceaicode`,
       `iuap_cloud_basedoc`.`org_inventory`.`parentid`                               AS `iparentid`,
       (case `iuap_cloud_basedoc`.`org_inventory`.`enable` when 1 then 0 else 1 end) AS `bstopstatus`,
       NULL                                                                          AS `dstoptime`,
       `iuap_cloud_basedoc`.`org_inventory`.`creationtime`                           AS `dcreatetime`,
       `iuap_cloud_basedoc`.`org_inventory`.`creationtime`                           AS `dcreatedate`,
       `iuap_cloud_basedoc`.`org_inventory`.`modifiedtime`                           AS `dmodifytime`,
       `iuap_cloud_basedoc`.`org_inventory`.`modifiedtime`                           AS `dmodifydate`,
       `iuap_cloud_basedoc`.`org_inventory`.`creator`                                AS `ccreator`,
       `iuap_cloud_basedoc`.`org_inventory`.`modifier`                               AS `cmodifier`,
       `iuap_cloud_basedoc`.`org_inventory`.`creator`                                AS `creatorid`,
       `iuap_cloud_basedoc`.`org_inventory`.`modifier`                               AS `modifierid`,
       `iuap_cloud_basedoc`.`org_inventory`.`orgid`                                  AS `orgid`,
       `iuap_cloud_basedoc`.`org_inventory`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_inventory`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                        AS `tenant_id`,
       NULL                                                                          AS `customerid`,
       `iuap_cloud_basedoc`.`org_inventory`.`finorgid`                               AS `finorgid`,
       `iuap_cloud_basedoc`.`org_inventory`.`name2`                                  AS `cname2`,
       `iuap_cloud_basedoc`.`org_inventory`.`name3`                                  AS `cname3`,
       `iuap_cloud_basedoc`.`org_inventory`.`name4`                                  AS `cname4`,
       `iuap_cloud_basedoc`.`org_inventory`.`name5`                                  AS `cname5`,
       `iuap_cloud_basedoc`.`org_inventory`.`name6`                                  AS `cname6`,
       `iuap_cloud_basedoc`.`org_inventory`.`name2`                                  AS `cfullname2`,
       `iuap_cloud_basedoc`.`org_inventory`.`name3`                                  AS `cfullname3`,
       `iuap_cloud_basedoc`.`org_inventory`.`name4`                                  AS `cfullname4`,
       `iuap_cloud_basedoc`.`org_inventory`.`name5`                                  AS `cfullname5`,
       `iuap_cloud_basedoc`.`org_inventory`.`name6`                                  AS `cfullname6`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_inventory`
                   on ((`iuap_cloud_basedoc`.`org_inventory`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_inventory`.`dr` = 0);

-- comment on column v_org_inventory.ccode not supported: 编码

-- comment on column v_org_inventory.cname not supported: 名称

-- comment on column v_org_inventory.cfullname not supported: 名称

-- comment on column v_org_inventory.isortnum not supported: 显示顺序

-- comment on column v_org_inventory.iparentid not supported: 上级节点

-- comment on column v_org_inventory.dcreatetime not supported: 创建时间

-- comment on column v_org_inventory.dcreatedate not supported: 创建时间

-- comment on column v_org_inventory.dmodifytime not supported: 修改时间

-- comment on column v_org_inventory.dmodifydate not supported: 修改时间

-- comment on column v_org_inventory.ccreator not supported: 创建人

-- comment on column v_org_inventory.cmodifier not supported: 修改人

-- comment on column v_org_inventory.creatorid not supported: 创建人

-- comment on column v_org_inventory.modifierid not supported: 修改人

-- comment on column v_org_inventory.orgid not supported: 组织单元主键

-- comment on column v_org_inventory.id not supported: 主键

-- comment on column v_org_inventory.tenant_id not supported: ID

-- comment on column v_org_inventory.finorgid not supported: 关联财务组织主键

-- comment on column v_org_inventory.cname2 not supported: 英文

-- comment on column v_org_inventory.cname3 not supported: 中文繁体

-- comment on column v_org_inventory.cname4 not supported: 法语

-- comment on column v_org_inventory.cname5 not supported: 备用

-- comment on column v_org_inventory.cname6 not supported: 备用

-- comment on column v_org_inventory.cfullname2 not supported: 英文

-- comment on column v_org_inventory.cfullname3 not supported: 中文繁体

-- comment on column v_org_inventory.cfullname4 not supported: 法语

-- comment on column v_org_inventory.cfullname5 not supported: 备用

-- comment on column v_org_inventory.cfullname6 not supported: 备用

