create definer = root@`%` view v_depts1 as
select 1 AS `id`, 1 AS `tenant_id`;

