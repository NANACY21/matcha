create definer = root@`%` view v_org_sales as
select `iuap_cloud_basedoc`.`org_sales`.`code`                                   AS `ccode`,
       `iuap_cloud_basedoc`.`org_sales`.`name`                                   AS `cname`,
       `iuap_cloud_basedoc`.`org_sales`.`name`                                   AS `cfullname`,
       `iuap_cloud_basedoc`.`org_sales`.`displayorder`                           AS `isortnum`,
       0                                                                         AS `bisend`,
       NULL                                                                      AS `corgfuncid`,
       0                                                                         AS `bisglobal`,
       NULL                                                                      AS `cerpcode`,
       NULL                                                                      AS `ceaicode`,
       `iuap_cloud_basedoc`.`org_sales`.`parentid`                               AS `iparentid`,
       (case `iuap_cloud_basedoc`.`org_sales`.`enable` when 1 then 0 else 1 end) AS `bstopstatus`,
       NULL                                                                      AS `dstoptime`,
       `iuap_cloud_basedoc`.`org_sales`.`creationtime`                           AS `dcreatetime`,
       `iuap_cloud_basedoc`.`org_sales`.`creationtime`                           AS `dcreatedate`,
       `iuap_cloud_basedoc`.`org_sales`.`modifiedtime`                           AS `dmodifytime`,
       `iuap_cloud_basedoc`.`org_sales`.`modifiedtime`                           AS `dmodifydate`,
       `iuap_cloud_basedoc`.`org_sales`.`creator`                                AS `ccreator`,
       `iuap_cloud_basedoc`.`org_sales`.`modifier`                               AS `cmodifier`,
       `iuap_cloud_basedoc`.`org_sales`.`creator`                                AS `creatorid`,
       `iuap_cloud_basedoc`.`org_sales`.`modifier`                               AS `modifierid`,
       `iuap_cloud_basedoc`.`org_sales`.`orgid`                                  AS `orgid`,
       `iuap_cloud_basedoc`.`org_sales`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_sales`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                    AS `tenant_id`,
       NULL                                                                      AS `customerid`,
       `iuap_cloud_basedoc`.`org_sales`.`exchangerate`                           AS `exchangerate`,
       `iuap_cloud_basedoc`.`org_sales`.`name2`                                  AS `cname2`,
       `iuap_cloud_basedoc`.`org_sales`.`name3`                                  AS `cname3`,
       `iuap_cloud_basedoc`.`org_sales`.`name4`                                  AS `cname4`,
       `iuap_cloud_basedoc`.`org_sales`.`name5`                                  AS `cname5`,
       `iuap_cloud_basedoc`.`org_sales`.`name6`                                  AS `cname6`,
       `iuap_cloud_basedoc`.`org_sales`.`name2`                                  AS `cfullname2`,
       `iuap_cloud_basedoc`.`org_sales`.`name3`                                  AS `cfullname3`,
       `iuap_cloud_basedoc`.`org_sales`.`name4`                                  AS `cfullname4`,
       `iuap_cloud_basedoc`.`org_sales`.`name5`                                  AS `cfullname5`,
       `iuap_cloud_basedoc`.`org_sales`.`name6`                                  AS `cfullname6`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_sales`
                   on ((`iuap_cloud_basedoc`.`org_sales`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_sales`.`dr` = 0);

-- comment on column v_org_sales.ccode not supported: 编码

-- comment on column v_org_sales.cname not supported: 名称

-- comment on column v_org_sales.cfullname not supported: 名称

-- comment on column v_org_sales.isortnum not supported: 显示顺序

-- comment on column v_org_sales.iparentid not supported: 上级节点

-- comment on column v_org_sales.dcreatetime not supported: 创建时间

-- comment on column v_org_sales.dcreatedate not supported: 创建时间

-- comment on column v_org_sales.dmodifytime not supported: 修改时间

-- comment on column v_org_sales.dmodifydate not supported: 修改时间

-- comment on column v_org_sales.ccreator not supported: 创建人

-- comment on column v_org_sales.cmodifier not supported: 修改人

-- comment on column v_org_sales.creatorid not supported: 创建人

-- comment on column v_org_sales.modifierid not supported: 修改人

-- comment on column v_org_sales.orgid not supported: 组织单元主键

-- comment on column v_org_sales.id not supported: 主键

-- comment on column v_org_sales.tenant_id not supported: ID

-- comment on column v_org_sales.exchangerate not supported: 汇率类型

-- comment on column v_org_sales.cname2 not supported: 英文

-- comment on column v_org_sales.cname3 not supported: 中文繁体

-- comment on column v_org_sales.cname4 not supported: 法语

-- comment on column v_org_sales.cname5 not supported: 备用

-- comment on column v_org_sales.cname6 not supported: 备用

-- comment on column v_org_sales.cfullname2 not supported: 英文

-- comment on column v_org_sales.cfullname3 not supported: 中文繁体

-- comment on column v_org_sales.cfullname4 not supported: 法语

-- comment on column v_org_sales.cfullname5 not supported: 备用

-- comment on column v_org_sales.cfullname6 not supported: 备用

