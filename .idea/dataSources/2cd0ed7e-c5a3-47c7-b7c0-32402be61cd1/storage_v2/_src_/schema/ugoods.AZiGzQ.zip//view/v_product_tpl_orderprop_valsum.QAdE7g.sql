create definer = root@`%` view v_product_tpl_orderprop_valsum as
select `p`.`id` AS `id`, group_concat(`v`.`value` separator '; ') AS `values`
from (`ugoods`.`product_tpl_orderprop` `p`
         left join `ugoods`.`product_tpl_orderprop_value` `v` on ((`p`.`id` = `v`.`property_id`)))
group by `p`.`id`;

-- comment on column v_product_tpl_orderprop_valsum.id not supported: ID

