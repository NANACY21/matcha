create definer = root@`%` view v_depts as
select `iuap_cloud_basedoc`.`org_admin`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_admin`.`ts`                                     AS `ts`,
       `iuap_cloud_basedoc`.`org_admin`.`code`                                   AS `ccode`,
       `iuap_cloud_basedoc`.`org_admin`.`name`                                   AS `cfullname`,
       `iuap_cloud_basedoc`.`org_admin`.`name2`                                  AS `cfullname2`,
       `iuap_cloud_basedoc`.`org_admin`.`name3`                                  AS `cfullname3`,
       `iuap_cloud_basedoc`.`org_admin`.`name4`                                  AS `cfullname4`,
       `iuap_cloud_basedoc`.`org_admin`.`name5`                                  AS `cfullname5`,
       `iuap_cloud_basedoc`.`org_admin`.`name6`                                  AS `cfullname6`,
       `iuap_cloud_basedoc`.`org_admin`.`name`                                   AS `cname`,
       `iuap_cloud_basedoc`.`org_admin`.`name2`                                  AS `cname2`,
       `iuap_cloud_basedoc`.`org_admin`.`name3`                                  AS `cname3`,
       `iuap_cloud_basedoc`.`org_admin`.`name4`                                  AS `cname4`,
       `iuap_cloud_basedoc`.`org_admin`.`name5`                                  AS `cname5`,
       `iuap_cloud_basedoc`.`org_admin`.`name6`                                  AS `cname6`,
       (case
            when (`iuap_cloud_basedoc`.`org_admin`.`parentid` = '') then NULL
            else `iuap_cloud_basedoc`.`org_admin`.`parentid` end)                AS `iparentid`,
       `iuap_cloud_basedoc`.`org_admin`.`level`                                  AS `igrade`,
       `iuap_cloud_basedoc`.`org_admin`.`creationtime`                           AS `dcreatetime`,
       `iuap_cloud_basedoc`.`org_admin`.`creationtime`                           AS `dcreatedate`,
       `iuap_cloud_basedoc`.`org_admin`.`modifiedtime`                           AS `dmodifytime`,
       `iuap_cloud_basedoc`.`org_admin`.`modifiedtime`                           AS `dmodifydate`,
       `iuap_cloud_basedoc`.`org_admin`.`creator`                                AS `ccreator`,
       `iuap_cloud_basedoc`.`org_admin`.`modifier`                               AS `cmodifier`,
       `iuap_cloud_basedoc`.`org_admin`.`creator`                                AS `creatorid`,
       `iuap_cloud_basedoc`.`org_admin`.`modifier`                               AS `modifierid`,
       `iuap_cloud_basedoc`.`org_admin`.`isEnd`                                  AS `bisend`,
       `iuap_cloud_basedoc`.`org_admin`.`displayorder`                           AS `isortnum`,
       `iuap_cloud_basedoc`.`org_admin`.`depttype`                               AS `depttype`,
       `iuap_cloud_basedoc`.`org_admin`.`principal`                              AS `principal`,
       NULL                                                                      AS `isupparentid`,
       NULL                                                                      AS `cerpcode`,
       `iuap_cloud_basedoc`.`org_admin`.`parentorgid`                            AS `iorgid`,
       (case `iuap_cloud_basedoc`.`org_admin`.`enable` when 1 then 0 else 1 end) AS `bstopstatus`,
       NULL                                                                      AS `dstoptime`,
       NULL                                                                      AS `cmemo`,
       NULL                                                                      AS `icorpid`,
       NULL                                                                      AS `cappid`,
       `ugoods`.`tenant`.`id`                                                    AS `tenant_id`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`org_admin`
              on ((`iuap_cloud_basedoc`.`org_admin`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where ((`iuap_cloud_basedoc`.`org_admin`.`orgtype` = 2) and (`iuap_cloud_basedoc`.`org_admin`.`dr` = 0) and
       (`iuap_cloud_basedoc`.`org_admin`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`));

-- comment on column v_depts.id not supported: 主键

-- comment on column v_depts.igrade not supported: 层级

-- comment on column v_depts.dcreatetime not supported: 创建时间

-- comment on column v_depts.dcreatedate not supported: 创建时间

-- comment on column v_depts.dmodifytime not supported: 修改时间

-- comment on column v_depts.dmodifydate not supported: 修改时间

-- comment on column v_depts.ccreator not supported: 创建者

-- comment on column v_depts.cmodifier not supported: 修改人

-- comment on column v_depts.creatorid not supported: 创建者

-- comment on column v_depts.modifierid not supported: 修改人

-- comment on column v_depts.isortnum not supported: 显示顺序

-- comment on column v_depts.depttype not supported: 部门性质

-- comment on column v_depts.principal not supported: 负责人

-- comment on column v_depts.iorgid not supported: 上级主键ID

-- comment on column v_depts.tenant_id not supported: ID

