create view v_operators1 as
select `iuap_cloud_basedoc`.`bd_staff`.`code`                                   AS `cCode`,
       `iuap_cloud_basedoc`.`bd_staff`.`name`                                   AS `cName`,
       `ugoods`.`tenant`.`id`                                                   AS `tenant_id`,
       `iuap_cloud_basedoc`.`bd_staff`.`ts`                                     AS `pubts`,
       `iuap_cloud_basedoc`.`bd_staff`.`photo`                                  AS `cHeadPicUrl`,
       `iuap_cloud_basedoc`.`bd_staff`.`mobile`                                 AS `cPhone`,
       `iuap_cloud_basedoc`.`bd_staff`.`email`                                  AS `cEmail`,
       NULL                                                                     AS `cErpCode`,
       NULL                                                                     AS `iPosition`,
       (case `iuap_cloud_basedoc`.`bd_staff`.`enable` when 1 then 1 else 0 end) AS `iStatus`,
       NULL                                                                     AS `iAuditStatus`,
       `iuap_cloud_basedoc`.`bd_staff`.`joinworkdate`                           AS `dEntryTime`,
       NULL                                                                     AS `dLeaveTime`,
       NULL                                                                     AS `iDepartmentID`,
       NULL                                                                     AS `cIntro`,
       NULL                                                                     AS `cYxyUserId`,
       `iuap_cloud_basedoc`.`bd_staff`.`creationtime`                           AS `dCreateTime`,
       `iuap_cloud_basedoc`.`bd_staff`.`modifiedtime`                           AS `dUpdateTime`,
       `iuap_cloud_basedoc`.`bd_staff`.`sex`                                    AS `iGender`,
       `iuap_cloud_basedoc`.`bd_staff`.`id`                                     AS `id`,
       NULL                                                                     AS `create_date`,
       NULL                                                                     AS `modify_date`,
       `iuap_cloud_basedoc`.`bd_staff`.`creator`                                AS `creator`,
       `iuap_cloud_basedoc`.`bd_staff`.`modifier`                               AS `modifier`,
       NULL                                                                     AS `cAppID`,
       `iuap_cloud_basedoc`.`bd_staff`.`user_id`                                AS `userId`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`bd_staff`
                   on ((`iuap_cloud_basedoc`.`bd_staff`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where ((`iuap_cloud_basedoc`.`bd_staff`.`dr` = 0) and
       (`iuap_cloud_basedoc`.`bd_staff`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`));

-- comment on column v_operators1.tenant_id not supported: ID

-- comment on column v_operators1.cHeadPicUrl not supported: 头像

-- comment on column v_operators1.cPhone not supported: 手机号

-- comment on column v_operators1.cEmail not supported: 邮箱

-- comment on column v_operators1.dEntryTime not supported: 参加工作日期

-- comment on column v_operators1.dCreateTime not supported: 创建时间

-- comment on column v_operators1.dUpdateTime not supported: 修改时间

-- comment on column v_operators1.iGender not supported: 性别

-- comment on column v_operators1.id not supported: 主键

-- comment on column v_operators1.creator not supported: 创建者

-- comment on column v_operators1.modifier not supported: 修改人

-- comment on column v_operators1.userId not supported: 关联用户

