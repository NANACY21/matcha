create definer = root@`%` view v_product_tpl_list as
select `tpl`.`id` AS `id`, `tpl`.`pubts` AS `pubts`, `brandsum`.`brand_name` AS `brand_name`
from (`ugoods`.`product_tpl` `tpl`
         left join `ugoods`.`v_product_tpl_brand_sum` `brandsum` on ((`tpl`.`id` = `brandsum`.`type_id`)));

-- comment on column v_product_tpl_list.id not supported: ID

-- comment on column v_product_tpl_list.pubts not supported: 时间戳

