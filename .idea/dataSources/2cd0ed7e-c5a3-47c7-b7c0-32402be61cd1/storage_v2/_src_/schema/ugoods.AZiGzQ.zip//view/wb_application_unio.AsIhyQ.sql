create view wb_application_unio as
select 1 AS `id`,
       1 AS `tenant_id`,
       1 AS `pubts`,
       1 AS `systemCode`,
       1 AS `systemLOGO`,
       1 AS `systemName`,
       1 AS `iDeleted`,
       1 AS `orderNumber`;

