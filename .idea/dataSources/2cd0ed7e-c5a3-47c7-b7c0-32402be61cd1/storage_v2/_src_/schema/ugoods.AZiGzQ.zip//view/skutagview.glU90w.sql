create view skutagview as
select `a`.`skuId` AS `skuId`, `a`.`tagId` AS `tagId`, `a`.`id` AS `id`, `a`.`tenant_id` AS `tenant_id`
from `ugoods`.`skutag` `a`
union
select `b`.`skuId` AS `skuId`, `b`.`tagId` AS `tagId`, `b`.`id` AS `id`, `b`.`tenant_id` AS `tenant_id`
from `ugoods`.`skutagextend` `b`;

