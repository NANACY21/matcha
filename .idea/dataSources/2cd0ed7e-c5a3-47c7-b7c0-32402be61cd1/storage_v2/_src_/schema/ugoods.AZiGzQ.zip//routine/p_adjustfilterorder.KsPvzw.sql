create
    definer = root@`%` procedure p_adjustfilterorder(IN cfilterName varchar(50))
begin 

declare done int default 0;
declare successCount int default 0;
declare warningCount int default 0;
declare errorCount int default 0;
declare skipCount int default 0;
declare tenantid BIGINT; -- 外层游标获取的id
declare isolutionId BIGINT; -- 内层游标获取的id
declare startIndex int default 0; -- 标记字段开始序号

declare outer_cur cursor for select id from tenant where isopen=1;
declare inner_cur cursor for select sol.id from pb_filter_solution sol inner join pb_meta_filters fil on fil.id = sol.filtersId where fil.filterName = cfilterName and sol.tenant_id = tenantid;

declare continue HANDLER for not found set done = 1;

open outer_cur;
	outer_loop:Loop
		fetch outer_cur into tenantid;
		if done then 
			leave outer_loop;
		end if;

		open inner_cur;
			inner_loop:Loop
				fetch inner_cur into isolutionId;
				if done then
					leave inner_loop;
				end if;

				select MIN(orderId) into startIndex from pb_filter_solution_common where solutionId = isolutionId and tenant_id = tenantid;
				-- select tenantid;
				-- select isolutionId;
				-- select startIndex;
				if startIndex is null then
					set errorCount = errorCount + 1;
				elseif startIndex = 0 then 
					set startIndex = 0;
					set warningCount = warningCount + 1;
					set successCount = successCount + 1;
					update pb_filter_solution_common set orderId = case when orderId = 0 then 1 else orderId * 10 end where solutionId = isolutionId and tenant_id = tenantid order by orderId;
				elseif startIndex < 10 then
					set startIndex = 0;
					set successCount = successCount + 1;
					update pb_filter_solution_common set orderId = orderId * 10 where solutionId = isolutionId and tenant_id = tenantid order by orderId;
				else 
					set skipCount = skipCount + 1;
				end if;

		end Loop inner_loop;
		close inner_cur;
		set done = 0;
	end Loop outer_loop;
close outer_cur;

-- 0租户数据单独执行
select MIN(com.orderId) into startIndex from pb_filter_solution_common com
inner join pb_filter_solution sol on sol.id = com.solutionId and sol.tenant_id = com.tenant_id and sol.tenant_id = 0
inner join pb_meta_filters fil on fil.id = sol.filtersId
where fil.filterName = cfilterName;

if startIndex is null then
	set errorCount = errorCount + 1;
elseif startIndex = 0 then 
	set warningCount = warningCount + 1;
	set successCount = successCount + 1;
	update pb_filter_solution_common com 
	inner join pb_filter_solution sol on sol.id = com.solutionId and sol.tenant_id = com.tenant_id and sol.tenant_id = 0
	inner join pb_meta_filters fil on fil.id = sol.filtersId
	set com.orderId = case when com.orderId = 0 then 1 else com.orderId * 10 end
	where fil.filterName = cfilterName;
elseif startIndex < 10 then
	set successCount = successCount + 1;
	update pb_filter_solution_common com 
	inner join pb_filter_solution sol on sol.id = com.solutionId and sol.tenant_id = com.tenant_id and sol.tenant_id = 0
	inner join pb_meta_filters fil on fil.id = sol.filtersId
	set com.orderId = com.orderId * 10 
	where fil.filterName = cfilterName;
else 
	set skipCount = skipCount + 1;
end if;


select done as '执行完成';
select successCount as '成功条数';
select warningCount as '警告条数（起始order为0）';
select errorCount as '错误条数（起始order为null）';
select skipCount as '跳过条数（已执行过）';
end;

