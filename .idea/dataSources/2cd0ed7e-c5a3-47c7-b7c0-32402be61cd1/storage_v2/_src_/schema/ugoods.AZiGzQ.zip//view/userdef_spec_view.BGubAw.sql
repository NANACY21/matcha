create definer = root@`%` view userdef_spec_view as
select `t`.`id`            AS `id`,
       `t`.`classname`     AS `classname`,
       `t`.`classId`       AS `classId`,
       `t`.`defineId`      AS `defineId`,
       `t`.`type`          AS `type`,
       `t`.`item`          AS `item`,
       `t`.`showitem`      AS `showitem`,
       `t`.`length`        AS `length`,
       `t`.`maxinputlen`   AS `maxinputlen`,
       `t`.`decimaldigits` AS `decimaldigits`,
       `t`.`ismultisel`    AS `ismultisel`,
       `t`.`isinput`       AS `isserinput`,
       `t`.`isenabled`     AS `isenabled`,
       `t`.`tenant_id`     AS `tenant_id`,
       `t`.`pubts`         AS `pubts`,
       `t`.`iswebshow`     AS `iswebshow`,
       `t`.`ordernum`      AS `ordernum`,
       `t`.`iDeleted`      AS `isdeleted`,
       `t`.`propertytype`  AS `propertytype`,
       `t`.`defineIdOther` AS `defineIdOther`,
       `t`.`userdef_desc`  AS `userdef_desc`,
       `t`.`userdef_alias` AS `userdef_alias`,
       `t`.`userdef_mode`  AS `userdef_mode`,
       `t`.`iswebinput`    AS `iswebinput`,
       `t`.`erp_code`      AS `erp_code`,
       `t`.`sourcetype`    AS `sourcetype`,
       `v`.`userdefid`     AS `userdefid`,
       `v`.`erpNameList`   AS `erpNameList`,
       `v`.`nameList`      AS `nameList`
from (`ugoods`.`userdef_base` `t`
         left join `ugoods`.`userdefine_view` `v` on ((`v`.`userdefid` = `t`.`id`)));

-- comment on column userdef_spec_view.id not supported: 主键

-- comment on column userdef_spec_view.classname not supported: 分类

-- comment on column userdef_spec_view.classId not supported: 项目号

-- comment on column userdef_spec_view.defineId not supported: 与bill里的自定义项保持一致

-- comment on column userdef_spec_view.type not supported: 数据类型

-- comment on column userdef_spec_view.item not supported: 属性来源

-- comment on column userdef_spec_view.showitem not supported: 显示名称

-- comment on column userdef_spec_view.length not supported: 长度

-- comment on column userdef_spec_view.maxinputlen not supported: 控制录入长度

-- comment on column userdef_spec_view.decimaldigits not supported: 小数位

-- comment on column userdef_spec_view.ismultisel not supported: 是否复选

-- comment on column userdef_spec_view.isserinput not supported: 管理端必输

-- comment on column userdef_spec_view.isenabled not supported: 是否启用

-- comment on column userdef_spec_view.tenant_id not supported: 租户ID

-- comment on column userdef_spec_view.pubts not supported: 时间戳

-- comment on column userdef_spec_view.iswebshow not supported: 前端显示

-- comment on column userdef_spec_view.isdeleted not supported: 是否删除

-- comment on column userdef_spec_view.userdef_desc not supported: 备注

-- comment on column userdef_spec_view.userdef_alias not supported: 属性别名

-- comment on column userdef_spec_view.userdef_mode not supported: 录入方式

-- comment on column userdef_spec_view.iswebinput not supported: 前端必输

-- comment on column userdef_spec_view.erp_code not supported: 对应ERP中的规格字段名称

-- comment on column userdef_spec_view.sourcetype not supported: 1系统预置，0自定义

