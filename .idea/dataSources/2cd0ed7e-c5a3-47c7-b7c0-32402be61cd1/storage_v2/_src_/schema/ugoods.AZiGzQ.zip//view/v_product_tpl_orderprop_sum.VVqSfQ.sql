create definer = root@`%` view v_product_tpl_orderprop_sum as
select `prop`.`tpl_id`        AS `tpl_id`,
       `prop`.`propertyType`  AS `propertyType`,
       `prop`.`propertyAlias` AS `propertyAlias`,
       `prop`.`isShow`        AS `isShow`,
       `prop`.`isWebRequired` AS `isWebRequired`,
       `prop`.`id`            AS `id`,
       `prop`.`pubts`         AS `pubts`,
       `prop`.`iDeleted`      AS `isDeleted`,
       `prop`.`ordernumber`   AS `ordernumber`,
       `prop`.`iLimitNum`     AS `iLimitNum`,
       `vals`.`values`        AS `values`
from (`ugoods`.`product_tpl_orderprop` `prop`
         left join `ugoods`.`v_product_tpl_orderprop_valsum` `vals` on ((`prop`.`id` = `vals`.`id`)));

-- comment on column v_product_tpl_orderprop_sum.tpl_id not supported: 商品模板

-- comment on column v_product_tpl_orderprop_sum.propertyType not supported: 属性名称

-- comment on column v_product_tpl_orderprop_sum.propertyAlias not supported: 属性别名

-- comment on column v_product_tpl_orderprop_sum.isShow not supported: 前端显示

-- comment on column v_product_tpl_orderprop_sum.isWebRequired not supported: 前端必输

-- comment on column v_product_tpl_orderprop_sum.id not supported: ID

-- comment on column v_product_tpl_orderprop_sum.pubts not supported: 时间戳

-- comment on column v_product_tpl_orderprop_sum.isDeleted not supported: 逻辑删除标记

-- comment on column v_product_tpl_orderprop_sum.ordernumber not supported: 排序

