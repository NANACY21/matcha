create definer = root@`%` view v_orgs as
select `iuap_cloud_basedoc`.`org_orgs`.`code`                                   AS `ccode`,
       `iuap_cloud_basedoc`.`org_orgs`.`name`                                   AS `cname`,
       `iuap_cloud_basedoc`.`org_orgs`.`name`                                   AS `cfullname`,
       1                                                                        AS `ilevel`,
       concat(`iuap_cloud_basedoc`.`org_orgs`.`id`, '|')                        AS `cpath`,
       `iuap_cloud_basedoc`.`org_orgs`.`displayorder`                           AS `isortnum`,
       0                                                                        AS `bisend`,
       NULL                                                                     AS `corgfuncid`,
       0                                                                        AS `bisglobal`,
       NULL                                                                     AS `cerpcode`,
       NULL                                                                     AS `ceaicode`,
       (case
            when ((('' = `iuap_cloud_basedoc`.`org_orgs`.`parentid`) or
                   isnull(`iuap_cloud_basedoc`.`org_orgs`.`parentid`)) and
                  (`iuap_cloud_basedoc`.`org_orgs`.`id` <> '666666')) then '666666'
            when ('' = `iuap_cloud_basedoc`.`org_orgs`.`parentid`) then NULL
            else `iuap_cloud_basedoc`.`org_orgs`.`parentid` end)                AS `iparentid`,
       (case `iuap_cloud_basedoc`.`org_orgs`.`enable` when 1 then 0 else 1 end) AS `bstopstatus`,
       NULL                                                                     AS `dstoptime`,
       `iuap_cloud_basedoc`.`org_orgs`.`creationtime`                           AS `dcreatetime`,
       `iuap_cloud_basedoc`.`org_orgs`.`creationtime`                           AS `dcreatedate`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifiedtime`                           AS `dmodifytime`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifiedtime`                           AS `dmodifydate`,
       `iuap_cloud_basedoc`.`org_orgs`.`creator`                                AS `ccreator`,
       `iuap_cloud_basedoc`.`org_orgs`.`modifier`                               AS `cmodifier`,
       NULL                                                                     AS `creatorid`,
       NULL                                                                     AS `modifierid`,
       `iuap_cloud_basedoc`.`org_orgs`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_orgs`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                   AS `tenant_id`,
       NULL                                                                     AS `customerid`,
       NULL                                                                     AS `orgtypeid`,
       `iuap_cloud_basedoc`.`org_orgs`.`principal`                              AS `principal`,
       `iuap_cloud_basedoc`.`org_orgs`.`name2`                                  AS `cname2`,
       `iuap_cloud_basedoc`.`org_orgs`.`name3`                                  AS `cname3`,
       `iuap_cloud_basedoc`.`org_orgs`.`name4`                                  AS `cname4`,
       `iuap_cloud_basedoc`.`org_orgs`.`name5`                                  AS `cname5`,
       `iuap_cloud_basedoc`.`org_orgs`.`name6`                                  AS `cname6`,
       `iuap_cloud_basedoc`.`org_orgs`.`name2`                                  AS `cfullname2`,
       `iuap_cloud_basedoc`.`org_orgs`.`name3`                                  AS `cfullname3`,
       `iuap_cloud_basedoc`.`org_orgs`.`name4`                                  AS `cfullname4`,
       `iuap_cloud_basedoc`.`org_orgs`.`name5`                                  AS `cfullname5`,
       `iuap_cloud_basedoc`.`org_orgs`.`name6`                                  AS `cfullname6`
from (`ugoods`.`tenant`
         join `iuap_cloud_basedoc`.`org_orgs`
              on ((`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where ((`iuap_cloud_basedoc`.`org_orgs`.`dr` = 0) and (`iuap_cloud_basedoc`.`org_orgs`.`is_biz_unit` = 1) and
       (`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`));

-- comment on column v_orgs.isortnum not supported: 显示顺序

-- comment on column v_orgs.dcreatetime not supported: 创建时间

-- comment on column v_orgs.dcreatedate not supported: 创建时间

-- comment on column v_orgs.dmodifytime not supported: 修改时间

-- comment on column v_orgs.dmodifydate not supported: 修改时间

-- comment on column v_orgs.ccreator not supported: 创建者

-- comment on column v_orgs.cmodifier not supported: 修改人

-- comment on column v_orgs.id not supported: 主键

-- comment on column v_orgs.tenant_id not supported: ID

-- comment on column v_orgs.principal not supported: 负责人

