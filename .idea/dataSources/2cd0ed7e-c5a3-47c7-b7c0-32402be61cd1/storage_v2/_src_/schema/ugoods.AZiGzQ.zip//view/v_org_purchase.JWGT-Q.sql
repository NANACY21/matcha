create definer = root@`%` view v_org_purchase as
select `iuap_cloud_basedoc`.`org_purchase`.`code`                                   AS `ccode`,
       `iuap_cloud_basedoc`.`org_purchase`.`name`                                   AS `cname`,
       `iuap_cloud_basedoc`.`org_purchase`.`name`                                   AS `cfullname`,
       `iuap_cloud_basedoc`.`org_purchase`.`displayorder`                           AS `isortnum`,
       0                                                                            AS `bisend`,
       NULL                                                                         AS `corgfuncid`,
       0                                                                            AS `bisglobal`,
       NULL                                                                         AS `cerpcode`,
       NULL                                                                         AS `ceaicode`,
       `iuap_cloud_basedoc`.`org_purchase`.`parentid`                               AS `iparentid`,
       (case `iuap_cloud_basedoc`.`org_purchase`.`enable` when 1 then 0 else 1 end) AS `bstopstatus`,
       NULL                                                                         AS `dstoptime`,
       `iuap_cloud_basedoc`.`org_purchase`.`creationtime`                           AS `dcreatetime`,
       `iuap_cloud_basedoc`.`org_purchase`.`creationtime`                           AS `dcreatedate`,
       `iuap_cloud_basedoc`.`org_purchase`.`modifiedtime`                           AS `dmodifytime`,
       `iuap_cloud_basedoc`.`org_purchase`.`modifiedtime`                           AS `dmodifydate`,
       `iuap_cloud_basedoc`.`org_purchase`.`creator`                                AS `ccreator`,
       `iuap_cloud_basedoc`.`org_purchase`.`modifier`                               AS `cmodifier`,
       `iuap_cloud_basedoc`.`org_purchase`.`creator`                                AS `creatorid`,
       `iuap_cloud_basedoc`.`org_purchase`.`modifier`                               AS `modifierid`,
       `iuap_cloud_basedoc`.`org_purchase`.`orgid`                                  AS `orgid`,
       `iuap_cloud_basedoc`.`org_purchase`.`id`                                     AS `id`,
       `iuap_cloud_basedoc`.`org_purchase`.`ts`                                     AS `pubts`,
       `ugoods`.`tenant`.`id`                                                       AS `tenant_id`,
       NULL                                                                         AS `customerid`,
       `iuap_cloud_basedoc`.`org_purchase`.`name2`                                  AS `cname2`,
       `iuap_cloud_basedoc`.`org_purchase`.`name3`                                  AS `cname3`,
       `iuap_cloud_basedoc`.`org_purchase`.`name4`                                  AS `cname4`,
       `iuap_cloud_basedoc`.`org_purchase`.`name5`                                  AS `cname5`,
       `iuap_cloud_basedoc`.`org_purchase`.`name6`                                  AS `cname6`,
       `iuap_cloud_basedoc`.`org_purchase`.`name2`                                  AS `cfullname2`,
       `iuap_cloud_basedoc`.`org_purchase`.`name3`                                  AS `cfullname3`,
       `iuap_cloud_basedoc`.`org_purchase`.`name4`                                  AS `cfullname4`,
       `iuap_cloud_basedoc`.`org_purchase`.`name5`                                  AS `cfullname5`,
       `iuap_cloud_basedoc`.`org_purchase`.`name6`                                  AS `cfullname6`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_purchase`
                   on ((`iuap_cloud_basedoc`.`org_purchase`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_purchase`.`dr` = 0);

-- comment on column v_org_purchase.isortnum not supported: 显示顺序

-- comment on column v_org_purchase.iparentid not supported: 上级节点

-- comment on column v_org_purchase.dcreatetime not supported: 创建时间

-- comment on column v_org_purchase.dcreatedate not supported: 创建时间

-- comment on column v_org_purchase.dmodifytime not supported: 修改时间

-- comment on column v_org_purchase.dmodifydate not supported: 修改时间

-- comment on column v_org_purchase.ccreator not supported: 创建人

-- comment on column v_org_purchase.cmodifier not supported: 修改人

-- comment on column v_org_purchase.creatorid not supported: 创建人

-- comment on column v_org_purchase.modifierid not supported: 修改人

-- comment on column v_org_purchase.orgid not supported: 组织单元主键

-- comment on column v_org_purchase.id not supported: 主键

-- comment on column v_org_purchase.tenant_id not supported: ID

