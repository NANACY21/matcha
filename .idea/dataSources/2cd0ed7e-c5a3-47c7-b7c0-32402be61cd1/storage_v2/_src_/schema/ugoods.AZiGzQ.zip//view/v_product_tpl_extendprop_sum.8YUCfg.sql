create definer = root@`%` view v_product_tpl_extendprop_sum as
select `prop`.`tpl_id`            AS `tpl_id`,
       `prop`.`propertyType`      AS `propertyType`,
       `udb`.`defineId`           AS `defineId`,
       `prop`.`propertyAlias`     AS `propertyAlias`,
       `prop`.`isArchiveRequired` AS `isArchiveRequired`,
       `prop`.`id`                AS `id`,
       `prop`.`pubts`             AS `pubts`,
       `prop`.`iDeleted`          AS `isDeleted`,
       `prop`.`ordernumber`       AS `ordernumber`,
       `prop`.`isShow`            AS `isShow`,
       `vals`.`values`            AS `values`
from ((`ugoods`.`product_tpl_extendprop` `prop` left join `ugoods`.`v_product_tpl_extendprop_valsum` `vals` on ((`prop`.`id` = `vals`.`id`)))
         left join `ugoods`.`userdef_base` `udb` on ((`prop`.`propertyType` = `udb`.`id`)));

-- comment on column v_product_tpl_extendprop_sum.tpl_id not supported: 商品模板

-- comment on column v_product_tpl_extendprop_sum.propertyType not supported: 属性名称

-- comment on column v_product_tpl_extendprop_sum.defineId not supported: 与bill里的自定义项保持一致

-- comment on column v_product_tpl_extendprop_sum.id not supported: ID

-- comment on column v_product_tpl_extendprop_sum.pubts not supported: 时间戳

-- comment on column v_product_tpl_extendprop_sum.isDeleted not supported: 逻辑删除标记

