create definer = root@`%` view v_orgs11 as
select 1 AS `cCode`, 1 AS `cName`, 1 AS `cFullName`, 1 AS `id`, 1 AS `pubts`, 1 AS `tenant_id`;

