create view v_orgs11 as
select `iuap_cloud_basedoc`.`org_orgs`.`code` AS `cCode`,
       `iuap_cloud_basedoc`.`org_orgs`.`name` AS `cName`,
       `iuap_cloud_basedoc`.`org_orgs`.`name` AS `cFullName`,
       `iuap_cloud_basedoc`.`org_orgs`.`id`   AS `id`,
       `iuap_cloud_basedoc`.`org_orgs`.`ts`   AS `pubts`,
       `ugoods`.`tenant`.`id`                 AS `tenant_id`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_orgs`
                   on ((`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)));

-- comment on column v_orgs11.id not supported: 主键

-- comment on column v_orgs11.tenant_id not supported: ID

