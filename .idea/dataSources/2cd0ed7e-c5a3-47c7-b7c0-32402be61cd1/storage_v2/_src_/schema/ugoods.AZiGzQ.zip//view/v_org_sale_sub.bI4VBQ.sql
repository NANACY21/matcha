create definer = root@`%` view v_org_sale_sub as
select `iuap_cloud_basedoc`.`org_orgs`.`code`                                   AS `ccode`,
       `iuap_cloud_basedoc`.`org_orgs`.`innercode`                              AS `cpath`,
       `iuap_cloud_basedoc`.`org_orgs`.`name`                                   AS `cname`,
       `iuap_cloud_basedoc`.`org_orgs`.`name`                                   AS `cfullname`,
       `iuap_cloud_basedoc`.`org_orgs`.`parentid`                               AS `iparentid`,
       (case `iuap_cloud_basedoc`.`org_orgs`.`enable` when 1 then 0 else 1 end) AS `bstopstatus`,
       `iuap_cloud_basedoc`.`org_orgs`.`id`                                     AS `id`,
       `ugoods`.`tenant`.`id`                                                   AS `tenant_id`,
       `iuap_cloud_basedoc`.`org_orgs`.`name2`                                  AS `cname2`,
       `iuap_cloud_basedoc`.`org_orgs`.`name3`                                  AS `cname3`,
       `iuap_cloud_basedoc`.`org_orgs`.`name4`                                  AS `cname4`,
       `iuap_cloud_basedoc`.`org_orgs`.`name5`                                  AS `cname5`,
       `iuap_cloud_basedoc`.`org_orgs`.`name6`                                  AS `cname6`,
       `iuap_cloud_basedoc`.`org_orgs`.`name2`                                  AS `cfullname2`,
       `iuap_cloud_basedoc`.`org_orgs`.`name3`                                  AS `cfullname3`,
       `iuap_cloud_basedoc`.`org_orgs`.`name4`                                  AS `cfullname4`,
       `iuap_cloud_basedoc`.`org_orgs`.`name5`                                  AS `cfullname5`,
       `iuap_cloud_basedoc`.`org_orgs`.`name6`                                  AS `cfullname6`
from (`ugoods`.`tenant`
         left join `iuap_cloud_basedoc`.`org_orgs`
                   on ((`iuap_cloud_basedoc`.`org_orgs`.`tenantid` = `ugoods`.`tenant`.`tenantcenter_id`)))
where (`iuap_cloud_basedoc`.`org_orgs`.`dr` = 0);

-- comment on column v_org_sale_sub.cpath not supported: 内部码

-- comment on column v_org_sale_sub.iparentid not supported: 上级节点

-- comment on column v_org_sale_sub.id not supported: 主键

-- comment on column v_org_sale_sub.tenant_id not supported: ID

