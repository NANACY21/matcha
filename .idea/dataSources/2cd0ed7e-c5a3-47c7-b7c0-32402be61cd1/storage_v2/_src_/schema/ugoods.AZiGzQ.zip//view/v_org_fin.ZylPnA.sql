create definer = root@`%` view v_org_fin as
select `iuap_cloud_basedoc`.`org_fin`.`code`                                                AS `ccode`,
       `iuap_cloud_basedoc`.`org_fin`.`name`                                                AS `cname`,
       `iuap_cloud_basedoc`.`org_fin`.`name`                                                AS `cfullname`,
       `iuap_cloud_basedoc`.`org_fin`.`displayorder`                                        AS `isortnum`,
       0                                                                                    AS `bisend`,
       NULL                                                                                 AS `corgfuncid`,
       0                                                                                    AS `bisglobal`,
       NULL                                                                                 AS `cerpcode`,
       NULL                                                                                 AS `ceaicode`,
       (case `iuap_cloud_basedoc`.`org_fin`.`enable` when 1 then 0 else 1 end)              AS `bstopstatus`,
       NULL                                                                                 AS `dstoptime`,
       `iuap_cloud_basedoc`.`org_fin`.`creationtime`                                        AS `dcreatetime`,
       `iuap_cloud_basedoc`.`org_fin`.`creationtime`                                        AS `dcreatedate`,
       `iuap_cloud_basedoc`.`org_fin`.`modifiedtime`                                        AS `dmodifytime`,
       `iuap_cloud_basedoc`.`org_fin`.`modifiedtime`                                        AS `dmodifydate`,
       `iuap_cloud_basedoc`.`org_fin`.`creator`                                             AS `ccreator`,
       `iuap_cloud_basedoc`.`org_fin`.`modifier`                                            AS `cmodifier`,
       `iuap_cloud_basedoc`.`org_fin`.`creator`                                             AS `creatorid`,
       `iuap_cloud_basedoc`.`org_fin`.`modifier`                                            AS `modifierid`,
       `iuap_cloud_basedoc`.`org_fin`.`id`                                                  AS `id`,
       `iuap_cloud_basedoc`.`org_fin`.`ts`                                                  AS `pubts`,
       `ugoods`.`tenant`.`id`                                                               AS `tenant_id`,
       NULL                                                                                 AS `customerid`,
       `iuap_cloud_basedoc`.`org_fin`.`taxpayerid`                                          AS `taxpayerid`,
       `iuap_cloud_basedoc`.`org_fin`.`currency`                                            AS `currency`,
       `iuap_cloud_basedoc`.`org_fin`.`statetaxregnum`                                      AS `statetaxregnum`,
       `iuap_cloud_basedoc`.`org_fin`.`localtaxregnum`                                      AS `localtaxregnum`,
       `iuap_cloud_basedoc`.`org_fin`.`accountingcalendar`                                  AS `accountingcalendar`,
       `iuap_cloud_basedoc`.`org_fin`.`region`                                              AS `region`,
       `iuap_cloud_basedoc`.`org_fin`.`orglevel`                                            AS `orglevel`,
       `iuap_cloud_basedoc`.`org_fin`.`orgid`                                               AS `orgid`,
       (case
            when (`iuap_cloud_basedoc`.`org_fin`.`parentid` = '') then NULL
            else `iuap_cloud_basedoc`.`org_fin`.`parentid` end)                             AS `iparentid`,
       NULL                                                                                 AS `parentorgid`,
       1                                                                                    AS `ilevel`,
       concat(`iuap_cloud_basedoc`.`org_fin`.`id`, '|')                                     AS `cpath`,
       NULL                                                                                 AS `orgtypeid`,
       `iuap_cloud_basedoc`.`bd_currency_tenant`.`code`                                     AS `currencycode`,
       `iuap_cloud_basedoc`.`bd_currency_tenant`.`name`                                     AS `currencyname`,
       `iuap_cloud_basedoc`.`org_fin`.`principal`                                           AS `principal`,
       `iuap_cloud_basedoc`.`org_fin`.`periodschema`                                        AS `periodschema`,
       (case `iuap_cloud_basedoc`.`org_fin`.`taxpayertype` when 1 then 0 when 2 then 1 end) AS `itaxpayingcate`,
       `iuap_cloud_basedoc`.`org_fin`.`exchangerate`                                        AS `exchangerate`,
       `iuap_cloud_basedoc`.`org_fin`.`name2`                                               AS `cname2`,
       `iuap_cloud_basedoc`.`org_fin`.`name3`                                               AS `cname3`,
       `iuap_cloud_basedoc`.`org_fin`.`name4`                                               AS `cname4`,
       `iuap_cloud_basedoc`.`org_fin`.`name5`                                               AS `cname5`,
       `iuap_cloud_basedoc`.`org_fin`.`name6`                                               AS `cname6`,
       `iuap_cloud_basedoc`.`org_fin`.`name2`                                               AS `cfullname2`,
       `iuap_cloud_basedoc`.`org_fin`.`name3`                                               AS `cfullname3`,
       `iuap_cloud_basedoc`.`org_fin`.`name4`                                               AS `cfullname4`,
       `iuap_cloud_basedoc`.`org_fin`.`name5`                                               AS `cfullname5`,
       `iuap_cloud_basedoc`.`org_fin`.`name6`                                               AS `cfullname6`
from ((`ugoods`.`tenant` left join `iuap_cloud_basedoc`.`org_fin` on ((`iuap_cloud_basedoc`.`org_fin`.`tenantid` =
                                                                       `ugoods`.`tenant`.`tenantcenter_id`)))
         left join `iuap_cloud_basedoc`.`bd_currency_tenant`
                   on (((`iuap_cloud_basedoc`.`org_fin`.`currency` = `iuap_cloud_basedoc`.`bd_currency_tenant`.`id`) and
                        (`iuap_cloud_basedoc`.`org_fin`.`tenantid` =
                         `iuap_cloud_basedoc`.`bd_currency_tenant`.`tenantid`))))
where (`iuap_cloud_basedoc`.`org_fin`.`dr` = 0);

-- comment on column v_org_fin.isortnum not supported: 显示顺序

-- comment on column v_org_fin.dcreatetime not supported: 创建时间

-- comment on column v_org_fin.dcreatedate not supported: 创建时间

-- comment on column v_org_fin.dmodifytime not supported: 修改时间

-- comment on column v_org_fin.dmodifydate not supported: 修改时间

-- comment on column v_org_fin.ccreator not supported: 创建者

-- comment on column v_org_fin.cmodifier not supported: 修改人

-- comment on column v_org_fin.creatorid not supported: 创建者

-- comment on column v_org_fin.modifierid not supported: 修改人

-- comment on column v_org_fin.id not supported: 主键

-- comment on column v_org_fin.tenant_id not supported: ID

-- comment on column v_org_fin.taxpayerid not supported: 纳税人识别号

-- comment on column v_org_fin.currency not supported: 本位币

-- comment on column v_org_fin.statetaxregnum not supported: 国税登记号

-- comment on column v_org_fin.localtaxregnum not supported: 地税登记号

-- comment on column v_org_fin.accountingcalendar not supported: 会计日历

-- comment on column v_org_fin.region not supported: 国家地区

-- comment on column v_org_fin.orglevel not supported: 组织级别

-- comment on column v_org_fin.currencycode not supported: 币种简称

-- comment on column v_org_fin.currencyname not supported: 币种

-- comment on column v_org_fin.principal not supported: 负责人

-- comment on column v_org_fin.periodschema not supported: 默认会计期间方案

-- comment on column v_org_fin.exchangerate not supported: 汇率类型

