create definer = root@`%` view v_productalbum_min as
select `ugoods`.`productalbum`.`productId` AS `productid`, min(`ugoods`.`productalbum`.`id`) AS `firstrecord`
from `ugoods`.`productalbum`
group by `ugoods`.`productalbum`.`productId`;

-- comment on column v_productalbum_min.productid not supported: 所属商品

-- comment on column v_productalbum_min.firstrecord not supported: ID

