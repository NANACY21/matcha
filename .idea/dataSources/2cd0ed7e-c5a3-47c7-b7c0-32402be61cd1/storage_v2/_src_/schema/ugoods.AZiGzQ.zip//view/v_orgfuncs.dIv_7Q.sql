create definer = root@`%` view v_orgfuncs as
select `iuap_cloud_basedoc`.`org_type`.`code`    AS `ccode`,
       `iuap_cloud_basedoc`.`org_type`.`name`    AS `cname`,
       `iuap_cloud_basedoc`.`org_type`.`ts`      AS `pubts`,
       `iuap_cloud_basedoc`.`org_type`.`idalias` AS `id`
from `iuap_cloud_basedoc`.`org_type`
where ((`iuap_cloud_basedoc`.`org_type`.`dr` = 0) and (`iuap_cloud_basedoc`.`org_type`.`id` like 'orgfunc%'));

-- comment on column v_orgfuncs.ccode not supported: 编码

-- comment on column v_orgfuncs.cname not supported: 名称

