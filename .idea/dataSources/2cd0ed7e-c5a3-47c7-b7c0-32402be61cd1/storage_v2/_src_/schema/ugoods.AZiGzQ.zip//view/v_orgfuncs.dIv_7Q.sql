create view v_orgfuncs as
select `iuap_cloud_basedoc`.`org_type`.`code`    AS `cCode`,
       `iuap_cloud_basedoc`.`org_type`.`name`    AS `cName`,
       `iuap_cloud_basedoc`.`org_type`.`ts`      AS `pubts`,
       `iuap_cloud_basedoc`.`org_type`.`idalias` AS `id`
from `iuap_cloud_basedoc`.`org_type`
where ((`iuap_cloud_basedoc`.`org_type`.`dr` = 0) and (`iuap_cloud_basedoc`.`org_type`.`id` like 'ORGFUNC%'));

-- comment on column v_orgfuncs.cCode not supported: 编码

-- comment on column v_orgfuncs.cName not supported: 名称

