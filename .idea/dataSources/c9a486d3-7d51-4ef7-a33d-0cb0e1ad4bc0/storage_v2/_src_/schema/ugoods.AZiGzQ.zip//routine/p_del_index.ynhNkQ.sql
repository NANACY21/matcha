create
    definer = dtssyncwriter@`%` procedure p_del_index(IN ctablename varchar(255), IN cindexname varchar(255))
begin 
declare existsCount integer default 0;
declare strsql varchar(512);

set @strsql = concat('alter table ', ctablename, ' drop index ', cindexname , ';'); 

SELECT count(1) into existsCount FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name = ctablename AND index_name = cindexname;
select existsCount;

if existsCount > 0 then 
prepare strsql from @strsql;
execute strsql;
end if;

end;

