create view shopproductskuview as
select `b`.`iRangeType`          AS `iRangeType`,
       `b`.`orgId`               AS `orgId`,
       `b`.`customerId`          AS `customerId`,
       `b`.`id`                  AS `iShopProductId`,
       `b`.`isCreator`           AS `isCreator`,
       `a`.`productId`           AS `productId`,
       `a`.`skuId`               AS `skuId`,
       `a`.`productApplyRangeId` AS `productApplyRangeId`,
       `a`.`iStatus`             AS `iStatus`,
       `a`.`iUStatus`            AS `iUStatus`,
       `a`.`batchPrice`          AS `batchPrice`,
       `a`.`fMarkPrice`          AS `fMarkPrice`,
       `a`.`fSalePrice`          AS `fSalePrice`,
       `a`.`fMarketPrice`        AS `fMarketPrice`,
       `a`.`fPrimeCosts`         AS `fPrimeCosts`,
       `a`.`fSettleAccountsRate` AS `fSettleAccountsRate`,
       `a`.`cBarCode`            AS `cBarCode`,
       `a`.`lInventoryCount`     AS `lInventoryCount`,
       `a`.`weight`              AS `weight`,
       `a`.`salePoints`          AS `salePoints`,
       `a`.`iSaled`              AS `iSaled`,
       `a`.`batchUnitId`         AS `batchUnitId`,
       `a`.`batchRate`           AS `batchRate`,
       `a`.`iMinOrderQuantity`   AS `iMinOrderQuantity`,
       `a`.`batchDeliveryDays`   AS `batchDeliveryDays`,
       `b`.`id`                  AS `id`,
       `a`.`pubts`               AS `pubts`,
       `b`.`tenant_id`           AS `tenant_id`,
       `a`.`shortName`           AS `shortName`,
       `a`.`iStatus_b`           AS `iStatus_b`,
       `a`.`iUStatus_b`          AS `iUStatus_b`,
       `a`.`fNoTaxCostPrice`     AS `fNoTaxCostPrice`,
       `a`.`stopstatus`          AS `stopstatus`
from (`ugoods`.`productapplyrange` `b`
         left join `ugoods`.`productskudetail` `a`
                   on (((`a`.`productApplyRangeId` = `b`.`id`) and (`a`.`productId` = `b`.`productId`))));

-- comment on column shopproductskuview.iRangeType not supported: 商品适用范围类型

-- comment on column shopproductskuview.orgId not supported: 组织ID

-- comment on column shopproductskuview.customerId not supported: 客户ID

-- comment on column shopproductskuview.iShopProductId not supported: ID

-- comment on column shopproductskuview.isCreator not supported: 是否创建者

-- comment on column shopproductskuview.productId not supported: 所属商品

-- comment on column shopproductskuview.skuId not supported: SKUID

-- comment on column shopproductskuview.productApplyRangeId not supported: 商品适用范围ID

-- comment on column shopproductskuview.iStatus not supported: 商城上下架状态

-- comment on column shopproductskuview.iUStatus not supported: U订货上下架状态

-- comment on column shopproductskuview.batchPrice not supported: 批发价

-- comment on column shopproductskuview.fMarkPrice not supported: 建议零售价

-- comment on column shopproductskuview.fSalePrice not supported: 线上零售价

-- comment on column shopproductskuview.fMarketPrice not supported: 市场价

-- comment on column shopproductskuview.fPrimeCosts not supported: 进货价

-- comment on column shopproductskuview.fSettleAccountsRate not supported: 结算费率

-- comment on column shopproductskuview.cBarCode not supported: SKU条形码

-- comment on column shopproductskuview.lInventoryCount not supported: 库存

-- comment on column shopproductskuview.weight not supported: 重量

-- comment on column shopproductskuview.salePoints not supported: 积分数量

-- comment on column shopproductskuview.iSaled not supported: 已售标记

-- comment on column shopproductskuview.batchUnitId not supported: 批发单位

-- comment on column shopproductskuview.batchRate not supported: 批发单位换算率

-- comment on column shopproductskuview.iMinOrderQuantity not supported: 批发-起订量

-- comment on column shopproductskuview.batchDeliveryDays not supported: 批发-交货周期（天）

-- comment on column shopproductskuview.id not supported: ID

-- comment on column shopproductskuview.pubts not supported: 时间戳

-- comment on column shopproductskuview.tenant_id not supported: 租户

-- comment on column shopproductskuview.iStatus_b not supported: 商城上下架状态_备用

-- comment on column shopproductskuview.iUStatus_b not supported: U订货上下架状态_备用

-- comment on column shopproductskuview.fNoTaxCostPrice not supported: 参考成本

-- comment on column shopproductskuview.stopstatus not supported: 停用状态

