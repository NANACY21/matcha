create view v_mallordershop_all as
select `upmalls`.`shop`.`id`        AS `id`,
       `upmalls`.`shop`.`cCorpName` AS `code`,
       `upmalls`.`shop`.`cShopname` AS `name`,
       `upmalls`.`shop`.`iCustId`   AS `customerId`,
       `upmalls`.`shop`.`pubuts`    AS `pubts`,
       `upmalls`.`shop`.`iCorpId`   AS `iCorpId`,
       `corp`.`yxyTenantId`         AS `yxyTenantId`
from (`upmalls`.`shop`
         left join `upmalls`.`corpration` `corp` on ((`upmalls`.`shop`.`iCorpId` = `corp`.`id`)))
union
select `shop`.`id`        AS `id`,
       `shop`.`cName`     AS `code`,
       `shop`.`cFullName` AS `name`,
       `shop`.`iAgentId`  AS `customerId`,
       `shop`.`pubuts`    AS `pubts`,
       `shop`.`iCorpId`   AS `iCorpId`,
       `corp`.`cTenantId` AS `yxyTenantId`
from (`uorders`.`merchant` `shop`
         left join `uorders`.`yxycorp` `corp` on ((`shop`.`iCorpId` = `corp`.`iCorpId`)))
where (`shop`.`iDeleted` = 0)
union
select `uorders`.`agent`.`id`      AS `id`,
       `uorders`.`agent`.`cName`   AS `code`,
       `uorders`.`agent`.`cName`   AS `name`,
       `uorders`.`agent`.`id`      AS `customerId`,
       `uorders`.`agent`.`pubuts`  AS `pubts`,
       `uorders`.`agent`.`iCorpId` AS `iCorpId`,
       `corp`.`cTenantId`          AS `yxyTenantId`
from (`uorders`.`agent`
         left join `uorders`.`yxycorp` `corp` on ((`uorders`.`agent`.`iCorpId` = `corp`.`iCorpId`)))
where ((`uorders`.`agent`.`bURetailJoin` = 1) and (`uorders`.`agent`.`bMerchant` = 0));

