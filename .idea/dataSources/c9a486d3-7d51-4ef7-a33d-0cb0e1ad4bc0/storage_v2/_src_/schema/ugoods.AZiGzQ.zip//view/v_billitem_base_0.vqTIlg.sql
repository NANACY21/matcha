create view v_billitem_base_0 as
select `ugoods`.`billitem_base`.`id`         AS `id`,
       `ugoods`.`bill_base`.`cBillNo`        AS `cBillNo`,
       `ugoods`.`billentity_base`.`cCode`    AS `cEntityCode`,
       `ugoods`.`billitem_base`.`cFieldName` AS `cFieldName`,
       `ugoods`.`billitem_base`.`isExport`   AS `isExport`
from ((`ugoods`.`billitem_base` join `ugoods`.`bill_base` on ((`ugoods`.`billitem_base`.`iBillId` = `ugoods`.`bill_base`.`id`)))
         join `ugoods`.`billentity_base`
              on ((`ugoods`.`billitem_base`.`iBillEntityId` = `ugoods`.`billentity_base`.`id`)))
where (`ugoods`.`billitem_base`.`tenant_id` = 0);

-- comment on column v_billitem_base_0.id not supported: 主键

-- comment on column v_billitem_base_0.cBillNo not supported: 单据编号-cardnumber

-- comment on column v_billitem_base_0.cEntityCode not supported: group编码

-- comment on column v_billitem_base_0.cFieldName not supported: 带关联关系的字段名

