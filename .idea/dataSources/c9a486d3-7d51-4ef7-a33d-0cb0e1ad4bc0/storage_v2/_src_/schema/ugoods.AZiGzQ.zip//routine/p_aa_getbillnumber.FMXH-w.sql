create
    definer = dtssyncwriter@`%` procedure p_aa_getbillnumber(IN p_tenant varchar(50), IN p_cbillnum varchar(50),
                                                             IN p_ownerorg bigint, IN p_cglide varchar(100),
                                                             IN p_cgliderule varchar(100), IN p_cseed varchar(100),
                                                             IN p_irealno int, OUT p_inumber int)
begin
	select inumber into p_inumber from aa_billhistory where tenant_id=p_tenant and cbillnum=p_cbillnum and ifnull(ownerorg,0)=p_ownerorg and cseed=p_cseed;
	if p_inumber is not null then 		
		set p_inumber=p_inumber+1;
		
		if p_irealno=1 then
			update aa_billhistory set inumber=p_inumber where cbillnum=p_cbillnum and ifnull(ownerorg,0)=p_ownerorg and cseed=p_cseed;
		end if;
	else
		select istartnumber into p_inumber from aa_billnumber where cbillnum=p_cbillnum and tenant_id=p_tenant;
		
		if p_irealno=1 then
			insert into aa_billhistory(cbillnum,ownerorg,cglide,cgliderule,cseed,inumber,tenant_id) 
			values (p_cbillnum,p_ownerorg,p_cglide,p_cgliderule,p_cseed,ifnull(p_inumber,1),p_tenant);
		end if;
	end if;
end;

